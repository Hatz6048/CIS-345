kernel/qlock.o: kernel/qlock.c kernel/types.h kernel/param.h \
 kernel/memlayout.h kernel/riscv.h kernel/defs.h kernel/qlock.h \
 kernel/spinlock.h kernel/proc.h
