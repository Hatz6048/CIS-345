#ifndef _QLOCK_H_
#define _QLOCK_H_

#include "spinlock.h"

struct qlock {
	struct spinlock lk;
	int locked;
	uint next_ticket;
	uint serving_ticket;
};

void initqlock(struct qlock *q, char *name);
void acquireq(struct qlock *q);
void releaseq(struct qlock *q);

#endif
