#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "defs.h"
#include "qlock.h"
#include "proc.h"

void
initqlock(struct qlock *q, char *name)
{
	initlock(&q->lk, name);
	q->locked = 0;
	q->next_ticket = 0;
	q->serving_ticket = 0;
}

void
acquireq(struct qlock *q)
{ 
	uint ticket;

	acquire(&q->lk);
	

	ticket = q->next_ticket;
	q->next_ticket++;

	while(ticket != q->serving_ticket)
	{
	sleep_prepare(&q->serving_ticket);
	release(&q->lk);
	sleep();
	acquire(&q->lk);
}

	q->locked = 1;
	release(&q->lk);
}

void
releaseq(struct qlock *q)
{
	acquire(&q->lk);

	if(q->locked == 0)
		panic("releaseq");

	q->locked = 0;
	q->serving_ticket++;

	wakeup(&q->serving_ticket);

	release(&q->lk);
}

void
qlock_basic_test(void)
{
	struct qlock q;

	initqlock(&q, "qlock_test");
	
	printk("QLock Test Starting\n");

	acquireq(&q);
	printk("QLock acquired successfully\n");

	releaseq(&q);
	printk("QLock released successfully\n");

	printk("QLock Basic Test Complete\n");
}

static struct qlock shared_q;
static int active = 0;
static int counter = 0;

void
qlock_concurrent_test(void)
{

	acquireq(&shared_q);

	active++;
	if(active != 1)
		panic("QLock mutual exclusion failed");

	counter++;
	printk("Process %d acquried QLock, counter = %d\n",
		myproc()->pid, counter);

	for(volatile int i = 0; i< 1000000;i++);

	active--;

	printk("Process%d released QLock\n", myproc()->pid);

	releaseq(&shared_q);
}

void 
qlock_test_init(void)
{
	initqlock(&shared_q, "shared_qlock");
}
