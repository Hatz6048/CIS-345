
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	0000a117          	auipc	sp,0xa
    80000004:	53813103          	ld	sp,1336(sp) # 8000a538 <_GLOBAL_OFFSET_TABLE_+0x8>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	042000ef          	jal	80000058 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    80000024:	30a027f3          	csrr	a5,0x30a
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | MENVCFG_STCE);
    80000028:	577d                	li	a4,-1
    8000002a:	177e                	slli	a4,a4,0x3f
    8000002c:	8fd9                	or	a5,a5,a4

static inline void
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    8000002e:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r"(x));
    80000032:	306027f3          	csrr	a5,mcounteren

  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000036:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r"(x));
    8000003a:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r"(x));
    8000003e:	c01027f3          	rdtime	a5

  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80000042:	000f4737          	lui	a4,0xf4
    80000046:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000004a:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000004c:	14d79073          	csrw	stimecmp,a5
}
    80000050:	60a2                	ld	ra,8(sp)
    80000052:	6402                	ld	s0,0(sp)
    80000054:	0141                	addi	sp,sp,16
    80000056:	8082                	ret

0000000080000058 <start>:
{
    80000058:	1141                	addi	sp,sp,-16
    8000005a:	e406                	sd	ra,8(sp)
    8000005c:	e022                	sd	s0,0(sp)
    8000005e:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    80000060:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000064:	7779                	lui	a4,0xffffe
    80000066:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdaf3f>
    8000006a:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    8000006c:	6705                	lui	a4,0x1
    8000006e:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80000072:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    80000074:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    80000078:	00001797          	auipc	a5,0x1
    8000007c:	e2678793          	addi	a5,a5,-474 # 80000e9e <main>
    80000080:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    80000084:	4781                	li	a5,0
    80000086:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    8000008a:	67c1                	lui	a5,0x10
    8000008c:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000008e:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    80000092:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    80000096:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    8000009a:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r"(x));
    8000009e:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    800000a2:	57fd                	li	a5,-1
    800000a4:	83a9                	srli	a5,a5,0xa
    800000a6:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000aa:	47bd                	li	a5,15
    800000ac:	3a079073          	csrw	pmpcfg0,a5
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    800000b0:	30a027f3          	csrr	a5,0x30a
  w_menvcfg(r_menvcfg() | MENVCFG_ADUE);
    800000b4:	4705                	li	a4,1
    800000b6:	1776                	slli	a4,a4,0x3d
    800000b8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    800000ba:	30a79073          	csrw	0x30a,a5
  timerinit();
    800000be:	f5fff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000c2:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c6:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000c8:	823e                	mv	tp,a5
  asm volatile("mret");
    800000ca:	30200073          	mret
}
    800000ce:	60a2                	ld	ra,8(sp)
    800000d0:	6402                	ld	s0,0(sp)
    800000d2:	0141                	addi	sp,sp,16
    800000d4:	8082                	ret

00000000800000d6 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d6:	7119                	addi	sp,sp,-128
    800000d8:	fc86                	sd	ra,120(sp)
    800000da:	f8a2                	sd	s0,112(sp)
    800000dc:	f4a6                	sd	s1,104(sp)
    800000de:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while (i < n) {
    800000e0:	06c05b63          	blez	a2,80000156 <consolewrite+0x80>
    800000e4:	f0ca                	sd	s2,96(sp)
    800000e6:	ecce                	sd	s3,88(sp)
    800000e8:	e8d2                	sd	s4,80(sp)
    800000ea:	e4d6                	sd	s5,72(sp)
    800000ec:	e0da                	sd	s6,64(sp)
    800000ee:	fc5e                	sd	s7,56(sp)
    800000f0:	f862                	sd	s8,48(sp)
    800000f2:	f466                	sd	s9,40(sp)
    800000f4:	f06a                	sd	s10,32(sp)
    800000f6:	8b2a                	mv	s6,a0
    800000f8:	8bae                	mv	s7,a1
    800000fa:	8a32                	mv	s4,a2
  int i = 0;
    800000fc:	4481                	li	s1,0
    int nn = sizeof(buf);
    if (nn > n - i)
    800000fe:	02000c93          	li	s9,32
    80000102:	02000d13          	li	s10,32
      nn = n - i;
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000106:	f8040a93          	addi	s5,s0,-128
    8000010a:	5c7d                	li	s8,-1
    8000010c:	a025                	j	80000134 <consolewrite+0x5e>
    if (nn > n - i)
    8000010e:	0009099b          	sext.w	s3,s2
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000112:	86ce                	mv	a3,s3
    80000114:	01748633          	add	a2,s1,s7
    80000118:	85da                	mv	a1,s6
    8000011a:	8556                	mv	a0,s5
    8000011c:	218020ef          	jal	80002334 <either_copyin>
    80000120:	03850d63          	beq	a0,s8,8000015a <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000124:	85ce                	mv	a1,s3
    80000126:	8556                	mv	a0,s5
    80000128:	7c2000ef          	jal	800008ea <uartwrite>
    i += nn;
    8000012c:	009904bb          	addw	s1,s2,s1
  while (i < n) {
    80000130:	0144d963          	bge	s1,s4,80000142 <consolewrite+0x6c>
    if (nn > n - i)
    80000134:	409a07bb          	subw	a5,s4,s1
    80000138:	893e                	mv	s2,a5
    8000013a:	fcfcdae3          	bge	s9,a5,8000010e <consolewrite+0x38>
    8000013e:	896a                	mv	s2,s10
    80000140:	b7f9                	j	8000010e <consolewrite+0x38>
    80000142:	7906                	ld	s2,96(sp)
    80000144:	69e6                	ld	s3,88(sp)
    80000146:	6a46                	ld	s4,80(sp)
    80000148:	6aa6                	ld	s5,72(sp)
    8000014a:	6b06                	ld	s6,64(sp)
    8000014c:	7be2                	ld	s7,56(sp)
    8000014e:	7c42                	ld	s8,48(sp)
    80000150:	7ca2                	ld	s9,40(sp)
    80000152:	7d02                	ld	s10,32(sp)
    80000154:	a821                	j	8000016c <consolewrite+0x96>
  int i = 0;
    80000156:	4481                	li	s1,0
    80000158:	a811                	j	8000016c <consolewrite+0x96>
    8000015a:	7906                	ld	s2,96(sp)
    8000015c:	69e6                	ld	s3,88(sp)
    8000015e:	6a46                	ld	s4,80(sp)
    80000160:	6aa6                	ld	s5,72(sp)
    80000162:	6b06                	ld	s6,64(sp)
    80000164:	7be2                	ld	s7,56(sp)
    80000166:	7c42                	ld	s8,48(sp)
    80000168:	7ca2                	ld	s9,40(sp)
    8000016a:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016c:	8526                	mv	a0,s1
    8000016e:	70e6                	ld	ra,120(sp)
    80000170:	7446                	ld	s0,112(sp)
    80000172:	74a6                	ld	s1,104(sp)
    80000174:	6109                	addi	sp,sp,128
    80000176:	8082                	ret

0000000080000178 <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000178:	711d                	addi	sp,sp,-96
    8000017a:	ec86                	sd	ra,88(sp)
    8000017c:	e8a2                	sd	s0,80(sp)
    8000017e:	e4a6                	sd	s1,72(sp)
    80000180:	e0ca                	sd	s2,64(sp)
    80000182:	fc4e                	sd	s3,56(sp)
    80000184:	f852                	sd	s4,48(sp)
    80000186:	f05a                	sd	s6,32(sp)
    80000188:	ec5e                	sd	s7,24(sp)
    8000018a:	1080                	addi	s0,sp,96
    8000018c:	8b2a                	mv	s6,a0
    8000018e:	8a2e                	mv	s4,a1
    80000190:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000192:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000194:	00012517          	auipc	a0,0x12
    80000198:	3fc50513          	addi	a0,a0,1020 # 80012590 <cons>
    8000019c:	28d000ef          	jal	80000c28 <acquire>
  while (n > 0) {
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while (cons.r == cons.w) {
    800001a0:	00012497          	auipc	s1,0x12
    800001a4:	3f048493          	addi	s1,s1,1008 # 80012590 <cons>
      if (killed(myproc())) {
        release(&cons.lock);
        return -1;
      }
      sleep_prepare(&cons.r);
    800001a8:	00012917          	auipc	s2,0x12
    800001ac:	48090913          	addi	s2,s2,1152 # 80012628 <cons+0x98>
  while (n > 0) {
    800001b0:	0d305263          	blez	s3,80000274 <consoleread+0xfc>
    while (cons.r == cons.w) {
    800001b4:	0984a783          	lw	a5,152(s1)
    800001b8:	09c4a703          	lw	a4,156(s1)
    800001bc:	0af71763          	bne	a4,a5,8000026a <consoleread+0xf2>
      if (killed(myproc())) {
    800001c0:	78c010ef          	jal	8000194c <myproc>
    800001c4:	7f1010ef          	jal	800021b4 <killed>
    800001c8:	e925                	bnez	a0,80000238 <consoleread+0xc0>
      sleep_prepare(&cons.r);
    800001ca:	854a                	mv	a0,s2
    800001cc:	58b010ef          	jal	80001f56 <sleep_prepare>
      release(&cons.lock);
    800001d0:	8526                	mv	a0,s1
    800001d2:	2df000ef          	jal	80000cb0 <release>
      sleep();
    800001d6:	5bd010ef          	jal	80001f92 <sleep>
      acquire(&cons.lock);
    800001da:	8526                	mv	a0,s1
    800001dc:	24d000ef          	jal	80000c28 <acquire>
    while (cons.r == cons.w) {
    800001e0:	0984a783          	lw	a5,152(s1)
    800001e4:	09c4a703          	lw	a4,156(s1)
    800001e8:	fcf70ce3          	beq	a4,a5,800001c0 <consoleread+0x48>
    800001ec:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001ee:	00012717          	auipc	a4,0x12
    800001f2:	3a270713          	addi	a4,a4,930 # 80012590 <cons>
    800001f6:	0017869b          	addiw	a3,a5,1
    800001fa:	08d72c23          	sw	a3,152(a4)
    800001fe:	07f7f693          	andi	a3,a5,127
    80000202:	9736                	add	a4,a4,a3
    80000204:	01874703          	lbu	a4,24(a4)
    80000208:	00070a9b          	sext.w	s5,a4

    if (c == C('D')) { // end-of-file
    8000020c:	4691                	li	a3,4
    8000020e:	04da8663          	beq	s5,a3,8000025a <consoleread+0xe2>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80000212:	fae407a3          	sb	a4,-81(s0)
    if (either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000216:	4685                	li	a3,1
    80000218:	faf40613          	addi	a2,s0,-81
    8000021c:	85d2                	mv	a1,s4
    8000021e:	855a                	mv	a0,s6
    80000220:	0c8020ef          	jal	800022e8 <either_copyout>
    80000224:	57fd                	li	a5,-1
    80000226:	04f50663          	beq	a0,a5,80000272 <consoleread+0xfa>
      break;

    dst++;
    8000022a:	0a05                	addi	s4,s4,1
    --n;
    8000022c:	39fd                	addiw	s3,s3,-1

    if (c == '\n') {
    8000022e:	47a9                	li	a5,10
    80000230:	04fa8b63          	beq	s5,a5,80000286 <consoleread+0x10e>
    80000234:	7aa2                	ld	s5,40(sp)
    80000236:	bfad                	j	800001b0 <consoleread+0x38>
        release(&cons.lock);
    80000238:	00012517          	auipc	a0,0x12
    8000023c:	35850513          	addi	a0,a0,856 # 80012590 <cons>
    80000240:	271000ef          	jal	80000cb0 <release>
        return -1;
    80000244:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000246:	60e6                	ld	ra,88(sp)
    80000248:	6446                	ld	s0,80(sp)
    8000024a:	64a6                	ld	s1,72(sp)
    8000024c:	6906                	ld	s2,64(sp)
    8000024e:	79e2                	ld	s3,56(sp)
    80000250:	7a42                	ld	s4,48(sp)
    80000252:	7b02                	ld	s6,32(sp)
    80000254:	6be2                	ld	s7,24(sp)
    80000256:	6125                	addi	sp,sp,96
    80000258:	8082                	ret
      if (n < target) {
    8000025a:	0179fa63          	bgeu	s3,s7,8000026e <consoleread+0xf6>
        cons.r--;
    8000025e:	00012717          	auipc	a4,0x12
    80000262:	3cf72523          	sw	a5,970(a4) # 80012628 <cons+0x98>
    80000266:	7aa2                	ld	s5,40(sp)
    80000268:	a031                	j	80000274 <consoleread+0xfc>
    8000026a:	f456                	sd	s5,40(sp)
    8000026c:	b749                	j	800001ee <consoleread+0x76>
    8000026e:	7aa2                	ld	s5,40(sp)
    80000270:	a011                	j	80000274 <consoleread+0xfc>
    80000272:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000274:	00012517          	auipc	a0,0x12
    80000278:	31c50513          	addi	a0,a0,796 # 80012590 <cons>
    8000027c:	235000ef          	jal	80000cb0 <release>
  return target - n;
    80000280:	413b853b          	subw	a0,s7,s3
    80000284:	b7c9                	j	80000246 <consoleread+0xce>
    80000286:	7aa2                	ld	s5,40(sp)
    80000288:	b7f5                	j	80000274 <consoleread+0xfc>

000000008000028a <consputc>:
{
    8000028a:	1141                	addi	sp,sp,-16
    8000028c:	e406                	sd	ra,8(sp)
    8000028e:	e022                	sd	s0,0(sp)
    80000290:	0800                	addi	s0,sp,16
  if (c == BACKSPACE) {
    80000292:	10000793          	li	a5,256
    80000296:	00f50863          	beq	a0,a5,800002a6 <consputc+0x1c>
    uartputc_sync(c);
    8000029a:	6f6000ef          	jal	80000990 <uartputc_sync>
}
    8000029e:	60a2                	ld	ra,8(sp)
    800002a0:	6402                	ld	s0,0(sp)
    800002a2:	0141                	addi	sp,sp,16
    800002a4:	8082                	ret
    uartputc_sync('\b');
    800002a6:	4521                	li	a0,8
    800002a8:	6e8000ef          	jal	80000990 <uartputc_sync>
    uartputc_sync(' ');
    800002ac:	02000513          	li	a0,32
    800002b0:	6e0000ef          	jal	80000990 <uartputc_sync>
    uartputc_sync('\b');
    800002b4:	4521                	li	a0,8
    800002b6:	6da000ef          	jal	80000990 <uartputc_sync>
    800002ba:	b7d5                	j	8000029e <consputc+0x14>

00000000800002bc <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002bc:	1101                	addi	sp,sp,-32
    800002be:	ec06                	sd	ra,24(sp)
    800002c0:	e822                	sd	s0,16(sp)
    800002c2:	e426                	sd	s1,8(sp)
    800002c4:	1000                	addi	s0,sp,32
    800002c6:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002c8:	00012517          	auipc	a0,0x12
    800002cc:	2c850513          	addi	a0,a0,712 # 80012590 <cons>
    800002d0:	159000ef          	jal	80000c28 <acquire>

  switch (c) {
    800002d4:	47d5                	li	a5,21
    800002d6:	08f48d63          	beq	s1,a5,80000370 <consoleintr+0xb4>
    800002da:	0297c563          	blt	a5,s1,80000304 <consoleintr+0x48>
    800002de:	47a1                	li	a5,8
    800002e0:	0ef48263          	beq	s1,a5,800003c4 <consoleintr+0x108>
    800002e4:	47c1                	li	a5,16
    800002e6:	10f49363          	bne	s1,a5,800003ec <consoleintr+0x130>
  case C('P'): // Print process list.
    procdump();
    800002ea:	096020ef          	jal	80002380 <procdump>
      }
    }
    break;
  }

  release(&cons.lock);
    800002ee:	00012517          	auipc	a0,0x12
    800002f2:	2a250513          	addi	a0,a0,674 # 80012590 <cons>
    800002f6:	1bb000ef          	jal	80000cb0 <release>
}
    800002fa:	60e2                	ld	ra,24(sp)
    800002fc:	6442                	ld	s0,16(sp)
    800002fe:	64a2                	ld	s1,8(sp)
    80000300:	6105                	addi	sp,sp,32
    80000302:	8082                	ret
  switch (c) {
    80000304:	07f00793          	li	a5,127
    80000308:	0af48e63          	beq	s1,a5,800003c4 <consoleintr+0x108>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    8000030c:	00012717          	auipc	a4,0x12
    80000310:	28470713          	addi	a4,a4,644 # 80012590 <cons>
    80000314:	0a072783          	lw	a5,160(a4)
    80000318:	09872703          	lw	a4,152(a4)
    8000031c:	9f99                	subw	a5,a5,a4
    8000031e:	07f00713          	li	a4,127
    80000322:	fcf766e3          	bltu	a4,a5,800002ee <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000326:	47b5                	li	a5,13
    80000328:	0cf48563          	beq	s1,a5,800003f2 <consoleintr+0x136>
      consputc(c);
    8000032c:	8526                	mv	a0,s1
    8000032e:	f5dff0ef          	jal	8000028a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000332:	00012717          	auipc	a4,0x12
    80000336:	25e70713          	addi	a4,a4,606 # 80012590 <cons>
    8000033a:	0a072683          	lw	a3,160(a4)
    8000033e:	0016879b          	addiw	a5,a3,1
    80000342:	863e                	mv	a2,a5
    80000344:	0af72023          	sw	a5,160(a4)
    80000348:	07f6f693          	andi	a3,a3,127
    8000034c:	9736                	add	a4,a4,a3
    8000034e:	00970c23          	sb	s1,24(a4)
      if (c == '\n' || c == C('D') || cons.e - cons.r == INPUT_BUF_SIZE) {
    80000352:	ff648713          	addi	a4,s1,-10
    80000356:	c371                	beqz	a4,8000041a <consoleintr+0x15e>
    80000358:	14f1                	addi	s1,s1,-4
    8000035a:	c0e1                	beqz	s1,8000041a <consoleintr+0x15e>
    8000035c:	00012717          	auipc	a4,0x12
    80000360:	2cc72703          	lw	a4,716(a4) # 80012628 <cons+0x98>
    80000364:	9f99                	subw	a5,a5,a4
    80000366:	08000713          	li	a4,128
    8000036a:	f8e792e3          	bne	a5,a4,800002ee <consoleintr+0x32>
    8000036e:	a075                	j	8000041a <consoleintr+0x15e>
    80000370:	e04a                	sd	s2,0(sp)
    while (cons.e != cons.w &&
    80000372:	00012717          	auipc	a4,0x12
    80000376:	21e70713          	addi	a4,a4,542 # 80012590 <cons>
    8000037a:	0a072783          	lw	a5,160(a4)
    8000037e:	09c72703          	lw	a4,156(a4)
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000382:	00012497          	auipc	s1,0x12
    80000386:	20e48493          	addi	s1,s1,526 # 80012590 <cons>
    while (cons.e != cons.w &&
    8000038a:	4929                	li	s2,10
    8000038c:	02f70863          	beq	a4,a5,800003bc <consoleintr+0x100>
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000390:	37fd                	addiw	a5,a5,-1
    80000392:	07f7f713          	andi	a4,a5,127
    80000396:	9726                	add	a4,a4,s1
    while (cons.e != cons.w &&
    80000398:	01874703          	lbu	a4,24(a4)
    8000039c:	03270263          	beq	a4,s2,800003c0 <consoleintr+0x104>
      cons.e--;
    800003a0:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003a4:	10000513          	li	a0,256
    800003a8:	ee3ff0ef          	jal	8000028a <consputc>
    while (cons.e != cons.w &&
    800003ac:	0a04a783          	lw	a5,160(s1)
    800003b0:	09c4a703          	lw	a4,156(s1)
    800003b4:	fcf71ee3          	bne	a4,a5,80000390 <consoleintr+0xd4>
    800003b8:	6902                	ld	s2,0(sp)
    800003ba:	bf15                	j	800002ee <consoleintr+0x32>
    800003bc:	6902                	ld	s2,0(sp)
    800003be:	bf05                	j	800002ee <consoleintr+0x32>
    800003c0:	6902                	ld	s2,0(sp)
    800003c2:	b735                	j	800002ee <consoleintr+0x32>
    if (cons.e != cons.w) {
    800003c4:	00012717          	auipc	a4,0x12
    800003c8:	1cc70713          	addi	a4,a4,460 # 80012590 <cons>
    800003cc:	0a072783          	lw	a5,160(a4)
    800003d0:	09c72703          	lw	a4,156(a4)
    800003d4:	f0f70de3          	beq	a4,a5,800002ee <consoleintr+0x32>
      cons.e--;
    800003d8:	37fd                	addiw	a5,a5,-1
    800003da:	00012717          	auipc	a4,0x12
    800003de:	24f72b23          	sw	a5,598(a4) # 80012630 <cons+0xa0>
      consputc(BACKSPACE);
    800003e2:	10000513          	li	a0,256
    800003e6:	ea5ff0ef          	jal	8000028a <consputc>
    800003ea:	b711                	j	800002ee <consoleintr+0x32>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800003ec:	f00481e3          	beqz	s1,800002ee <consoleintr+0x32>
    800003f0:	bf31                	j	8000030c <consoleintr+0x50>
      consputc(c);
    800003f2:	4529                	li	a0,10
    800003f4:	e97ff0ef          	jal	8000028a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003f8:	00012797          	auipc	a5,0x12
    800003fc:	19878793          	addi	a5,a5,408 # 80012590 <cons>
    80000400:	0a07a703          	lw	a4,160(a5)
    80000404:	0017069b          	addiw	a3,a4,1
    80000408:	8636                	mv	a2,a3
    8000040a:	0ad7a023          	sw	a3,160(a5)
    8000040e:	07f77713          	andi	a4,a4,127
    80000412:	97ba                	add	a5,a5,a4
    80000414:	4729                	li	a4,10
    80000416:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000041a:	00012797          	auipc	a5,0x12
    8000041e:	20c7a923          	sw	a2,530(a5) # 8001262c <cons+0x9c>
        wakeup(&cons.r);
    80000422:	00012517          	auipc	a0,0x12
    80000426:	20650513          	addi	a0,a0,518 # 80012628 <cons+0x98>
    8000042a:	399010ef          	jal	80001fc2 <wakeup>
    8000042e:	b5c1                	j	800002ee <consoleintr+0x32>

0000000080000430 <consoleinit>:

void
consoleinit(void)
{
    80000430:	1141                	addi	sp,sp,-16
    80000432:	e406                	sd	ra,8(sp)
    80000434:	e022                	sd	s0,0(sp)
    80000436:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000438:	00007597          	auipc	a1,0x7
    8000043c:	bc858593          	addi	a1,a1,-1080 # 80007000 <etext>
    80000440:	00012517          	auipc	a0,0x12
    80000444:	15050513          	addi	a0,a0,336 # 80012590 <cons>
    80000448:	760000ef          	jal	80000ba8 <initlock>

  uartinit();
    8000044c:	448000ef          	jal	80000894 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000450:	00022797          	auipc	a5,0x22
    80000454:	2b078793          	addi	a5,a5,688 # 80022700 <devsw>
    80000458:	00000717          	auipc	a4,0x0
    8000045c:	d2070713          	addi	a4,a4,-736 # 80000178 <consoleread>
    80000460:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000462:	00000717          	auipc	a4,0x0
    80000466:	c7470713          	addi	a4,a4,-908 # 800000d6 <consolewrite>
    8000046a:	ef98                	sd	a4,24(a5)
}
    8000046c:	60a2                	ld	ra,8(sp)
    8000046e:	6402                	ld	s0,0(sp)
    80000470:	0141                	addi	sp,sp,16
    80000472:	8082                	ret

0000000080000474 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000474:	7139                	addi	sp,sp,-64
    80000476:	fc06                	sd	ra,56(sp)
    80000478:	f822                	sd	s0,48(sp)
    8000047a:	f04a                	sd	s2,32(sp)
    8000047c:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if (sign && (sign = (xx < 0)))
    8000047e:	c219                	beqz	a2,80000484 <printint+0x10>
    80000480:	08054163          	bltz	a0,80000502 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80000484:	4301                	li	t1,0

  i = 0;
    80000486:	fc840913          	addi	s2,s0,-56
    x = xx;
    8000048a:	86ca                	mv	a3,s2
  i = 0;
    8000048c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    8000048e:	00007817          	auipc	a6,0x7
    80000492:	3ba80813          	addi	a6,a6,954 # 80007848 <digits>
    80000496:	88ba                	mv	a7,a4
    80000498:	0017061b          	addiw	a2,a4,1
    8000049c:	8732                	mv	a4,a2
    8000049e:	02b577b3          	remu	a5,a0,a1
    800004a2:	97c2                	add	a5,a5,a6
    800004a4:	0007c783          	lbu	a5,0(a5)
    800004a8:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
    800004ac:	87aa                	mv	a5,a0
    800004ae:	02b55533          	divu	a0,a0,a1
    800004b2:	0685                	addi	a3,a3,1
    800004b4:	feb7f1e3          	bgeu	a5,a1,80000496 <printint+0x22>

  if (sign)
    800004b8:	00030c63          	beqz	t1,800004d0 <printint+0x5c>
    buf[i++] = '-';
    800004bc:	fe060793          	addi	a5,a2,-32
    800004c0:	00878633          	add	a2,a5,s0
    800004c4:	02d00793          	li	a5,45
    800004c8:	fef60423          	sb	a5,-24(a2)
    800004cc:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
    800004d0:	02e05463          	blez	a4,800004f8 <printint+0x84>
    800004d4:	f426                	sd	s1,40(sp)
    800004d6:	377d                	addiw	a4,a4,-1
    800004d8:	00e904b3          	add	s1,s2,a4
    800004dc:	197d                	addi	s2,s2,-1
    800004de:	993a                	add	s2,s2,a4
    800004e0:	1702                	slli	a4,a4,0x20
    800004e2:	9301                	srli	a4,a4,0x20
    800004e4:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004e8:	0004c503          	lbu	a0,0(s1)
    800004ec:	d9fff0ef          	jal	8000028a <consputc>
  while (--i >= 0)
    800004f0:	14fd                	addi	s1,s1,-1
    800004f2:	ff249be3          	bne	s1,s2,800004e8 <printint+0x74>
    800004f6:	74a2                	ld	s1,40(sp)
}
    800004f8:	70e2                	ld	ra,56(sp)
    800004fa:	7442                	ld	s0,48(sp)
    800004fc:	7902                	ld	s2,32(sp)
    800004fe:	6121                	addi	sp,sp,64
    80000500:	8082                	ret
    x = -xx;
    80000502:	40a00533          	neg	a0,a0
  if (sign && (sign = (xx < 0)))
    80000506:	4305                	li	t1,1
    x = -xx;
    80000508:	bfbd                	j	80000486 <printint+0x12>

000000008000050a <printk>:
}

// Print to the console.
int
printk(char *fmt, ...)
{
    8000050a:	7131                	addi	sp,sp,-192
    8000050c:	fc86                	sd	ra,120(sp)
    8000050e:	f8a2                	sd	s0,112(sp)
    80000510:	f0ca                	sd	s2,96(sp)
    80000512:	0100                	addi	s0,sp,128
    80000514:	892a                	mv	s2,a0
    80000516:	e40c                	sd	a1,8(s0)
    80000518:	e810                	sd	a2,16(s0)
    8000051a:	ec14                	sd	a3,24(s0)
    8000051c:	f018                	sd	a4,32(s0)
    8000051e:	f41c                	sd	a5,40(s0)
    80000520:	03043823          	sd	a6,48(s0)
    80000524:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if (panicking == 0)
    80000528:	0000a797          	auipc	a5,0xa
    8000052c:	02c7a783          	lw	a5,44(a5) # 8000a554 <panicking>
    80000530:	cf9d                	beqz	a5,8000056e <printk+0x64>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000532:	00840793          	addi	a5,s0,8
    80000536:	f8f43423          	sd	a5,-120(s0)
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    8000053a:	00094503          	lbu	a0,0(s2)
    8000053e:	22050663          	beqz	a0,8000076a <printk+0x260>
    80000542:	f4a6                	sd	s1,104(sp)
    80000544:	ecce                	sd	s3,88(sp)
    80000546:	e8d2                	sd	s4,80(sp)
    80000548:	e4d6                	sd	s5,72(sp)
    8000054a:	e0da                	sd	s6,64(sp)
    8000054c:	fc5e                	sd	s7,56(sp)
    8000054e:	f862                	sd	s8,48(sp)
    80000550:	f06a                	sd	s10,32(sp)
    80000552:	ec6e                	sd	s11,24(sp)
    80000554:	4a01                	li	s4,0
    if (cx != '%') {
    80000556:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if (c0 == 'u') {
    8000055a:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if (c0 == 'x') {
    8000055e:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if (c0 == 'p') {
    80000562:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    80000566:	4b29                	li	s6,10
    if (c0 == 'd') {
    80000568:	06400b93          	li	s7,100
    8000056c:	a015                	j	80000590 <printk+0x86>
    acquire(&pr.lock);
    8000056e:	00012517          	auipc	a0,0x12
    80000572:	0ca50513          	addi	a0,a0,202 # 80012638 <pr>
    80000576:	6b2000ef          	jal	80000c28 <acquire>
    8000057a:	bf65                	j	80000532 <printk+0x28>
      consputc(cx);
    8000057c:	d0fff0ef          	jal	8000028a <consputc>
      continue;
    80000580:	84d2                	mv	s1,s4
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000582:	2485                	addiw	s1,s1,1
    80000584:	8a26                	mv	s4,s1
    80000586:	94ca                	add	s1,s1,s2
    80000588:	0004c503          	lbu	a0,0(s1)
    8000058c:	1c050663          	beqz	a0,80000758 <printk+0x24e>
    if (cx != '%') {
    80000590:	ff3516e3          	bne	a0,s3,8000057c <printk+0x72>
    i++;
    80000594:	001a079b          	addiw	a5,s4,1
    80000598:	84be                	mv	s1,a5
    c0 = fmt[i + 0] & 0xff;
    8000059a:	00f90733          	add	a4,s2,a5
    8000059e:	00074a83          	lbu	s5,0(a4)
    if (c0)
    800005a2:	200a8963          	beqz	s5,800007b4 <printk+0x2aa>
      c1 = fmt[i + 1] & 0xff;
    800005a6:	00174683          	lbu	a3,1(a4)
    if (c1)
    800005aa:	1e068c63          	beqz	a3,800007a2 <printk+0x298>
    if (c0 == 'd') {
    800005ae:	037a8863          	beq	s5,s7,800005de <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    800005b2:	f94a8713          	addi	a4,s5,-108
    800005b6:	00173713          	seqz	a4,a4
    800005ba:	f9c68613          	addi	a2,a3,-100
    800005be:	ee05                	bnez	a2,800005f6 <printk+0xec>
    800005c0:	cb1d                	beqz	a4,800005f6 <printk+0xec>
      printint(va_arg(ap, uint64), 10, 1);
    800005c2:	f8843783          	ld	a5,-120(s0)
    800005c6:	00878713          	addi	a4,a5,8
    800005ca:	f8e43423          	sd	a4,-120(s0)
    800005ce:	4605                	li	a2,1
    800005d0:	85da                	mv	a1,s6
    800005d2:	6388                	ld	a0,0(a5)
    800005d4:	ea1ff0ef          	jal	80000474 <printint>
      i += 1;
    800005d8:	002a049b          	addiw	s1,s4,2
    800005dc:	b75d                	j	80000582 <printk+0x78>
      printint(va_arg(ap, int), 10, 1);
    800005de:	f8843783          	ld	a5,-120(s0)
    800005e2:	00878713          	addi	a4,a5,8
    800005e6:	f8e43423          	sd	a4,-120(s0)
    800005ea:	4605                	li	a2,1
    800005ec:	85da                	mv	a1,s6
    800005ee:	4388                	lw	a0,0(a5)
    800005f0:	e85ff0ef          	jal	80000474 <printint>
    800005f4:	b779                	j	80000582 <printk+0x78>
      c2 = fmt[i + 2] & 0xff;
    800005f6:	97ca                	add	a5,a5,s2
    800005f8:	8636                	mv	a2,a3
    800005fa:	0027c683          	lbu	a3,2(a5)
    800005fe:	a2c9                	j	800007c0 <printk+0x2b6>
      printint(va_arg(ap, uint64), 10, 1);
    80000600:	f8843783          	ld	a5,-120(s0)
    80000604:	00878713          	addi	a4,a5,8
    80000608:	f8e43423          	sd	a4,-120(s0)
    8000060c:	4605                	li	a2,1
    8000060e:	45a9                	li	a1,10
    80000610:	6388                	ld	a0,0(a5)
    80000612:	e63ff0ef          	jal	80000474 <printint>
      i += 2;
    80000616:	003a049b          	addiw	s1,s4,3
    8000061a:	b7a5                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint32), 10, 0);
    8000061c:	f8843783          	ld	a5,-120(s0)
    80000620:	00878713          	addi	a4,a5,8
    80000624:	f8e43423          	sd	a4,-120(s0)
    80000628:	4601                	li	a2,0
    8000062a:	85da                	mv	a1,s6
    8000062c:	0007e503          	lwu	a0,0(a5)
    80000630:	e45ff0ef          	jal	80000474 <printint>
    80000634:	b7b9                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000636:	f8843783          	ld	a5,-120(s0)
    8000063a:	00878713          	addi	a4,a5,8
    8000063e:	f8e43423          	sd	a4,-120(s0)
    80000642:	4601                	li	a2,0
    80000644:	85da                	mv	a1,s6
    80000646:	6388                	ld	a0,0(a5)
    80000648:	e2dff0ef          	jal	80000474 <printint>
      i += 1;
    8000064c:	002a049b          	addiw	s1,s4,2
    80000650:	bf0d                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000652:	f8843783          	ld	a5,-120(s0)
    80000656:	00878713          	addi	a4,a5,8
    8000065a:	f8e43423          	sd	a4,-120(s0)
    8000065e:	4601                	li	a2,0
    80000660:	45a9                	li	a1,10
    80000662:	6388                	ld	a0,0(a5)
    80000664:	e11ff0ef          	jal	80000474 <printint>
      i += 2;
    80000668:	003a049b          	addiw	s1,s4,3
    8000066c:	bf19                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint32), 16, 0);
    8000066e:	f8843783          	ld	a5,-120(s0)
    80000672:	00878713          	addi	a4,a5,8
    80000676:	f8e43423          	sd	a4,-120(s0)
    8000067a:	4601                	li	a2,0
    8000067c:	45c1                	li	a1,16
    8000067e:	0007e503          	lwu	a0,0(a5)
    80000682:	df3ff0ef          	jal	80000474 <printint>
    80000686:	bdf5                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000688:	f8843783          	ld	a5,-120(s0)
    8000068c:	00878713          	addi	a4,a5,8
    80000690:	f8e43423          	sd	a4,-120(s0)
    80000694:	45c1                	li	a1,16
    80000696:	6388                	ld	a0,0(a5)
    80000698:	dddff0ef          	jal	80000474 <printint>
      i += 1;
    8000069c:	002a049b          	addiw	s1,s4,2
    800006a0:	b5cd                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    800006a2:	f8843783          	ld	a5,-120(s0)
    800006a6:	00878713          	addi	a4,a5,8
    800006aa:	f8e43423          	sd	a4,-120(s0)
    800006ae:	4601                	li	a2,0
    800006b0:	45c1                	li	a1,16
    800006b2:	6388                	ld	a0,0(a5)
    800006b4:	dc1ff0ef          	jal	80000474 <printint>
      i += 2;
    800006b8:	003a049b          	addiw	s1,s4,3
    800006bc:	b5d9                	j	80000582 <printk+0x78>
    800006be:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006c0:	f8843783          	ld	a5,-120(s0)
    800006c4:	00878713          	addi	a4,a5,8
    800006c8:	f8e43423          	sd	a4,-120(s0)
    800006cc:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006d0:	03000513          	li	a0,48
    800006d4:	bb7ff0ef          	jal	8000028a <consputc>
  consputc('x');
    800006d8:	07800513          	li	a0,120
    800006dc:	bafff0ef          	jal	8000028a <consputc>
    800006e0:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006e2:	00007c97          	auipc	s9,0x7
    800006e6:	166c8c93          	addi	s9,s9,358 # 80007848 <digits>
    800006ea:	03cad793          	srli	a5,s5,0x3c
    800006ee:	97e6                	add	a5,a5,s9
    800006f0:	0007c503          	lbu	a0,0(a5)
    800006f4:	b97ff0ef          	jal	8000028a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006f8:	0a92                	slli	s5,s5,0x4
    800006fa:	3a7d                	addiw	s4,s4,-1
    800006fc:	fe0a17e3          	bnez	s4,800006ea <printk+0x1e0>
    80000700:	7ca2                	ld	s9,40(sp)
    80000702:	b541                	j	80000582 <printk+0x78>
    } else if (c0 == 'c') {
      consputc(va_arg(ap, uint));
    80000704:	f8843783          	ld	a5,-120(s0)
    80000708:	00878713          	addi	a4,a5,8
    8000070c:	f8e43423          	sd	a4,-120(s0)
    80000710:	4388                	lw	a0,0(a5)
    80000712:	b79ff0ef          	jal	8000028a <consputc>
    80000716:	b5b5                	j	80000582 <printk+0x78>
    } else if (c0 == 's') {
      if ((s = va_arg(ap, char *)) == 0)
    80000718:	f8843783          	ld	a5,-120(s0)
    8000071c:	00878713          	addi	a4,a5,8
    80000720:	f8e43423          	sd	a4,-120(s0)
    80000724:	0007ba03          	ld	s4,0(a5)
    80000728:	000a0d63          	beqz	s4,80000742 <printk+0x238>
        s = "(null)";
      for (; *s; s++)
    8000072c:	000a4503          	lbu	a0,0(s4)
    80000730:	e40509e3          	beqz	a0,80000582 <printk+0x78>
        consputc(*s);
    80000734:	b57ff0ef          	jal	8000028a <consputc>
      for (; *s; s++)
    80000738:	0a05                	addi	s4,s4,1
    8000073a:	000a4503          	lbu	a0,0(s4)
    8000073e:	f97d                	bnez	a0,80000734 <printk+0x22a>
    80000740:	b589                	j	80000582 <printk+0x78>
        s = "(null)";
    80000742:	00007a17          	auipc	s4,0x7
    80000746:	8c6a0a13          	addi	s4,s4,-1850 # 80007008 <etext+0x8>
      for (; *s; s++)
    8000074a:	02800513          	li	a0,40
    8000074e:	b7dd                	j	80000734 <printk+0x22a>
    } else if (c0 == '%') {
      consputc('%');
    80000750:	8556                	mv	a0,s5
    80000752:	b39ff0ef          	jal	8000028a <consputc>
    80000756:	b535                	j	80000582 <printk+0x78>
    80000758:	74a6                	ld	s1,104(sp)
    8000075a:	69e6                	ld	s3,88(sp)
    8000075c:	6a46                	ld	s4,80(sp)
    8000075e:	6aa6                	ld	s5,72(sp)
    80000760:	6b06                	ld	s6,64(sp)
    80000762:	7be2                	ld	s7,56(sp)
    80000764:	7c42                	ld	s8,48(sp)
    80000766:	7d02                	ld	s10,32(sp)
    80000768:	6de2                	ld	s11,24(sp)
      consputc(c0);
    }
  }
  va_end(ap);

  if (panicking == 0)
    8000076a:	0000a797          	auipc	a5,0xa
    8000076e:	dea7a783          	lw	a5,-534(a5) # 8000a554 <panicking>
    80000772:	c38d                	beqz	a5,80000794 <printk+0x28a>
    release(&pr.lock);

  return 0;
}
    80000774:	4501                	li	a0,0
    80000776:	70e6                	ld	ra,120(sp)
    80000778:	7446                	ld	s0,112(sp)
    8000077a:	7906                	ld	s2,96(sp)
    8000077c:	6129                	addi	sp,sp,192
    8000077e:	8082                	ret
    80000780:	74a6                	ld	s1,104(sp)
    80000782:	69e6                	ld	s3,88(sp)
    80000784:	6a46                	ld	s4,80(sp)
    80000786:	6aa6                	ld	s5,72(sp)
    80000788:	6b06                	ld	s6,64(sp)
    8000078a:	7be2                	ld	s7,56(sp)
    8000078c:	7c42                	ld	s8,48(sp)
    8000078e:	7d02                	ld	s10,32(sp)
    80000790:	6de2                	ld	s11,24(sp)
    80000792:	bfe1                	j	8000076a <printk+0x260>
    release(&pr.lock);
    80000794:	00012517          	auipc	a0,0x12
    80000798:	ea450513          	addi	a0,a0,-348 # 80012638 <pr>
    8000079c:	514000ef          	jal	80000cb0 <release>
  return 0;
    800007a0:	bfd1                	j	80000774 <printk+0x26a>
    if (c0 == 'd') {
    800007a2:	e37a8ee3          	beq	s5,s7,800005de <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    800007a6:	f94a8713          	addi	a4,s5,-108
    800007aa:	00173713          	seqz	a4,a4
    800007ae:	8636                	mv	a2,a3
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    800007b0:	4781                	li	a5,0
    800007b2:	a00d                	j	800007d4 <printk+0x2ca>
    } else if (c0 == 'l' && c1 == 'd') {
    800007b4:	f94a8713          	addi	a4,s5,-108
    800007b8:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    800007bc:	8656                	mv	a2,s5
    800007be:	86d6                	mv	a3,s5
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    800007c0:	f9460793          	addi	a5,a2,-108
    800007c4:	0017b793          	seqz	a5,a5
    800007c8:	8ff9                	and	a5,a5,a4
    800007ca:	f9c68593          	addi	a1,a3,-100
    800007ce:	e199                	bnez	a1,800007d4 <printk+0x2ca>
    800007d0:	e20798e3          	bnez	a5,80000600 <printk+0xf6>
    } else if (c0 == 'u') {
    800007d4:	e58a84e3          	beq	s5,s8,8000061c <printk+0x112>
    } else if (c0 == 'l' && c1 == 'u') {
    800007d8:	f8b60593          	addi	a1,a2,-117
    800007dc:	e199                	bnez	a1,800007e2 <printk+0x2d8>
    800007de:	e4071ce3          	bnez	a4,80000636 <printk+0x12c>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    800007e2:	f8b68593          	addi	a1,a3,-117
    800007e6:	e199                	bnez	a1,800007ec <printk+0x2e2>
    800007e8:	e60795e3          	bnez	a5,80000652 <printk+0x148>
    } else if (c0 == 'x') {
    800007ec:	e9aa81e3          	beq	s5,s10,8000066e <printk+0x164>
    } else if (c0 == 'l' && c1 == 'x') {
    800007f0:	f8860613          	addi	a2,a2,-120
    800007f4:	e219                	bnez	a2,800007fa <printk+0x2f0>
    800007f6:	e80719e3          	bnez	a4,80000688 <printk+0x17e>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    800007fa:	f8868693          	addi	a3,a3,-120
    800007fe:	e299                	bnez	a3,80000804 <printk+0x2fa>
    80000800:	ea0791e3          	bnez	a5,800006a2 <printk+0x198>
    } else if (c0 == 'p') {
    80000804:	ebba8de3          	beq	s5,s11,800006be <printk+0x1b4>
    } else if (c0 == 'c') {
    80000808:	06300793          	li	a5,99
    8000080c:	eefa8ce3          	beq	s5,a5,80000704 <printk+0x1fa>
    } else if (c0 == 's') {
    80000810:	07300793          	li	a5,115
    80000814:	f0fa82e3          	beq	s5,a5,80000718 <printk+0x20e>
    } else if (c0 == '%') {
    80000818:	02500793          	li	a5,37
    8000081c:	f2fa8ae3          	beq	s5,a5,80000750 <printk+0x246>
    } else if (c0 == 0) {
    80000820:	f60a80e3          	beqz	s5,80000780 <printk+0x276>
      consputc('%');
    80000824:	02500513          	li	a0,37
    80000828:	a63ff0ef          	jal	8000028a <consputc>
      consputc(c0);
    8000082c:	8556                	mv	a0,s5
    8000082e:	a5dff0ef          	jal	8000028a <consputc>
    80000832:	bb81                	j	80000582 <printk+0x78>

0000000080000834 <panic>:

void
panic(char *s)
{
    80000834:	1101                	addi	sp,sp,-32
    80000836:	ec06                	sd	ra,24(sp)
    80000838:	e822                	sd	s0,16(sp)
    8000083a:	e426                	sd	s1,8(sp)
    8000083c:	e04a                	sd	s2,0(sp)
    8000083e:	1000                	addi	s0,sp,32
    80000840:	892a                	mv	s2,a0
  panicking = 1;
    80000842:	4485                	li	s1,1
    80000844:	0000a797          	auipc	a5,0xa
    80000848:	d097a823          	sw	s1,-752(a5) # 8000a554 <panicking>
  printk("panic: ");
    8000084c:	00006517          	auipc	a0,0x6
    80000850:	7cc50513          	addi	a0,a0,1996 # 80007018 <etext+0x18>
    80000854:	cb7ff0ef          	jal	8000050a <printk>
  printk("%s\n", s);
    80000858:	85ca                	mv	a1,s2
    8000085a:	00006517          	auipc	a0,0x6
    8000085e:	7c650513          	addi	a0,a0,1990 # 80007020 <etext+0x20>
    80000862:	ca9ff0ef          	jal	8000050a <printk>
  panicked = 1; // freeze uart output from other CPUs
    80000866:	0000a797          	auipc	a5,0xa
    8000086a:	ce97a523          	sw	s1,-790(a5) # 8000a550 <panicked>
  for (;;)
    8000086e:	a001                	j	8000086e <panic+0x3a>

0000000080000870 <printkinit>:
    ;
}

void
printkinit(void)
{
    80000870:	1141                	addi	sp,sp,-16
    80000872:	e406                	sd	ra,8(sp)
    80000874:	e022                	sd	s0,0(sp)
    80000876:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000878:	00006597          	auipc	a1,0x6
    8000087c:	7b058593          	addi	a1,a1,1968 # 80007028 <etext+0x28>
    80000880:	00012517          	auipc	a0,0x12
    80000884:	db850513          	addi	a0,a0,-584 # 80012638 <pr>
    80000888:	320000ef          	jal	80000ba8 <initlock>
}
    8000088c:	60a2                	ld	ra,8(sp)
    8000088e:	6402                	ld	s0,0(sp)
    80000890:	0141                	addi	sp,sp,16
    80000892:	8082                	ret

0000000080000894 <uartinit>:
extern volatile int panicking; // from printk.c
extern volatile int panicked;  // from printk.c

void
uartinit(void)
{
    80000894:	1141                	addi	sp,sp,-16
    80000896:	e406                	sd	ra,8(sp)
    80000898:	e022                	sd	s0,0(sp)
    8000089a:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000089c:	100007b7          	lui	a5,0x10000
    800008a0:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800008a4:	10000737          	lui	a4,0x10000
    800008a8:	f8000693          	li	a3,-128
    800008ac:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008b0:	468d                	li	a3,3
    800008b2:	10000637          	lui	a2,0x10000
    800008b6:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008ba:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008be:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008c2:	8732                	mv	a4,a2
    800008c4:	461d                	li	a2,7
    800008c6:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008ca:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    800008ce:	00006597          	auipc	a1,0x6
    800008d2:	76258593          	addi	a1,a1,1890 # 80007030 <etext+0x30>
    800008d6:	00012517          	auipc	a0,0x12
    800008da:	d7a50513          	addi	a0,a0,-646 # 80012650 <tx_lock>
    800008de:	2ca000ef          	jal	80000ba8 <initlock>
}
    800008e2:	60a2                	ld	ra,8(sp)
    800008e4:	6402                	ld	s0,0(sp)
    800008e6:	0141                	addi	sp,sp,16
    800008e8:	8082                	ret

00000000800008ea <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008ea:	715d                	addi	sp,sp,-80
    800008ec:	e486                	sd	ra,72(sp)
    800008ee:	e0a2                	sd	s0,64(sp)
    800008f0:	fc26                	sd	s1,56(sp)
    800008f2:	ec56                	sd	s5,24(sp)
    800008f4:	0880                	addi	s0,sp,80
    800008f6:	8aaa                	mv	s5,a0
    800008f8:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008fa:	00012517          	auipc	a0,0x12
    800008fe:	d5650513          	addi	a0,a0,-682 # 80012650 <tx_lock>
    80000902:	326000ef          	jal	80000c28 <acquire>

  int i = 0;
  while (i < n) {
    80000906:	06905963          	blez	s1,80000978 <uartwrite+0x8e>
    8000090a:	f84a                	sd	s2,48(sp)
    8000090c:	f44e                	sd	s3,40(sp)
    8000090e:	f052                	sd	s4,32(sp)
    80000910:	e85a                	sd	s6,16(sp)
    80000912:	e45e                	sd	s7,8(sp)
    80000914:	8a56                	mv	s4,s5
    80000916:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    80000918:	0000a917          	auipc	s2,0xa
    8000091c:	c4490913          	addi	s2,s2,-956 # 8000a55c <tx_busy>
      // wait for a UART interrupt to set tx_busy to 0.
      sleep_prepare(&tx_chan);
    80000920:	0000a997          	auipc	s3,0xa
    80000924:	c3898993          	addi	s3,s3,-968 # 8000a558 <tx_chan>
      release(&tx_lock);
    80000928:	00012497          	auipc	s1,0x12
    8000092c:	d2848493          	addi	s1,s1,-728 # 80012650 <tx_lock>
      sleep();
      acquire(&tx_lock);
    }
    WriteReg(THR, buf[i]);
    80000930:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    80000934:	4b05                	li	s6,1
    80000936:	a805                	j	80000966 <uartwrite+0x7c>
      sleep_prepare(&tx_chan);
    80000938:	854e                	mv	a0,s3
    8000093a:	61c010ef          	jal	80001f56 <sleep_prepare>
      release(&tx_lock);
    8000093e:	8526                	mv	a0,s1
    80000940:	370000ef          	jal	80000cb0 <release>
      sleep();
    80000944:	64e010ef          	jal	80001f92 <sleep>
      acquire(&tx_lock);
    80000948:	8526                	mv	a0,s1
    8000094a:	2de000ef          	jal	80000c28 <acquire>
    while(tx_busy != 0){
    8000094e:	00092783          	lw	a5,0(s2)
    80000952:	f3fd                	bnez	a5,80000938 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    80000954:	000a4783          	lbu	a5,0(s4)
    80000958:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    8000095c:	01692023          	sw	s6,0(s2)
  while (i < n) {
    80000960:	0a05                	addi	s4,s4,1
    80000962:	015a0663          	beq	s4,s5,8000096e <uartwrite+0x84>
    while(tx_busy != 0){
    80000966:	00092783          	lw	a5,0(s2)
    8000096a:	f7f9                	bnez	a5,80000938 <uartwrite+0x4e>
    8000096c:	b7e5                	j	80000954 <uartwrite+0x6a>
    8000096e:	7942                	ld	s2,48(sp)
    80000970:	79a2                	ld	s3,40(sp)
    80000972:	7a02                	ld	s4,32(sp)
    80000974:	6b42                	ld	s6,16(sp)
    80000976:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000978:	00012517          	auipc	a0,0x12
    8000097c:	cd850513          	addi	a0,a0,-808 # 80012650 <tx_lock>
    80000980:	330000ef          	jal	80000cb0 <release>
}
    80000984:	60a6                	ld	ra,72(sp)
    80000986:	6406                	ld	s0,64(sp)
    80000988:	74e2                	ld	s1,56(sp)
    8000098a:	6ae2                	ld	s5,24(sp)
    8000098c:	6161                	addi	sp,sp,80
    8000098e:	8082                	ret

0000000080000990 <uartputc_sync>:
// interrupts, for use by kernel printk() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80000990:	1101                	addi	sp,sp,-32
    80000992:	ec06                	sd	ra,24(sp)
    80000994:	e822                	sd	s0,16(sp)
    80000996:	e426                	sd	s1,8(sp)
    80000998:	1000                	addi	s0,sp,32
    8000099a:	84aa                	mv	s1,a0
  if (panicking == 0)
    8000099c:	0000a797          	auipc	a5,0xa
    800009a0:	bb87a783          	lw	a5,-1096(a5) # 8000a554 <panicking>
    800009a4:	cf95                	beqz	a5,800009e0 <uartputc_sync+0x50>
    push_off();

  if (panicked) {
    800009a6:	0000a797          	auipc	a5,0xa
    800009aa:	baa7a783          	lw	a5,-1110(a5) # 8000a550 <panicked>
    800009ae:	ef85                	bnez	a5,800009e6 <uartputc_sync+0x56>
    for (;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800009b0:	10000737          	lui	a4,0x10000
    800009b4:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    800009b6:	00074783          	lbu	a5,0(a4)
    800009ba:	0207f793          	andi	a5,a5,32
    800009be:	dfe5                	beqz	a5,800009b6 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    800009c0:	0ff4f513          	zext.b	a0,s1
    800009c4:	100007b7          	lui	a5,0x10000
    800009c8:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if (panicking == 0)
    800009cc:	0000a797          	auipc	a5,0xa
    800009d0:	b887a783          	lw	a5,-1144(a5) # 8000a554 <panicking>
    800009d4:	cb91                	beqz	a5,800009e8 <uartputc_sync+0x58>
    pop_off();
}
    800009d6:	60e2                	ld	ra,24(sp)
    800009d8:	6442                	ld	s0,16(sp)
    800009da:	64a2                	ld	s1,8(sp)
    800009dc:	6105                	addi	sp,sp,32
    800009de:	8082                	ret
    push_off();
    800009e0:	20e000ef          	jal	80000bee <push_off>
    800009e4:	b7c9                	j	800009a6 <uartputc_sync+0x16>
    for (;;)
    800009e6:	a001                	j	800009e6 <uartputc_sync+0x56>
    pop_off();
    800009e8:	280000ef          	jal	80000c68 <pop_off>
}
    800009ec:	b7ed                	j	800009d6 <uartputc_sync+0x46>

00000000800009ee <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009ee:	1101                	addi	sp,sp,-32
    800009f0:	ec06                	sd	ra,24(sp)
    800009f2:	e822                	sd	s0,16(sp)
    800009f4:	e426                	sd	s1,8(sp)
    800009f6:	e04a                	sd	s2,0(sp)
    800009f8:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009fa:	100007b7          	lui	a5,0x10000
    800009fe:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  acquire(&tx_lock);
    80000a02:	00012517          	auipc	a0,0x12
    80000a06:	c4e50513          	addi	a0,a0,-946 # 80012650 <tx_lock>
    80000a0a:	21e000ef          	jal	80000c28 <acquire>
  if (ReadReg(LSR) & LSR_TX_IDLE) {
    80000a0e:	100007b7          	lui	a5,0x10000
    80000a12:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000a16:	0207f793          	andi	a5,a5,32
    80000a1a:	e78d                	bnez	a5,80000a44 <uartintr+0x56>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    80000a1c:	00012517          	auipc	a0,0x12
    80000a20:	c3450513          	addi	a0,a0,-972 # 80012650 <tx_lock>
    80000a24:	28c000ef          	jal	80000cb0 <release>
  if (ReadReg(LSR) & LSR_RX_READY) {
    80000a28:	100004b7          	lui	s1,0x10000
    80000a2c:	0495                	addi	s1,s1,5 # 10000005 <_entry-0x6ffffffb>
    return ReadReg(RHR);
    80000a2e:	10000937          	lui	s2,0x10000
  if (ReadReg(LSR) & LSR_RX_READY) {
    80000a32:	0004c783          	lbu	a5,0(s1)
    80000a36:	8b85                	andi	a5,a5,1
    80000a38:	c38d                	beqz	a5,80000a5a <uartintr+0x6c>
    return ReadReg(RHR);
    80000a3a:	00094503          	lbu	a0,0(s2) # 10000000 <_entry-0x70000000>
  // read and process incoming characters, if any.
  while (1) {
    int c = uartgetc();
    if (c == -1)
      break;
    consoleintr(c);
    80000a3e:	87fff0ef          	jal	800002bc <consoleintr>
  while (1) {
    80000a42:	bfc5                	j	80000a32 <uartintr+0x44>
    tx_busy = 0;
    80000a44:	0000a797          	auipc	a5,0xa
    80000a48:	b007ac23          	sw	zero,-1256(a5) # 8000a55c <tx_busy>
    wakeup(&tx_chan);
    80000a4c:	0000a517          	auipc	a0,0xa
    80000a50:	b0c50513          	addi	a0,a0,-1268 # 8000a558 <tx_chan>
    80000a54:	56e010ef          	jal	80001fc2 <wakeup>
    80000a58:	b7d1                	j	80000a1c <uartintr+0x2e>
  }
}
    80000a5a:	60e2                	ld	ra,24(sp)
    80000a5c:	6442                	ld	s0,16(sp)
    80000a5e:	64a2                	ld	s1,8(sp)
    80000a60:	6902                	ld	s2,0(sp)
    80000a62:	6105                	addi	sp,sp,32
    80000a64:	8082                	ret

0000000080000a66 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a66:	1101                	addi	sp,sp,-32
    80000a68:	ec06                	sd	ra,24(sp)
    80000a6a:	e822                	sd	s0,16(sp)
    80000a6c:	e426                	sd	s1,8(sp)
    80000a6e:	e04a                	sd	s2,0(sp)
    80000a70:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    80000a72:	00023797          	auipc	a5,0x23
    80000a76:	e4e78793          	addi	a5,a5,-434 # 800238c0 <end>
    80000a7a:	00f53733          	sltu	a4,a0,a5
    80000a7e:	47c5                	li	a5,17
    80000a80:	07ee                	slli	a5,a5,0x1b
    80000a82:	17fd                	addi	a5,a5,-1
    80000a84:	00a7b7b3          	sltu	a5,a5,a0
    80000a88:	8fd9                	or	a5,a5,a4
    80000a8a:	ef95                	bnez	a5,80000ac6 <kfree+0x60>
    80000a8c:	84aa                	mv	s1,a0
    80000a8e:	03451793          	slli	a5,a0,0x34
    80000a92:	eb95                	bnez	a5,80000ac6 <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a94:	6605                	lui	a2,0x1
    80000a96:	4585                	li	a1,1
    80000a98:	250000ef          	jal	80000ce8 <memset>

  r = (struct run *)pa;

  acquire(&kmem.lock);
    80000a9c:	00012917          	auipc	s2,0x12
    80000aa0:	bcc90913          	addi	s2,s2,-1076 # 80012668 <kmem>
    80000aa4:	854a                	mv	a0,s2
    80000aa6:	182000ef          	jal	80000c28 <acquire>
  r->next = kmem.freelist;
    80000aaa:	01893783          	ld	a5,24(s2)
    80000aae:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000ab0:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000ab4:	854a                	mv	a0,s2
    80000ab6:	1fa000ef          	jal	80000cb0 <release>
}
    80000aba:	60e2                	ld	ra,24(sp)
    80000abc:	6442                	ld	s0,16(sp)
    80000abe:	64a2                	ld	s1,8(sp)
    80000ac0:	6902                	ld	s2,0(sp)
    80000ac2:	6105                	addi	sp,sp,32
    80000ac4:	8082                	ret
    panic("kfree");
    80000ac6:	00006517          	auipc	a0,0x6
    80000aca:	57250513          	addi	a0,a0,1394 # 80007038 <etext+0x38>
    80000ace:	d67ff0ef          	jal	80000834 <panic>

0000000080000ad2 <freerange>:
{
    80000ad2:	7179                	addi	sp,sp,-48
    80000ad4:	f406                	sd	ra,40(sp)
    80000ad6:	f022                	sd	s0,32(sp)
    80000ad8:	ec26                	sd	s1,24(sp)
    80000ada:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000adc:	6785                	lui	a5,0x1
    80000ade:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000ae2:	00e504b3          	add	s1,a0,a4
    80000ae6:	777d                	lui	a4,0xfffff
    80000ae8:	8cf9                	and	s1,s1,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000aea:	94be                	add	s1,s1,a5
    80000aec:	0295e263          	bltu	a1,s1,80000b10 <freerange+0x3e>
    80000af0:	e84a                	sd	s2,16(sp)
    80000af2:	e44e                	sd	s3,8(sp)
    80000af4:	e052                	sd	s4,0(sp)
    80000af6:	892e                	mv	s2,a1
    kfree(p);
    80000af8:	8a3a                	mv	s4,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000afa:	89be                	mv	s3,a5
    kfree(p);
    80000afc:	01448533          	add	a0,s1,s4
    80000b00:	f67ff0ef          	jal	80000a66 <kfree>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000b04:	94ce                	add	s1,s1,s3
    80000b06:	fe997be3          	bgeu	s2,s1,80000afc <freerange+0x2a>
    80000b0a:	6942                	ld	s2,16(sp)
    80000b0c:	69a2                	ld	s3,8(sp)
    80000b0e:	6a02                	ld	s4,0(sp)
}
    80000b10:	70a2                	ld	ra,40(sp)
    80000b12:	7402                	ld	s0,32(sp)
    80000b14:	64e2                	ld	s1,24(sp)
    80000b16:	6145                	addi	sp,sp,48
    80000b18:	8082                	ret

0000000080000b1a <kinit>:
{
    80000b1a:	1141                	addi	sp,sp,-16
    80000b1c:	e406                	sd	ra,8(sp)
    80000b1e:	e022                	sd	s0,0(sp)
    80000b20:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b22:	00006597          	auipc	a1,0x6
    80000b26:	51e58593          	addi	a1,a1,1310 # 80007040 <etext+0x40>
    80000b2a:	00012517          	auipc	a0,0x12
    80000b2e:	b3e50513          	addi	a0,a0,-1218 # 80012668 <kmem>
    80000b32:	076000ef          	jal	80000ba8 <initlock>
  freerange(end, (void *)PHYSTOP);
    80000b36:	45c5                	li	a1,17
    80000b38:	05ee                	slli	a1,a1,0x1b
    80000b3a:	00023517          	auipc	a0,0x23
    80000b3e:	d8650513          	addi	a0,a0,-634 # 800238c0 <end>
    80000b42:	f91ff0ef          	jal	80000ad2 <freerange>
}
    80000b46:	60a2                	ld	ra,8(sp)
    80000b48:	6402                	ld	s0,0(sp)
    80000b4a:	0141                	addi	sp,sp,16
    80000b4c:	8082                	ret

0000000080000b4e <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b4e:	1101                	addi	sp,sp,-32
    80000b50:	ec06                	sd	ra,24(sp)
    80000b52:	e822                	sd	s0,16(sp)
    80000b54:	e426                	sd	s1,8(sp)
    80000b56:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b58:	00012517          	auipc	a0,0x12
    80000b5c:	b1050513          	addi	a0,a0,-1264 # 80012668 <kmem>
    80000b60:	0c8000ef          	jal	80000c28 <acquire>
  r = kmem.freelist;
    80000b64:	00012497          	auipc	s1,0x12
    80000b68:	b1c4b483          	ld	s1,-1252(s1) # 80012680 <kmem+0x18>
  if (r)
    80000b6c:	c49d                	beqz	s1,80000b9a <kalloc+0x4c>
    kmem.freelist = r->next;
    80000b6e:	609c                	ld	a5,0(s1)
    80000b70:	00012717          	auipc	a4,0x12
    80000b74:	b0f73823          	sd	a5,-1264(a4) # 80012680 <kmem+0x18>
  release(&kmem.lock);
    80000b78:	00012517          	auipc	a0,0x12
    80000b7c:	af050513          	addi	a0,a0,-1296 # 80012668 <kmem>
    80000b80:	130000ef          	jal	80000cb0 <release>

  if (r)
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000b84:	6605                	lui	a2,0x1
    80000b86:	4595                	li	a1,5
    80000b88:	8526                	mv	a0,s1
    80000b8a:	15e000ef          	jal	80000ce8 <memset>
  return (void *)r;
}
    80000b8e:	8526                	mv	a0,s1
    80000b90:	60e2                	ld	ra,24(sp)
    80000b92:	6442                	ld	s0,16(sp)
    80000b94:	64a2                	ld	s1,8(sp)
    80000b96:	6105                	addi	sp,sp,32
    80000b98:	8082                	ret
  release(&kmem.lock);
    80000b9a:	00012517          	auipc	a0,0x12
    80000b9e:	ace50513          	addi	a0,a0,-1330 # 80012668 <kmem>
    80000ba2:	10e000ef          	jal	80000cb0 <release>
  if (r)
    80000ba6:	b7e5                	j	80000b8e <kalloc+0x40>

0000000080000ba8 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000ba8:	1141                	addi	sp,sp,-16
    80000baa:	e406                	sd	ra,8(sp)
    80000bac:	e022                	sd	s0,0(sp)
    80000bae:	0800                	addi	s0,sp,16
  lk->name = name;
    80000bb0:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000bb2:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000bb6:	00053823          	sd	zero,16(a0)
}
    80000bba:	60a2                	ld	ra,8(sp)
    80000bbc:	6402                	ld	s0,0(sp)
    80000bbe:	0141                	addi	sp,sp,16
    80000bc0:	8082                	ret

0000000080000bc2 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000bc2:	411c                	lw	a5,0(a0)
    80000bc4:	e399                	bnez	a5,80000bca <holding+0x8>
    80000bc6:	4501                	li	a0,0
  return r;
}
    80000bc8:	8082                	ret
{
    80000bca:	1101                	addi	sp,sp,-32
    80000bcc:	ec06                	sd	ra,24(sp)
    80000bce:	e822                	sd	s0,16(sp)
    80000bd0:	e426                	sd	s1,8(sp)
    80000bd2:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000bd4:	691c                	ld	a5,16(a0)
    80000bd6:	84be                	mv	s1,a5
    80000bd8:	555000ef          	jal	8000192c <mycpu>
    80000bdc:	40a48533          	sub	a0,s1,a0
    80000be0:	00153513          	seqz	a0,a0
}
    80000be4:	60e2                	ld	ra,24(sp)
    80000be6:	6442                	ld	s0,16(sp)
    80000be8:	64a2                	ld	s1,8(sp)
    80000bea:	6105                	addi	sp,sp,32
    80000bec:	8082                	ret

0000000080000bee <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000bee:	1101                	addi	sp,sp,-32
    80000bf0:	ec06                	sd	ra,24(sp)
    80000bf2:	e822                	sd	s0,16(sp)
    80000bf4:	e426                	sd	s1,8(sp)
    80000bf6:	1000                	addi	s0,sp,32
  __asm__ __volatile__("csrrc %0, sstatus, %1" : "=r"(x) : "rK"(x) : "memory");
    80000bf8:	100177f3          	csrrci	a5,sstatus,2
    80000bfc:	84be                	mv	s1,a5
  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  uint64 flags = rc_sstatus(SSTATUS_SIE);
  int old = !!(flags & SSTATUS_SIE);

  if (mycpu()->noff == 0)
    80000bfe:	52f000ef          	jal	8000192c <mycpu>
    80000c02:	5d3c                	lw	a5,120(a0)
    80000c04:	cb99                	beqz	a5,80000c1a <push_off+0x2c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000c06:	527000ef          	jal	8000192c <mycpu>
    80000c0a:	5d3c                	lw	a5,120(a0)
    80000c0c:	2785                	addiw	a5,a5,1
    80000c0e:	dd3c                	sw	a5,120(a0)
}
    80000c10:	60e2                	ld	ra,24(sp)
    80000c12:	6442                	ld	s0,16(sp)
    80000c14:	64a2                	ld	s1,8(sp)
    80000c16:	6105                	addi	sp,sp,32
    80000c18:	8082                	ret
    mycpu()->intena = old;
    80000c1a:	513000ef          	jal	8000192c <mycpu>
  int old = !!(flags & SSTATUS_SIE);
    80000c1e:	0014d793          	srli	a5,s1,0x1
    80000c22:	8b85                	andi	a5,a5,1
    mycpu()->intena = old;
    80000c24:	dd7c                	sw	a5,124(a0)
    80000c26:	b7c5                	j	80000c06 <push_off+0x18>

0000000080000c28 <acquire>:
{
    80000c28:	1101                	addi	sp,sp,-32
    80000c2a:	ec06                	sd	ra,24(sp)
    80000c2c:	e822                	sd	s0,16(sp)
    80000c2e:	e426                	sd	s1,8(sp)
    80000c30:	1000                	addi	s0,sp,32
    80000c32:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c34:	fbbff0ef          	jal	80000bee <push_off>
  if (holding(lk))
    80000c38:	8526                	mv	a0,s1
    80000c3a:	f89ff0ef          	jal	80000bc2 <holding>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000c3e:	4705                	li	a4,1
  if (holding(lk))
    80000c40:	ed11                	bnez	a0,80000c5c <acquire+0x34>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000c42:	87ba                	mv	a5,a4
    80000c44:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c48:	2781                	sext.w	a5,a5
    80000c4a:	ffe5                	bnez	a5,80000c42 <acquire+0x1a>
  lk->cpu = mycpu();
    80000c4c:	4e1000ef          	jal	8000192c <mycpu>
    80000c50:	e888                	sd	a0,16(s1)
}
    80000c52:	60e2                	ld	ra,24(sp)
    80000c54:	6442                	ld	s0,16(sp)
    80000c56:	64a2                	ld	s1,8(sp)
    80000c58:	6105                	addi	sp,sp,32
    80000c5a:	8082                	ret
    panic("acquire");
    80000c5c:	00006517          	auipc	a0,0x6
    80000c60:	3ec50513          	addi	a0,a0,1004 # 80007048 <etext+0x48>
    80000c64:	bd1ff0ef          	jal	80000834 <panic>

0000000080000c68 <pop_off>:

void
pop_off(void)
{
    80000c68:	1141                	addi	sp,sp,-16
    80000c6a:	e406                	sd	ra,8(sp)
    80000c6c:	e022                	sd	s0,0(sp)
    80000c6e:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c70:	4bd000ef          	jal	8000192c <mycpu>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000c74:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c78:	8b89                	andi	a5,a5,2
  if (intr_get())
    80000c7a:	ef99                	bnez	a5,80000c98 <pop_off+0x30>
    panic("pop_off - interruptible");
  if (c->noff < 1)
    80000c7c:	5d3c                	lw	a5,120(a0)
    80000c7e:	02f05363          	blez	a5,80000ca4 <pop_off+0x3c>
    panic("pop_off");
  c->noff -= 1;
    80000c82:	37fd                	addiw	a5,a5,-1
    80000c84:	dd3c                	sw	a5,120(a0)
  if (c->noff == 0 && c->intena)
    80000c86:	e789                	bnez	a5,80000c90 <pop_off+0x28>
    80000c88:	5d7c                	lw	a5,124(a0)
    80000c8a:	c399                	beqz	a5,80000c90 <pop_off+0x28>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80000c8c:	10016073          	csrsi	sstatus,2
    intr_on();
}
    80000c90:	60a2                	ld	ra,8(sp)
    80000c92:	6402                	ld	s0,0(sp)
    80000c94:	0141                	addi	sp,sp,16
    80000c96:	8082                	ret
    panic("pop_off - interruptible");
    80000c98:	00006517          	auipc	a0,0x6
    80000c9c:	3b850513          	addi	a0,a0,952 # 80007050 <etext+0x50>
    80000ca0:	b95ff0ef          	jal	80000834 <panic>
    panic("pop_off");
    80000ca4:	00006517          	auipc	a0,0x6
    80000ca8:	3c450513          	addi	a0,a0,964 # 80007068 <etext+0x68>
    80000cac:	b89ff0ef          	jal	80000834 <panic>

0000000080000cb0 <release>:
{
    80000cb0:	1101                	addi	sp,sp,-32
    80000cb2:	ec06                	sd	ra,24(sp)
    80000cb4:	e822                	sd	s0,16(sp)
    80000cb6:	e426                	sd	s1,8(sp)
    80000cb8:	1000                	addi	s0,sp,32
    80000cba:	84aa                	mv	s1,a0
  if (!holding(lk))
    80000cbc:	f07ff0ef          	jal	80000bc2 <holding>
    80000cc0:	cd11                	beqz	a0,80000cdc <release+0x2c>
  lk->cpu = 0;
    80000cc2:	0004b823          	sd	zero,16(s1)
  __atomic_store_n(&lk->locked, 0, __ATOMIC_RELEASE);
    80000cc6:	0310000f          	fence	rw,w
    80000cca:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000cce:	f9bff0ef          	jal	80000c68 <pop_off>
}
    80000cd2:	60e2                	ld	ra,24(sp)
    80000cd4:	6442                	ld	s0,16(sp)
    80000cd6:	64a2                	ld	s1,8(sp)
    80000cd8:	6105                	addi	sp,sp,32
    80000cda:	8082                	ret
    panic("release");
    80000cdc:	00006517          	auipc	a0,0x6
    80000ce0:	39450513          	addi	a0,a0,916 # 80007070 <etext+0x70>
    80000ce4:	b51ff0ef          	jal	80000834 <panic>

0000000080000ce8 <memset>:
#include "types.h"

void *
memset(void *dst, int c, uint n)
{
    80000ce8:	1141                	addi	sp,sp,-16
    80000cea:	e406                	sd	ra,8(sp)
    80000cec:	e022                	sd	s0,0(sp)
    80000cee:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    80000cf0:	ca19                	beqz	a2,80000d06 <memset+0x1e>
    80000cf2:	87aa                	mv	a5,a0
    80000cf4:	1602                	slli	a2,a2,0x20
    80000cf6:	9201                	srli	a2,a2,0x20
    80000cf8:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000cfc:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    80000d00:	0785                	addi	a5,a5,1
    80000d02:	fee79de3          	bne	a5,a4,80000cfc <memset+0x14>
  }
  return dst;
}
    80000d06:	60a2                	ld	ra,8(sp)
    80000d08:	6402                	ld	s0,0(sp)
    80000d0a:	0141                	addi	sp,sp,16
    80000d0c:	8082                	ret

0000000080000d0e <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d0e:	1141                	addi	sp,sp,-16
    80000d10:	e406                	sd	ra,8(sp)
    80000d12:	e022                	sd	s0,0(sp)
    80000d14:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while (n-- > 0) {
    80000d16:	c61d                	beqz	a2,80000d44 <memcmp+0x36>
    80000d18:	1602                	slli	a2,a2,0x20
    80000d1a:	9201                	srli	a2,a2,0x20
    80000d1c:	00c506b3          	add	a3,a0,a2
    if (*s1 != *s2)
    80000d20:	00054783          	lbu	a5,0(a0)
    80000d24:	0005c703          	lbu	a4,0(a1)
    80000d28:	00e79863          	bne	a5,a4,80000d38 <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    80000d2c:	0505                	addi	a0,a0,1
    80000d2e:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    80000d30:	fed518e3          	bne	a0,a3,80000d20 <memcmp+0x12>
  }

  return 0;
    80000d34:	4501                	li	a0,0
    80000d36:	a019                	j	80000d3c <memcmp+0x2e>
      return *s1 - *s2;
    80000d38:	40e7853b          	subw	a0,a5,a4
}
    80000d3c:	60a2                	ld	ra,8(sp)
    80000d3e:	6402                	ld	s0,0(sp)
    80000d40:	0141                	addi	sp,sp,16
    80000d42:	8082                	ret
  return 0;
    80000d44:	4501                	li	a0,0
    80000d46:	bfdd                	j	80000d3c <memcmp+0x2e>

0000000080000d48 <memmove>:

void *
memmove(void *dst, const void *src, uint n)
{
    80000d48:	1141                	addi	sp,sp,-16
    80000d4a:	e406                	sd	ra,8(sp)
    80000d4c:	e022                	sd	s0,0(sp)
    80000d4e:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if (n == 0)
    80000d50:	c205                	beqz	a2,80000d70 <memmove+0x28>
    return dst;

  s = src;
  d = dst;
  if (s < d && s + n > d) {
    80000d52:	02a5e363          	bltu	a1,a0,80000d78 <memmove+0x30>
    s += n;
    d += n;
    while (n-- > 0)
      *--d = *--s;
  } else
    while (n-- > 0)
    80000d56:	1602                	slli	a2,a2,0x20
    80000d58:	9201                	srli	a2,a2,0x20
    80000d5a:	00c587b3          	add	a5,a1,a2
{
    80000d5e:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d60:	0585                	addi	a1,a1,1
    80000d62:	0705                	addi	a4,a4,1
    80000d64:	fff5c683          	lbu	a3,-1(a1)
    80000d68:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    80000d6c:	feb79ae3          	bne	a5,a1,80000d60 <memmove+0x18>

  return dst;
}
    80000d70:	60a2                	ld	ra,8(sp)
    80000d72:	6402                	ld	s0,0(sp)
    80000d74:	0141                	addi	sp,sp,16
    80000d76:	8082                	ret
  if (s < d && s + n > d) {
    80000d78:	02061693          	slli	a3,a2,0x20
    80000d7c:	9281                	srli	a3,a3,0x20
    80000d7e:	00d58733          	add	a4,a1,a3
    80000d82:	fce57ae3          	bgeu	a0,a4,80000d56 <memmove+0xe>
    d += n;
    80000d86:	96aa                	add	a3,a3,a0
    while (n-- > 0)
    80000d88:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000d8c:	1782                	slli	a5,a5,0x20
    80000d8e:	9381                	srli	a5,a5,0x20
    80000d90:	fff7c793          	not	a5,a5
    80000d94:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d96:	177d                	addi	a4,a4,-1
    80000d98:	16fd                	addi	a3,a3,-1
    80000d9a:	00074603          	lbu	a2,0(a4)
    80000d9e:	00c68023          	sb	a2,0(a3)
    while (n-- > 0)
    80000da2:	fee79ae3          	bne	a5,a4,80000d96 <memmove+0x4e>
    80000da6:	b7e9                	j	80000d70 <memmove+0x28>

0000000080000da8 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void *
memcpy(void *dst, const void *src, uint n)
{
    80000da8:	1141                	addi	sp,sp,-16
    80000daa:	e406                	sd	ra,8(sp)
    80000dac:	e022                	sd	s0,0(sp)
    80000dae:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000db0:	f99ff0ef          	jal	80000d48 <memmove>
}
    80000db4:	60a2                	ld	ra,8(sp)
    80000db6:	6402                	ld	s0,0(sp)
    80000db8:	0141                	addi	sp,sp,16
    80000dba:	8082                	ret

0000000080000dbc <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000dbc:	1141                	addi	sp,sp,-16
    80000dbe:	e406                	sd	ra,8(sp)
    80000dc0:	e022                	sd	s0,0(sp)
    80000dc2:	0800                	addi	s0,sp,16
  while (n > 0 && *p && *p == *q)
    80000dc4:	ce11                	beqz	a2,80000de0 <strncmp+0x24>
    80000dc6:	00054783          	lbu	a5,0(a0)
    80000dca:	cf89                	beqz	a5,80000de4 <strncmp+0x28>
    80000dcc:	0005c703          	lbu	a4,0(a1)
    80000dd0:	00f71a63          	bne	a4,a5,80000de4 <strncmp+0x28>
    n--, p++, q++;
    80000dd4:	367d                	addiw	a2,a2,-1
    80000dd6:	0505                	addi	a0,a0,1
    80000dd8:	0585                	addi	a1,a1,1
  while (n > 0 && *p && *p == *q)
    80000dda:	f675                	bnez	a2,80000dc6 <strncmp+0xa>
  if (n == 0)
    return 0;
    80000ddc:	4501                	li	a0,0
    80000dde:	a801                	j	80000dee <strncmp+0x32>
    80000de0:	4501                	li	a0,0
    80000de2:	a031                	j	80000dee <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    80000de4:	00054503          	lbu	a0,0(a0)
    80000de8:	0005c783          	lbu	a5,0(a1)
    80000dec:	9d1d                	subw	a0,a0,a5
}
    80000dee:	60a2                	ld	ra,8(sp)
    80000df0:	6402                	ld	s0,0(sp)
    80000df2:	0141                	addi	sp,sp,16
    80000df4:	8082                	ret

0000000080000df6 <strncpy>:

char *
strncpy(char *s, const char *t, int n)
{
    80000df6:	1141                	addi	sp,sp,-16
    80000df8:	e406                	sd	ra,8(sp)
    80000dfa:	e022                	sd	s0,0(sp)
    80000dfc:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while (n-- > 0 && (*s++ = *t++) != 0)
    80000dfe:	87aa                	mv	a5,a0
    80000e00:	a011                	j	80000e04 <strncpy+0xe>
    80000e02:	8636                	mv	a2,a3
    80000e04:	02c05863          	blez	a2,80000e34 <strncpy+0x3e>
    80000e08:	fff6069b          	addiw	a3,a2,-1
    80000e0c:	8836                	mv	a6,a3
    80000e0e:	0785                	addi	a5,a5,1
    80000e10:	0005c703          	lbu	a4,0(a1)
    80000e14:	fee78fa3          	sb	a4,-1(a5)
    80000e18:	0585                	addi	a1,a1,1
    80000e1a:	f765                	bnez	a4,80000e02 <strncpy+0xc>
    ;
  while (n-- > 0)
    80000e1c:	873e                	mv	a4,a5
    80000e1e:	01005b63          	blez	a6,80000e34 <strncpy+0x3e>
    80000e22:	9fb1                	addw	a5,a5,a2
    80000e24:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000e26:	0705                	addi	a4,a4,1
    80000e28:	fe070fa3          	sb	zero,-1(a4)
  while (n-- > 0)
    80000e2c:	40e786bb          	subw	a3,a5,a4
    80000e30:	fed04be3          	bgtz	a3,80000e26 <strncpy+0x30>
  return os;
}
    80000e34:	60a2                	ld	ra,8(sp)
    80000e36:	6402                	ld	s0,0(sp)
    80000e38:	0141                	addi	sp,sp,16
    80000e3a:	8082                	ret

0000000080000e3c <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char *
safestrcpy(char *s, const char *t, int n)
{
    80000e3c:	1141                	addi	sp,sp,-16
    80000e3e:	e406                	sd	ra,8(sp)
    80000e40:	e022                	sd	s0,0(sp)
    80000e42:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if (n <= 0)
    80000e44:	02c05363          	blez	a2,80000e6a <safestrcpy+0x2e>
    80000e48:	fff6069b          	addiw	a3,a2,-1
    80000e4c:	1682                	slli	a3,a3,0x20
    80000e4e:	9281                	srli	a3,a3,0x20
    80000e50:	96ae                	add	a3,a3,a1
    80000e52:	87aa                	mv	a5,a0
    return os;
  while (--n > 0 && (*s++ = *t++) != 0)
    80000e54:	00d58963          	beq	a1,a3,80000e66 <safestrcpy+0x2a>
    80000e58:	0585                	addi	a1,a1,1
    80000e5a:	0785                	addi	a5,a5,1
    80000e5c:	fff5c703          	lbu	a4,-1(a1)
    80000e60:	fee78fa3          	sb	a4,-1(a5)
    80000e64:	fb65                	bnez	a4,80000e54 <safestrcpy+0x18>
    ;
  *s = 0;
    80000e66:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e6a:	60a2                	ld	ra,8(sp)
    80000e6c:	6402                	ld	s0,0(sp)
    80000e6e:	0141                	addi	sp,sp,16
    80000e70:	8082                	ret

0000000080000e72 <strlen>:

int
strlen(const char *s)
{
    80000e72:	1141                	addi	sp,sp,-16
    80000e74:	e406                	sd	ra,8(sp)
    80000e76:	e022                	sd	s0,0(sp)
    80000e78:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    80000e7a:	00054783          	lbu	a5,0(a0)
    80000e7e:	cf91                	beqz	a5,80000e9a <strlen+0x28>
    80000e80:	00150793          	addi	a5,a0,1
    80000e84:	86be                	mv	a3,a5
    80000e86:	0785                	addi	a5,a5,1
    80000e88:	fff7c703          	lbu	a4,-1(a5)
    80000e8c:	ff65                	bnez	a4,80000e84 <strlen+0x12>
    80000e8e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000e92:	60a2                	ld	ra,8(sp)
    80000e94:	6402                	ld	s0,0(sp)
    80000e96:	0141                	addi	sp,sp,16
    80000e98:	8082                	ret
  for (n = 0; s[n]; n++)
    80000e9a:	4501                	li	a0,0
    80000e9c:	bfdd                	j	80000e92 <strlen+0x20>

0000000080000e9e <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e9e:	1141                	addi	sp,sp,-16
    80000ea0:	e406                	sd	ra,8(sp)
    80000ea2:	e022                	sd	s0,0(sp)
    80000ea4:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80000ea6:	273000ef          	jal	80001918 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();         // first user process

    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
  } else {
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000eaa:	00009717          	auipc	a4,0x9
    80000eae:	6b670713          	addi	a4,a4,1718 # 8000a560 <started>
  if (cpuid() == 0) {
    80000eb2:	c51d                	beqz	a0,80000ee0 <main+0x42>
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000eb4:	431c                	lw	a5,0(a4)
    80000eb6:	0230000f          	fence	r,rw
    80000eba:	2781                	sext.w	a5,a5
    80000ebc:	dfe5                	beqz	a5,80000eb4 <main+0x16>
      ;

    printk("hart %d starting\n", cpuid());
    80000ebe:	25b000ef          	jal	80001918 <cpuid>
    80000ec2:	85aa                	mv	a1,a0
    80000ec4:	00006517          	auipc	a0,0x6
    80000ec8:	1d450513          	addi	a0,a0,468 # 80007098 <etext+0x98>
    80000ecc:	e3eff0ef          	jal	8000050a <printk>
    kvminithart();  // turn on paging
    80000ed0:	086000ef          	jal	80000f56 <kvminithart>
    trapinithart(); // install kernel trap vector
    80000ed4:	5de010ef          	jal	800024b2 <trapinithart>
    plicinithart(); // ask PLIC for device interrupts
    80000ed8:	011040ef          	jal	800056e8 <plicinithart>
  }

  scheduler();
    80000edc:	6df000ef          	jal	80001dba <scheduler>
    consoleinit();
    80000ee0:	d50ff0ef          	jal	80000430 <consoleinit>
    printkinit();
    80000ee4:	98dff0ef          	jal	80000870 <printkinit>
    printk("\n");
    80000ee8:	00006517          	auipc	a0,0x6
    80000eec:	19050513          	addi	a0,a0,400 # 80007078 <etext+0x78>
    80000ef0:	e1aff0ef          	jal	8000050a <printk>
    printk("xv6 kernel is booting\n");
    80000ef4:	00006517          	auipc	a0,0x6
    80000ef8:	18c50513          	addi	a0,a0,396 # 80007080 <etext+0x80>
    80000efc:	e0eff0ef          	jal	8000050a <printk>
    printk("\n");
    80000f00:	00006517          	auipc	a0,0x6
    80000f04:	17850513          	addi	a0,a0,376 # 80007078 <etext+0x78>
    80000f08:	e02ff0ef          	jal	8000050a <printk>
    kinit();            // physical page allocator
    80000f0c:	c0fff0ef          	jal	80000b1a <kinit>
    kvminit();          // create kernel page table
    80000f10:	2d2000ef          	jal	800011e2 <kvminit>
    kvminithart();      // turn on paging
    80000f14:	042000ef          	jal	80000f56 <kvminithart>
    procinit();         // process table
    80000f18:	14b000ef          	jal	80001862 <procinit>
    qlock_test_init();
    80000f1c:	74b040ef          	jal	80005e66 <qlock_test_init>
    trapinit();         // trap vectors
    80000f20:	56e010ef          	jal	8000248e <trapinit>
    trapinithart();     // install kernel trap vector
    80000f24:	58e010ef          	jal	800024b2 <trapinithart>
    plicinit();         // set up interrupt controller
    80000f28:	7a6040ef          	jal	800056ce <plicinit>
    plicinithart();     // ask PLIC for device interrupts
    80000f2c:	7bc040ef          	jal	800056e8 <plicinithart>
    binit();            // buffer cache
    80000f30:	485010ef          	jal	80002bb4 <binit>
    iinit();            // inode table
    80000f34:	1d6020ef          	jal	8000310a <iinit>
    fileinit();         // file table
    80000f38:	204030ef          	jal	8000413c <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f3c:	0a3040ef          	jal	800057de <virtio_disk_init>
    userinit();         // first user process
    80000f40:	4cf000ef          	jal	80001c0e <userinit>
    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
    80000f44:	00009797          	auipc	a5,0x9
    80000f48:	61c78793          	addi	a5,a5,1564 # 8000a560 <started>
    80000f4c:	4705                	li	a4,1
    80000f4e:	0310000f          	fence	rw,w
    80000f52:	c398                	sw	a4,0(a5)
    80000f54:	b761                	j	80000edc <main+0x3e>

0000000080000f56 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000f56:	1141                	addi	sp,sp,-16
    80000f58:	e406                	sd	ra,8(sp)
    80000f5a:	e022                	sd	s0,0(sp)
    80000f5c:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000f5e:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f62:	00009797          	auipc	a5,0x9
    80000f66:	6067b783          	ld	a5,1542(a5) # 8000a568 <kernel_pagetable>
    80000f6a:	83b1                	srli	a5,a5,0xc
    80000f6c:	577d                	li	a4,-1
    80000f6e:	177e                	slli	a4,a4,0x3f
    80000f70:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80000f72:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000f76:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f7a:	60a2                	ld	ra,8(sp)
    80000f7c:	6402                	ld	s0,0(sp)
    80000f7e:	0141                	addi	sp,sp,16
    80000f80:	8082                	ret

0000000080000f82 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f82:	7139                	addi	sp,sp,-64
    80000f84:	fc06                	sd	ra,56(sp)
    80000f86:	f822                	sd	s0,48(sp)
    80000f88:	f426                	sd	s1,40(sp)
    80000f8a:	f04a                	sd	s2,32(sp)
    80000f8c:	ec4e                	sd	s3,24(sp)
    80000f8e:	e852                	sd	s4,16(sp)
    80000f90:	e456                	sd	s5,8(sp)
    80000f92:	e05a                	sd	s6,0(sp)
    80000f94:	0080                	addi	s0,sp,64
    80000f96:	84aa                	mv	s1,a0
    80000f98:	89ae                	mv	s3,a1
    80000f9a:	8b32                	mv	s6,a2
  if (va >= MAXVA)
    80000f9c:	57fd                	li	a5,-1
    80000f9e:	83e9                	srli	a5,a5,0x1a
    80000fa0:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--) {
    80000fa2:	4ab1                	li	s5,12
  if (va >= MAXVA)
    80000fa4:	04b7e263          	bltu	a5,a1,80000fe8 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    80000fa8:	0149d933          	srl	s2,s3,s4
    80000fac:	1ff97913          	andi	s2,s2,511
    80000fb0:	090e                	slli	s2,s2,0x3
    80000fb2:	9926                	add	s2,s2,s1
    if (*pte & PTE_V) {
    80000fb4:	00093483          	ld	s1,0(s2)
    80000fb8:	0014f793          	andi	a5,s1,1
    80000fbc:	cf85                	beqz	a5,80000ff4 <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000fbe:	80a9                	srli	s1,s1,0xa
    80000fc0:	04b2                	slli	s1,s1,0xc
  for (int level = 2; level > 0; level--) {
    80000fc2:	3a5d                	addiw	s4,s4,-9
    80000fc4:	ff5a12e3          	bne	s4,s5,80000fa8 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000fc8:	00c9d513          	srli	a0,s3,0xc
    80000fcc:	1ff57513          	andi	a0,a0,511
    80000fd0:	050e                	slli	a0,a0,0x3
    80000fd2:	9526                	add	a0,a0,s1
}
    80000fd4:	70e2                	ld	ra,56(sp)
    80000fd6:	7442                	ld	s0,48(sp)
    80000fd8:	74a2                	ld	s1,40(sp)
    80000fda:	7902                	ld	s2,32(sp)
    80000fdc:	69e2                	ld	s3,24(sp)
    80000fde:	6a42                	ld	s4,16(sp)
    80000fe0:	6aa2                	ld	s5,8(sp)
    80000fe2:	6b02                	ld	s6,0(sp)
    80000fe4:	6121                	addi	sp,sp,64
    80000fe6:	8082                	ret
    panic("walk");
    80000fe8:	00006517          	auipc	a0,0x6
    80000fec:	0c850513          	addi	a0,a0,200 # 800070b0 <etext+0xb0>
    80000ff0:	845ff0ef          	jal	80000834 <panic>
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    80000ff4:	020b0263          	beqz	s6,80001018 <walk+0x96>
    80000ff8:	b57ff0ef          	jal	80000b4e <kalloc>
    80000ffc:	84aa                	mv	s1,a0
    80000ffe:	d979                	beqz	a0,80000fd4 <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    80001000:	6605                	lui	a2,0x1
    80001002:	4581                	li	a1,0
    80001004:	ce5ff0ef          	jal	80000ce8 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80001008:	00c4d793          	srli	a5,s1,0xc
    8000100c:	07aa                	slli	a5,a5,0xa
    8000100e:	0017e793          	ori	a5,a5,1
    80001012:	00f93023          	sd	a5,0(s2)
    80001016:	b775                	j	80000fc2 <walk+0x40>
        return 0;
    80001018:	4501                	li	a0,0
    8000101a:	bf6d                	j	80000fd4 <walk+0x52>

000000008000101c <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    8000101c:	57fd                	li	a5,-1
    8000101e:	83e9                	srli	a5,a5,0x1a
    80001020:	00b7f463          	bgeu	a5,a1,80001028 <walkaddr+0xc>
    return 0;
    80001024:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80001026:	8082                	ret
{
    80001028:	1141                	addi	sp,sp,-16
    8000102a:	e406                	sd	ra,8(sp)
    8000102c:	e022                	sd	s0,0(sp)
    8000102e:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80001030:	4601                	li	a2,0
    80001032:	f51ff0ef          	jal	80000f82 <walk>
  if (pte == 0)
    80001036:	c901                	beqz	a0,80001046 <walkaddr+0x2a>
  if ((*pte & PTE_V) == 0)
    80001038:	611c                	ld	a5,0(a0)
  if ((*pte & PTE_U) == 0)
    8000103a:	0117f693          	andi	a3,a5,17
    8000103e:	4745                	li	a4,17
    return 0;
    80001040:	4501                	li	a0,0
  if ((*pte & PTE_U) == 0)
    80001042:	00e68663          	beq	a3,a4,8000104e <walkaddr+0x32>
}
    80001046:	60a2                	ld	ra,8(sp)
    80001048:	6402                	ld	s0,0(sp)
    8000104a:	0141                	addi	sp,sp,16
    8000104c:	8082                	ret
  pa = PTE2PA(*pte);
    8000104e:	83a9                	srli	a5,a5,0xa
    80001050:	00c79513          	slli	a0,a5,0xc
  return pa;
    80001054:	bfcd                	j	80001046 <walkaddr+0x2a>

0000000080001056 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001056:	715d                	addi	sp,sp,-80
    80001058:	e486                	sd	ra,72(sp)
    8000105a:	e0a2                	sd	s0,64(sp)
    8000105c:	fc26                	sd	s1,56(sp)
    8000105e:	f84a                	sd	s2,48(sp)
    80001060:	f44e                	sd	s3,40(sp)
    80001062:	f052                	sd	s4,32(sp)
    80001064:	ec56                	sd	s5,24(sp)
    80001066:	e85a                	sd	s6,16(sp)
    80001068:	e45e                	sd	s7,8(sp)
    8000106a:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    8000106c:	03459793          	slli	a5,a1,0x34
    80001070:	eba1                	bnez	a5,800010c0 <mappages+0x6a>
    80001072:	8a2a                	mv	s4,a0
    80001074:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    80001076:	03461793          	slli	a5,a2,0x34
    8000107a:	eba9                	bnez	a5,800010cc <mappages+0x76>
    panic("mappages: size not aligned");

  if (size == 0)
    8000107c:	ce31                	beqz	a2,800010d8 <mappages+0x82>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    8000107e:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    80001082:	80060613          	addi	a2,a2,-2048
    80001086:	00b60933          	add	s2,a2,a1
  a = va;
    8000108a:	84ae                	mv	s1,a1
  for (;;) {
    if ((pte = walk(pagetable, a, 1)) == 0)
    8000108c:	4b05                	li	s6,1
    8000108e:	40b689b3          	sub	s3,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    80001092:	6b85                	lui	s7,0x1
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001094:	865a                	mv	a2,s6
    80001096:	85a6                	mv	a1,s1
    80001098:	8552                	mv	a0,s4
    8000109a:	ee9ff0ef          	jal	80000f82 <walk>
    8000109e:	c929                	beqz	a0,800010f0 <mappages+0x9a>
    if (*pte & PTE_V)
    800010a0:	611c                	ld	a5,0(a0)
    800010a2:	8b85                	andi	a5,a5,1
    800010a4:	e3a1                	bnez	a5,800010e4 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800010a6:	013487b3          	add	a5,s1,s3
    800010aa:	83b1                	srli	a5,a5,0xc
    800010ac:	07aa                	slli	a5,a5,0xa
    800010ae:	0157e7b3          	or	a5,a5,s5
    800010b2:	0017e793          	ori	a5,a5,1
    800010b6:	e11c                	sd	a5,0(a0)
    if (a == last)
    800010b8:	05248863          	beq	s1,s2,80001108 <mappages+0xb2>
    a += PGSIZE;
    800010bc:	94de                	add	s1,s1,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    800010be:	bfd9                	j	80001094 <mappages+0x3e>
    panic("mappages: va not aligned");
    800010c0:	00006517          	auipc	a0,0x6
    800010c4:	ff850513          	addi	a0,a0,-8 # 800070b8 <etext+0xb8>
    800010c8:	f6cff0ef          	jal	80000834 <panic>
    panic("mappages: size not aligned");
    800010cc:	00006517          	auipc	a0,0x6
    800010d0:	00c50513          	addi	a0,a0,12 # 800070d8 <etext+0xd8>
    800010d4:	f60ff0ef          	jal	80000834 <panic>
    panic("mappages: size");
    800010d8:	00006517          	auipc	a0,0x6
    800010dc:	02050513          	addi	a0,a0,32 # 800070f8 <etext+0xf8>
    800010e0:	f54ff0ef          	jal	80000834 <panic>
      panic("mappages: remap");
    800010e4:	00006517          	auipc	a0,0x6
    800010e8:	02450513          	addi	a0,a0,36 # 80007108 <etext+0x108>
    800010ec:	f48ff0ef          	jal	80000834 <panic>
      return -1;
    800010f0:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800010f2:	60a6                	ld	ra,72(sp)
    800010f4:	6406                	ld	s0,64(sp)
    800010f6:	74e2                	ld	s1,56(sp)
    800010f8:	7942                	ld	s2,48(sp)
    800010fa:	79a2                	ld	s3,40(sp)
    800010fc:	7a02                	ld	s4,32(sp)
    800010fe:	6ae2                	ld	s5,24(sp)
    80001100:	6b42                	ld	s6,16(sp)
    80001102:	6ba2                	ld	s7,8(sp)
    80001104:	6161                	addi	sp,sp,80
    80001106:	8082                	ret
  return 0;
    80001108:	4501                	li	a0,0
    8000110a:	b7e5                	j	800010f2 <mappages+0x9c>

000000008000110c <kvmmap>:
{
    8000110c:	1141                	addi	sp,sp,-16
    8000110e:	e406                	sd	ra,8(sp)
    80001110:	e022                	sd	s0,0(sp)
    80001112:	0800                	addi	s0,sp,16
    80001114:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001116:	86b2                	mv	a3,a2
    80001118:	863e                	mv	a2,a5
    8000111a:	f3dff0ef          	jal	80001056 <mappages>
    8000111e:	e509                	bnez	a0,80001128 <kvmmap+0x1c>
}
    80001120:	60a2                	ld	ra,8(sp)
    80001122:	6402                	ld	s0,0(sp)
    80001124:	0141                	addi	sp,sp,16
    80001126:	8082                	ret
    panic("kvmmap");
    80001128:	00006517          	auipc	a0,0x6
    8000112c:	ff050513          	addi	a0,a0,-16 # 80007118 <etext+0x118>
    80001130:	f04ff0ef          	jal	80000834 <panic>

0000000080001134 <kvmmake>:
{
    80001134:	1101                	addi	sp,sp,-32
    80001136:	ec06                	sd	ra,24(sp)
    80001138:	e822                	sd	s0,16(sp)
    8000113a:	e426                	sd	s1,8(sp)
    8000113c:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    8000113e:	a11ff0ef          	jal	80000b4e <kalloc>
    80001142:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001144:	6605                	lui	a2,0x1
    80001146:	4581                	li	a1,0
    80001148:	ba1ff0ef          	jal	80000ce8 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000114c:	4719                	li	a4,6
    8000114e:	6685                	lui	a3,0x1
    80001150:	10000637          	lui	a2,0x10000
    80001154:	85b2                	mv	a1,a2
    80001156:	8526                	mv	a0,s1
    80001158:	fb5ff0ef          	jal	8000110c <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    8000115c:	4719                	li	a4,6
    8000115e:	6685                	lui	a3,0x1
    80001160:	10001637          	lui	a2,0x10001
    80001164:	85b2                	mv	a1,a2
    80001166:	8526                	mv	a0,s1
    80001168:	fa5ff0ef          	jal	8000110c <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    8000116c:	4719                	li	a4,6
    8000116e:	040006b7          	lui	a3,0x4000
    80001172:	0c000637          	lui	a2,0xc000
    80001176:	85b2                	mv	a1,a2
    80001178:	8526                	mv	a0,s1
    8000117a:	f93ff0ef          	jal	8000110c <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    8000117e:	4729                	li	a4,10
    80001180:	80006697          	auipc	a3,0x80006
    80001184:	e8068693          	addi	a3,a3,-384 # 7000 <_entry-0x7fff9000>
    80001188:	4605                	li	a2,1
    8000118a:	067e                	slli	a2,a2,0x1f
    8000118c:	85b2                	mv	a1,a2
    8000118e:	8526                	mv	a0,s1
    80001190:	f7dff0ef          	jal	8000110c <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
    80001194:	4719                	li	a4,6
    80001196:	00006697          	auipc	a3,0x6
    8000119a:	e6a68693          	addi	a3,a3,-406 # 80007000 <etext>
    8000119e:	47c5                	li	a5,17
    800011a0:	07ee                	slli	a5,a5,0x1b
    800011a2:	40d786b3          	sub	a3,a5,a3
    800011a6:	00006617          	auipc	a2,0x6
    800011aa:	e5a60613          	addi	a2,a2,-422 # 80007000 <etext>
    800011ae:	85b2                	mv	a1,a2
    800011b0:	8526                	mv	a0,s1
    800011b2:	f5bff0ef          	jal	8000110c <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800011b6:	4729                	li	a4,10
    800011b8:	6685                	lui	a3,0x1
    800011ba:	00005617          	auipc	a2,0x5
    800011be:	e4660613          	addi	a2,a2,-442 # 80006000 <_trampoline>
    800011c2:	040005b7          	lui	a1,0x4000
    800011c6:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800011c8:	05b2                	slli	a1,a1,0xc
    800011ca:	8526                	mv	a0,s1
    800011cc:	f41ff0ef          	jal	8000110c <kvmmap>
  proc_mapstacks(kpgtbl);
    800011d0:	8526                	mv	a0,s1
    800011d2:	5ec000ef          	jal	800017be <proc_mapstacks>
}
    800011d6:	8526                	mv	a0,s1
    800011d8:	60e2                	ld	ra,24(sp)
    800011da:	6442                	ld	s0,16(sp)
    800011dc:	64a2                	ld	s1,8(sp)
    800011de:	6105                	addi	sp,sp,32
    800011e0:	8082                	ret

00000000800011e2 <kvminit>:
{
    800011e2:	1141                	addi	sp,sp,-16
    800011e4:	e406                	sd	ra,8(sp)
    800011e6:	e022                	sd	s0,0(sp)
    800011e8:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800011ea:	f4bff0ef          	jal	80001134 <kvmmake>
    800011ee:	00009797          	auipc	a5,0x9
    800011f2:	36a7bd23          	sd	a0,890(a5) # 8000a568 <kernel_pagetable>
}
    800011f6:	60a2                	ld	ra,8(sp)
    800011f8:	6402                	ld	s0,0(sp)
    800011fa:	0141                	addi	sp,sp,16
    800011fc:	8082                	ret

00000000800011fe <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800011fe:	1101                	addi	sp,sp,-32
    80001200:	ec06                	sd	ra,24(sp)
    80001202:	e822                	sd	s0,16(sp)
    80001204:	e426                	sd	s1,8(sp)
    80001206:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    80001208:	947ff0ef          	jal	80000b4e <kalloc>
    8000120c:	84aa                	mv	s1,a0
  if (pagetable == 0)
    8000120e:	c509                	beqz	a0,80001218 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80001210:	6605                	lui	a2,0x1
    80001212:	4581                	li	a1,0
    80001214:	ad5ff0ef          	jal	80000ce8 <memset>
  return pagetable;
}
    80001218:	8526                	mv	a0,s1
    8000121a:	60e2                	ld	ra,24(sp)
    8000121c:	6442                	ld	s0,16(sp)
    8000121e:	64a2                	ld	s1,8(sp)
    80001220:	6105                	addi	sp,sp,32
    80001222:	8082                	ret

0000000080001224 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    80001224:	7139                	addi	sp,sp,-64
    80001226:	fc06                	sd	ra,56(sp)
    80001228:	f822                	sd	s0,48(sp)
    8000122a:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    8000122c:	03459793          	slli	a5,a1,0x34
    80001230:	e38d                	bnez	a5,80001252 <uvmunmap+0x2e>
    80001232:	f04a                	sd	s2,32(sp)
    80001234:	ec4e                	sd	s3,24(sp)
    80001236:	e852                	sd	s4,16(sp)
    80001238:	e456                	sd	s5,8(sp)
    8000123a:	e05a                	sd	s6,0(sp)
    8000123c:	8a2a                	mv	s4,a0
    8000123e:	892e                	mv	s2,a1
    80001240:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80001242:	0632                	slli	a2,a2,0xc
    80001244:	00b609b3          	add	s3,a2,a1
    80001248:	6b05                	lui	s6,0x1
    8000124a:	0535f963          	bgeu	a1,s3,8000129c <uvmunmap+0x78>
    8000124e:	f426                	sd	s1,40(sp)
    80001250:	a015                	j	80001274 <uvmunmap+0x50>
    80001252:	f426                	sd	s1,40(sp)
    80001254:	f04a                	sd	s2,32(sp)
    80001256:	ec4e                	sd	s3,24(sp)
    80001258:	e852                	sd	s4,16(sp)
    8000125a:	e456                	sd	s5,8(sp)
    8000125c:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    8000125e:	00006517          	auipc	a0,0x6
    80001262:	ec250513          	addi	a0,a0,-318 # 80007120 <etext+0x120>
    80001266:	dceff0ef          	jal	80000834 <panic>
      continue;
    if (do_free) {
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
    8000126a:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    8000126e:	995a                	add	s2,s2,s6
    80001270:	03397563          	bgeu	s2,s3,8000129a <uvmunmap+0x76>
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    80001274:	4601                	li	a2,0
    80001276:	85ca                	mv	a1,s2
    80001278:	8552                	mv	a0,s4
    8000127a:	d09ff0ef          	jal	80000f82 <walk>
    8000127e:	84aa                	mv	s1,a0
    80001280:	d57d                	beqz	a0,8000126e <uvmunmap+0x4a>
    if ((*pte & PTE_V) == 0) // has physical page been allocated?
    80001282:	611c                	ld	a5,0(a0)
    80001284:	0017f713          	andi	a4,a5,1
    80001288:	d37d                	beqz	a4,8000126e <uvmunmap+0x4a>
    if (do_free) {
    8000128a:	fe0a80e3          	beqz	s5,8000126a <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    8000128e:	83a9                	srli	a5,a5,0xa
      kfree((void *)pa);
    80001290:	00c79513          	slli	a0,a5,0xc
    80001294:	fd2ff0ef          	jal	80000a66 <kfree>
    80001298:	bfc9                	j	8000126a <uvmunmap+0x46>
    8000129a:	74a2                	ld	s1,40(sp)
    8000129c:	7902                	ld	s2,32(sp)
    8000129e:	69e2                	ld	s3,24(sp)
    800012a0:	6a42                	ld	s4,16(sp)
    800012a2:	6aa2                	ld	s5,8(sp)
    800012a4:	6b02                	ld	s6,0(sp)
  }
}
    800012a6:	70e2                	ld	ra,56(sp)
    800012a8:	7442                	ld	s0,48(sp)
    800012aa:	6121                	addi	sp,sp,64
    800012ac:	8082                	ret

00000000800012ae <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800012ae:	1101                	addi	sp,sp,-32
    800012b0:	ec06                	sd	ra,24(sp)
    800012b2:	e822                	sd	s0,16(sp)
    800012b4:	e426                	sd	s1,8(sp)
    800012b6:	1000                	addi	s0,sp,32
  if (newsz >= oldsz)
    return oldsz;
    800012b8:	84ae                	mv	s1,a1
  if (newsz >= oldsz)
    800012ba:	00b67d63          	bgeu	a2,a1,800012d4 <uvmdealloc+0x26>
    800012be:	84b2                	mv	s1,a2

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    800012c0:	6785                	lui	a5,0x1
    800012c2:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012c4:	00f60733          	add	a4,a2,a5
    800012c8:	76fd                	lui	a3,0xfffff
    800012ca:	8f75                	and	a4,a4,a3
    800012cc:	97ae                	add	a5,a5,a1
    800012ce:	8ff5                	and	a5,a5,a3
    800012d0:	00f76863          	bltu	a4,a5,800012e0 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800012d4:	8526                	mv	a0,s1
    800012d6:	60e2                	ld	ra,24(sp)
    800012d8:	6442                	ld	s0,16(sp)
    800012da:	64a2                	ld	s1,8(sp)
    800012dc:	6105                	addi	sp,sp,32
    800012de:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800012e0:	8f99                	sub	a5,a5,a4
    800012e2:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800012e4:	4685                	li	a3,1
    800012e6:	0007861b          	sext.w	a2,a5
    800012ea:	85ba                	mv	a1,a4
    800012ec:	f39ff0ef          	jal	80001224 <uvmunmap>
    800012f0:	b7d5                	j	800012d4 <uvmdealloc+0x26>

00000000800012f2 <uvmalloc>:
  if (newsz < oldsz)
    800012f2:	0ab66163          	bltu	a2,a1,80001394 <uvmalloc+0xa2>
{
    800012f6:	715d                	addi	sp,sp,-80
    800012f8:	e486                	sd	ra,72(sp)
    800012fa:	e0a2                	sd	s0,64(sp)
    800012fc:	f84a                	sd	s2,48(sp)
    800012fe:	f052                	sd	s4,32(sp)
    80001300:	ec56                	sd	s5,24(sp)
    80001302:	e45e                	sd	s7,8(sp)
    80001304:	0880                	addi	s0,sp,80
    80001306:	8aaa                	mv	s5,a0
    80001308:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    8000130a:	6785                	lui	a5,0x1
    8000130c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000130e:	95be                	add	a1,a1,a5
    80001310:	77fd                	lui	a5,0xfffff
    80001312:	00f5f933          	and	s2,a1,a5
    80001316:	8bca                	mv	s7,s2
  for (a = oldsz; a < newsz; a += PGSIZE) {
    80001318:	08c97063          	bgeu	s2,a2,80001398 <uvmalloc+0xa6>
    8000131c:	fc26                	sd	s1,56(sp)
    8000131e:	f44e                	sd	s3,40(sp)
    80001320:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    80001322:	6985                	lui	s3,0x1
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    80001324:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001328:	827ff0ef          	jal	80000b4e <kalloc>
    8000132c:	84aa                	mv	s1,a0
    if (mem == 0) {
    8000132e:	c50d                	beqz	a0,80001358 <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    80001330:	864e                	mv	a2,s3
    80001332:	4581                	li	a1,0
    80001334:	9b5ff0ef          	jal	80000ce8 <memset>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    80001338:	875a                	mv	a4,s6
    8000133a:	86a6                	mv	a3,s1
    8000133c:	864e                	mv	a2,s3
    8000133e:	85ca                	mv	a1,s2
    80001340:	8556                	mv	a0,s5
    80001342:	d15ff0ef          	jal	80001056 <mappages>
    80001346:	e915                	bnez	a0,8000137a <uvmalloc+0x88>
  for (a = oldsz; a < newsz; a += PGSIZE) {
    80001348:	994e                	add	s2,s2,s3
    8000134a:	fd496fe3          	bltu	s2,s4,80001328 <uvmalloc+0x36>
  return newsz;
    8000134e:	8552                	mv	a0,s4
    80001350:	74e2                	ld	s1,56(sp)
    80001352:	79a2                	ld	s3,40(sp)
    80001354:	6b42                	ld	s6,16(sp)
    80001356:	a811                	j	8000136a <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80001358:	865e                	mv	a2,s7
    8000135a:	85ca                	mv	a1,s2
    8000135c:	8556                	mv	a0,s5
    8000135e:	f51ff0ef          	jal	800012ae <uvmdealloc>
      return 0;
    80001362:	4501                	li	a0,0
    80001364:	74e2                	ld	s1,56(sp)
    80001366:	79a2                	ld	s3,40(sp)
    80001368:	6b42                	ld	s6,16(sp)
}
    8000136a:	60a6                	ld	ra,72(sp)
    8000136c:	6406                	ld	s0,64(sp)
    8000136e:	7942                	ld	s2,48(sp)
    80001370:	7a02                	ld	s4,32(sp)
    80001372:	6ae2                	ld	s5,24(sp)
    80001374:	6ba2                	ld	s7,8(sp)
    80001376:	6161                	addi	sp,sp,80
    80001378:	8082                	ret
      kfree(mem);
    8000137a:	8526                	mv	a0,s1
    8000137c:	eeaff0ef          	jal	80000a66 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001380:	865e                	mv	a2,s7
    80001382:	85ca                	mv	a1,s2
    80001384:	8556                	mv	a0,s5
    80001386:	f29ff0ef          	jal	800012ae <uvmdealloc>
      return 0;
    8000138a:	4501                	li	a0,0
    8000138c:	74e2                	ld	s1,56(sp)
    8000138e:	79a2                	ld	s3,40(sp)
    80001390:	6b42                	ld	s6,16(sp)
    80001392:	bfe1                	j	8000136a <uvmalloc+0x78>
    return oldsz;
    80001394:	852e                	mv	a0,a1
}
    80001396:	8082                	ret
  return newsz;
    80001398:	8532                	mv	a0,a2
    8000139a:	bfc1                	j	8000136a <uvmalloc+0x78>

000000008000139c <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000139c:	7179                	addi	sp,sp,-48
    8000139e:	f406                	sd	ra,40(sp)
    800013a0:	f022                	sd	s0,32(sp)
    800013a2:	ec26                	sd	s1,24(sp)
    800013a4:	e84a                	sd	s2,16(sp)
    800013a6:	e44e                	sd	s3,8(sp)
    800013a8:	1800                	addi	s0,sp,48
    800013aa:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    800013ac:	84aa                	mv	s1,a0
    800013ae:	6905                	lui	s2,0x1
    800013b0:	992a                	add	s2,s2,a0
    800013b2:	a811                	j	800013c6 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if (pte & PTE_V) {
      panic("freewalk: leaf");
    800013b4:	00006517          	auipc	a0,0x6
    800013b8:	d8450513          	addi	a0,a0,-636 # 80007138 <etext+0x138>
    800013bc:	c78ff0ef          	jal	80000834 <panic>
  for (int i = 0; i < 512; i++) {
    800013c0:	04a1                	addi	s1,s1,8
    800013c2:	03248163          	beq	s1,s2,800013e4 <freewalk+0x48>
    pte_t pte = pagetable[i];
    800013c6:	609c                	ld	a5,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    800013c8:	0017f713          	andi	a4,a5,1
    800013cc:	db75                	beqz	a4,800013c0 <freewalk+0x24>
    800013ce:	00e7f713          	andi	a4,a5,14
    800013d2:	f36d                	bnez	a4,800013b4 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    800013d4:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800013d6:	00c79513          	slli	a0,a5,0xc
    800013da:	fc3ff0ef          	jal	8000139c <freewalk>
      pagetable[i] = 0;
    800013de:	0004b023          	sd	zero,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    800013e2:	bff9                	j	800013c0 <freewalk+0x24>
    }
  }
  kfree((void *)pagetable);
    800013e4:	854e                	mv	a0,s3
    800013e6:	e80ff0ef          	jal	80000a66 <kfree>
}
    800013ea:	70a2                	ld	ra,40(sp)
    800013ec:	7402                	ld	s0,32(sp)
    800013ee:	64e2                	ld	s1,24(sp)
    800013f0:	6942                	ld	s2,16(sp)
    800013f2:	69a2                	ld	s3,8(sp)
    800013f4:	6145                	addi	sp,sp,48
    800013f6:	8082                	ret

00000000800013f8 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800013f8:	1101                	addi	sp,sp,-32
    800013fa:	ec06                	sd	ra,24(sp)
    800013fc:	e822                	sd	s0,16(sp)
    800013fe:	e426                	sd	s1,8(sp)
    80001400:	1000                	addi	s0,sp,32
    80001402:	84aa                	mv	s1,a0
  if (sz > 0)
    80001404:	e989                	bnez	a1,80001416 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    80001406:	8526                	mv	a0,s1
    80001408:	f95ff0ef          	jal	8000139c <freewalk>
}
    8000140c:	60e2                	ld	ra,24(sp)
    8000140e:	6442                	ld	s0,16(sp)
    80001410:	64a2                	ld	s1,8(sp)
    80001412:	6105                	addi	sp,sp,32
    80001414:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80001416:	6785                	lui	a5,0x1
    80001418:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000141a:	95be                	add	a1,a1,a5
    8000141c:	4685                	li	a3,1
    8000141e:	00c5d613          	srli	a2,a1,0xc
    80001422:	4581                	li	a1,0
    80001424:	e01ff0ef          	jal	80001224 <uvmunmap>
    80001428:	bff9                	j	80001406 <uvmfree+0xe>

000000008000142a <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for (i = 0; i < sz; i += PGSIZE) {
    8000142a:	ca59                	beqz	a2,800014c0 <uvmcopy+0x96>
{
    8000142c:	715d                	addi	sp,sp,-80
    8000142e:	e486                	sd	ra,72(sp)
    80001430:	e0a2                	sd	s0,64(sp)
    80001432:	fc26                	sd	s1,56(sp)
    80001434:	f84a                	sd	s2,48(sp)
    80001436:	f44e                	sd	s3,40(sp)
    80001438:	f052                	sd	s4,32(sp)
    8000143a:	ec56                	sd	s5,24(sp)
    8000143c:	e85a                	sd	s6,16(sp)
    8000143e:	e45e                	sd	s7,8(sp)
    80001440:	0880                	addi	s0,sp,80
    80001442:	8b2a                	mv	s6,a0
    80001444:	8bae                	mv	s7,a1
    80001446:	8ab2                	mv	s5,a2
  for (i = 0; i < sz; i += PGSIZE) {
    80001448:	4481                	li	s1,0
      continue; // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if ((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char *)pa, PGSIZE);
    8000144a:	6a05                	lui	s4,0x1
    8000144c:	a021                	j	80001454 <uvmcopy+0x2a>
  for (i = 0; i < sz; i += PGSIZE) {
    8000144e:	94d2                	add	s1,s1,s4
    80001450:	0554fc63          	bgeu	s1,s5,800014a8 <uvmcopy+0x7e>
    if ((pte = walk(old, i, 0)) == 0)
    80001454:	4601                	li	a2,0
    80001456:	85a6                	mv	a1,s1
    80001458:	855a                	mv	a0,s6
    8000145a:	b29ff0ef          	jal	80000f82 <walk>
    8000145e:	d965                	beqz	a0,8000144e <uvmcopy+0x24>
    if ((*pte & PTE_V) == 0)
    80001460:	00053983          	ld	s3,0(a0)
    80001464:	0019f793          	andi	a5,s3,1
    80001468:	d3fd                	beqz	a5,8000144e <uvmcopy+0x24>
    if ((mem = kalloc()) == 0)
    8000146a:	ee4ff0ef          	jal	80000b4e <kalloc>
    8000146e:	892a                	mv	s2,a0
    80001470:	c11d                	beqz	a0,80001496 <uvmcopy+0x6c>
    pa = PTE2PA(*pte);
    80001472:	00a9d593          	srli	a1,s3,0xa
    memmove(mem, (char *)pa, PGSIZE);
    80001476:	8652                	mv	a2,s4
    80001478:	05b2                	slli	a1,a1,0xc
    8000147a:	8cfff0ef          	jal	80000d48 <memmove>
    if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    8000147e:	3ff9f713          	andi	a4,s3,1023
    80001482:	86ca                	mv	a3,s2
    80001484:	8652                	mv	a2,s4
    80001486:	85a6                	mv	a1,s1
    80001488:	855e                	mv	a0,s7
    8000148a:	bcdff0ef          	jal	80001056 <mappages>
    8000148e:	d161                	beqz	a0,8000144e <uvmcopy+0x24>
      kfree(mem);
    80001490:	854a                	mv	a0,s2
    80001492:	dd4ff0ef          	jal	80000a66 <kfree>
    }
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001496:	4685                	li	a3,1
    80001498:	00c4d613          	srli	a2,s1,0xc
    8000149c:	4581                	li	a1,0
    8000149e:	855e                	mv	a0,s7
    800014a0:	d85ff0ef          	jal	80001224 <uvmunmap>
  return -1;
    800014a4:	557d                	li	a0,-1
    800014a6:	a011                	j	800014aa <uvmcopy+0x80>
  return 0;
    800014a8:	4501                	li	a0,0
}
    800014aa:	60a6                	ld	ra,72(sp)
    800014ac:	6406                	ld	s0,64(sp)
    800014ae:	74e2                	ld	s1,56(sp)
    800014b0:	7942                	ld	s2,48(sp)
    800014b2:	79a2                	ld	s3,40(sp)
    800014b4:	7a02                	ld	s4,32(sp)
    800014b6:	6ae2                	ld	s5,24(sp)
    800014b8:	6b42                	ld	s6,16(sp)
    800014ba:	6ba2                	ld	s7,8(sp)
    800014bc:	6161                	addi	sp,sp,80
    800014be:	8082                	ret
  return 0;
    800014c0:	4501                	li	a0,0
}
    800014c2:	8082                	ret

00000000800014c4 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800014c4:	1141                	addi	sp,sp,-16
    800014c6:	e406                	sd	ra,8(sp)
    800014c8:	e022                	sd	s0,0(sp)
    800014ca:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    800014cc:	4601                	li	a2,0
    800014ce:	ab5ff0ef          	jal	80000f82 <walk>
  if (pte == 0)
    800014d2:	c901                	beqz	a0,800014e2 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800014d4:	611c                	ld	a5,0(a0)
    800014d6:	9bbd                	andi	a5,a5,-17
    800014d8:	e11c                	sd	a5,0(a0)
}
    800014da:	60a2                	ld	ra,8(sp)
    800014dc:	6402                	ld	s0,0(sp)
    800014de:	0141                	addi	sp,sp,16
    800014e0:	8082                	ret
    panic("uvmclear");
    800014e2:	00006517          	auipc	a0,0x6
    800014e6:	c6650513          	addi	a0,a0,-922 # 80007148 <etext+0x148>
    800014ea:	b4aff0ef          	jal	80000834 <panic>

00000000800014ee <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    800014ee:	1141                	addi	sp,sp,-16
    800014f0:	e406                	sd	ra,8(sp)
    800014f2:	e022                	sd	s0,0(sp)
    800014f4:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800014f6:	4601                	li	a2,0
    800014f8:	a8bff0ef          	jal	80000f82 <walk>
  if (pte == 0) {
    800014fc:	c119                	beqz	a0,80001502 <ismapped+0x14>
    return 0;
  }
  if (*pte & PTE_V) {
    800014fe:	6108                	ld	a0,0(a0)
    80001500:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001502:	60a2                	ld	ra,8(sp)
    80001504:	6402                	ld	s0,0(sp)
    80001506:	0141                	addi	sp,sp,16
    80001508:	8082                	ret

000000008000150a <vmfault>:
{
    8000150a:	7179                	addi	sp,sp,-48
    8000150c:	f406                	sd	ra,40(sp)
    8000150e:	f022                	sd	s0,32(sp)
    80001510:	e052                	sd	s4,0(sp)
    80001512:	1800                	addi	s0,sp,48
    return 0;
    80001514:	4a01                	li	s4,0
  if (va >= psz)
    80001516:	00b66863          	bltu	a2,a1,80001526 <vmfault+0x1c>
}
    8000151a:	8552                	mv	a0,s4
    8000151c:	70a2                	ld	ra,40(sp)
    8000151e:	7402                	ld	s0,32(sp)
    80001520:	6a02                	ld	s4,0(sp)
    80001522:	6145                	addi	sp,sp,48
    80001524:	8082                	ret
    80001526:	ec26                	sd	s1,24(sp)
    80001528:	e44e                	sd	s3,8(sp)
    8000152a:	84aa                	mv	s1,a0
  va = PGROUNDDOWN(va);
    8000152c:	77fd                	lui	a5,0xfffff
    8000152e:	00f679b3          	and	s3,a2,a5
  if (ismapped(pagetable, va)) {
    80001532:	85ce                	mv	a1,s3
    80001534:	fbbff0ef          	jal	800014ee <ismapped>
    return 0;
    80001538:	4a01                	li	s4,0
  if (ismapped(pagetable, va)) {
    8000153a:	c501                	beqz	a0,80001542 <vmfault+0x38>
    8000153c:	64e2                	ld	s1,24(sp)
    8000153e:	69a2                	ld	s3,8(sp)
    80001540:	bfe9                	j	8000151a <vmfault+0x10>
    80001542:	e84a                	sd	s2,16(sp)
  mem = (uint64)kalloc();
    80001544:	e0aff0ef          	jal	80000b4e <kalloc>
    80001548:	892a                	mv	s2,a0
  if (mem == 0)
    8000154a:	c915                	beqz	a0,8000157e <vmfault+0x74>
  mem = (uint64)kalloc();
    8000154c:	8a2a                	mv	s4,a0
  memset((void *)mem, 0, PGSIZE);
    8000154e:	6605                	lui	a2,0x1
    80001550:	4581                	li	a1,0
    80001552:	f96ff0ef          	jal	80000ce8 <memset>
  if (mappages(pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    80001556:	4759                	li	a4,22
    80001558:	86ca                	mv	a3,s2
    8000155a:	6605                	lui	a2,0x1
    8000155c:	85ce                	mv	a1,s3
    8000155e:	8526                	mv	a0,s1
    80001560:	af7ff0ef          	jal	80001056 <mappages>
    80001564:	e509                	bnez	a0,8000156e <vmfault+0x64>
    80001566:	64e2                	ld	s1,24(sp)
    80001568:	6942                	ld	s2,16(sp)
    8000156a:	69a2                	ld	s3,8(sp)
    8000156c:	b77d                	j	8000151a <vmfault+0x10>
    kfree((void *)mem);
    8000156e:	854a                	mv	a0,s2
    80001570:	cf6ff0ef          	jal	80000a66 <kfree>
    return 0;
    80001574:	4a01                	li	s4,0
    80001576:	64e2                	ld	s1,24(sp)
    80001578:	6942                	ld	s2,16(sp)
    8000157a:	69a2                	ld	s3,8(sp)
    8000157c:	bf79                	j	8000151a <vmfault+0x10>
    8000157e:	64e2                	ld	s1,24(sp)
    80001580:	6942                	ld	s2,16(sp)
    80001582:	69a2                	ld	s3,8(sp)
    80001584:	bf59                	j	8000151a <vmfault+0x10>

0000000080001586 <copyout>:
  while (len > 0) {
    80001586:	cf49                	beqz	a4,80001620 <copyout+0x9a>
{
    80001588:	7159                	addi	sp,sp,-112
    8000158a:	f486                	sd	ra,104(sp)
    8000158c:	f0a2                	sd	s0,96(sp)
    8000158e:	eca6                	sd	s1,88(sp)
    80001590:	e8ca                	sd	s2,80(sp)
    80001592:	e4ce                	sd	s3,72(sp)
    80001594:	e0d2                	sd	s4,64(sp)
    80001596:	fc56                	sd	s5,56(sp)
    80001598:	f85a                	sd	s6,48(sp)
    8000159a:	f45e                	sd	s7,40(sp)
    8000159c:	f062                	sd	s8,32(sp)
    8000159e:	ec66                	sd	s9,24(sp)
    800015a0:	e86a                	sd	s10,16(sp)
    800015a2:	e46e                	sd	s11,8(sp)
    800015a4:	1880                	addi	s0,sp,112
    800015a6:	8baa                	mv	s7,a0
    800015a8:	8dae                	mv	s11,a1
    800015aa:	8a32                	mv	s4,a2
    800015ac:	8b36                	mv	s6,a3
    800015ae:	8aba                	mv	s5,a4
    va0 = PGROUNDDOWN(dstva);
    800015b0:	7d7d                	lui	s10,0xfffff
    if (va0 >= MAXVA)
    800015b2:	5cfd                	li	s9,-1
    800015b4:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    800015b8:	6c05                	lui	s8,0x1
    800015ba:	a005                	j	800015da <copyout+0x54>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    800015bc:	409a0533          	sub	a0,s4,s1
    800015c0:	0009061b          	sext.w	a2,s2
    800015c4:	85da                	mv	a1,s6
    800015c6:	954e                	add	a0,a0,s3
    800015c8:	f80ff0ef          	jal	80000d48 <memmove>
    len -= n;
    800015cc:	412a8ab3          	sub	s5,s5,s2
    src += n;
    800015d0:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    800015d2:	01848a33          	add	s4,s1,s8
  while (len > 0) {
    800015d6:	040a8363          	beqz	s5,8000161c <copyout+0x96>
    va0 = PGROUNDDOWN(dstva);
    800015da:	01aa74b3          	and	s1,s4,s10
    if (va0 >= MAXVA)
    800015de:	049ce363          	bltu	s9,s1,80001624 <copyout+0x9e>
    pa0 = walkaddr(pagetable, va0);
    800015e2:	85a6                	mv	a1,s1
    800015e4:	855e                	mv	a0,s7
    800015e6:	a37ff0ef          	jal	8000101c <walkaddr>
    800015ea:	89aa                	mv	s3,a0
    if (pa0 == 0) {
    800015ec:	e909                	bnez	a0,800015fe <copyout+0x78>
      if ((pa0 = vmfault(pagetable, psz, va0, 0)) == 0) {
    800015ee:	4681                	li	a3,0
    800015f0:	8626                	mv	a2,s1
    800015f2:	85ee                	mv	a1,s11
    800015f4:	855e                	mv	a0,s7
    800015f6:	f15ff0ef          	jal	8000150a <vmfault>
    800015fa:	89aa                	mv	s3,a0
    800015fc:	c521                	beqz	a0,80001644 <copyout+0xbe>
    pte = walk(pagetable, va0, 0);
    800015fe:	4601                	li	a2,0
    80001600:	85a6                	mv	a1,s1
    80001602:	855e                	mv	a0,s7
    80001604:	97fff0ef          	jal	80000f82 <walk>
    if ((*pte & PTE_W) == 0)
    80001608:	611c                	ld	a5,0(a0)
    8000160a:	8b91                	andi	a5,a5,4
    8000160c:	cf95                	beqz	a5,80001648 <copyout+0xc2>
    n = PGSIZE - (dstva - va0);
    8000160e:	41448933          	sub	s2,s1,s4
    80001612:	9962                	add	s2,s2,s8
    if (n > len)
    80001614:	fb2af4e3          	bgeu	s5,s2,800015bc <copyout+0x36>
    80001618:	8956                	mv	s2,s5
    8000161a:	b74d                	j	800015bc <copyout+0x36>
  return 0;
    8000161c:	4501                	li	a0,0
    8000161e:	a021                	j	80001626 <copyout+0xa0>
    80001620:	4501                	li	a0,0
}
    80001622:	8082                	ret
      return -1;
    80001624:	557d                	li	a0,-1
}
    80001626:	70a6                	ld	ra,104(sp)
    80001628:	7406                	ld	s0,96(sp)
    8000162a:	64e6                	ld	s1,88(sp)
    8000162c:	6946                	ld	s2,80(sp)
    8000162e:	69a6                	ld	s3,72(sp)
    80001630:	6a06                	ld	s4,64(sp)
    80001632:	7ae2                	ld	s5,56(sp)
    80001634:	7b42                	ld	s6,48(sp)
    80001636:	7ba2                	ld	s7,40(sp)
    80001638:	7c02                	ld	s8,32(sp)
    8000163a:	6ce2                	ld	s9,24(sp)
    8000163c:	6d42                	ld	s10,16(sp)
    8000163e:	6da2                	ld	s11,8(sp)
    80001640:	6165                	addi	sp,sp,112
    80001642:	8082                	ret
        return -1;
    80001644:	557d                	li	a0,-1
    80001646:	b7c5                	j	80001626 <copyout+0xa0>
      return -1;
    80001648:	557d                	li	a0,-1
    8000164a:	bff1                	j	80001626 <copyout+0xa0>

000000008000164c <copyin>:
  while (len > 0) {
    8000164c:	cf41                	beqz	a4,800016e4 <copyin+0x98>
{
    8000164e:	711d                	addi	sp,sp,-96
    80001650:	ec86                	sd	ra,88(sp)
    80001652:	e8a2                	sd	s0,80(sp)
    80001654:	e4a6                	sd	s1,72(sp)
    80001656:	e0ca                	sd	s2,64(sp)
    80001658:	fc4e                	sd	s3,56(sp)
    8000165a:	f852                	sd	s4,48(sp)
    8000165c:	f456                	sd	s5,40(sp)
    8000165e:	f05a                	sd	s6,32(sp)
    80001660:	ec5e                	sd	s7,24(sp)
    80001662:	e862                	sd	s8,16(sp)
    80001664:	e466                	sd	s9,8(sp)
    80001666:	e06a                	sd	s10,0(sp)
    80001668:	1080                	addi	s0,sp,96
    8000166a:	8baa                	mv	s7,a0
    8000166c:	8cae                	mv	s9,a1
    8000166e:	8ab2                	mv	s5,a2
    80001670:	8936                	mv	s2,a3
    80001672:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    80001674:	7c7d                	lui	s8,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001676:	4d05                	li	s10,1
    n = PGSIZE - (srcva - va0);
    80001678:	6b05                	lui	s6,0x1
    8000167a:	a035                	j	800016a6 <copyin+0x5a>
    8000167c:	412984b3          	sub	s1,s3,s2
    80001680:	94da                	add	s1,s1,s6
    if (n > len)
    80001682:	009a7363          	bgeu	s4,s1,80001688 <copyin+0x3c>
    80001686:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001688:	413905b3          	sub	a1,s2,s3
    8000168c:	0004861b          	sext.w	a2,s1
    80001690:	95aa                	add	a1,a1,a0
    80001692:	8556                	mv	a0,s5
    80001694:	eb4ff0ef          	jal	80000d48 <memmove>
    len -= n;
    80001698:	409a0a33          	sub	s4,s4,s1
    dst += n;
    8000169c:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    8000169e:	01698933          	add	s2,s3,s6
  while (len > 0) {
    800016a2:	020a0263          	beqz	s4,800016c6 <copyin+0x7a>
    va0 = PGROUNDDOWN(srcva);
    800016a6:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    800016aa:	85ce                	mv	a1,s3
    800016ac:	855e                	mv	a0,s7
    800016ae:	96fff0ef          	jal	8000101c <walkaddr>
    if (pa0 == 0) {
    800016b2:	f569                	bnez	a0,8000167c <copyin+0x30>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    800016b4:	86ea                	mv	a3,s10
    800016b6:	864e                	mv	a2,s3
    800016b8:	85e6                	mv	a1,s9
    800016ba:	855e                	mv	a0,s7
    800016bc:	e4fff0ef          	jal	8000150a <vmfault>
    800016c0:	fd55                	bnez	a0,8000167c <copyin+0x30>
        return -1;
    800016c2:	557d                	li	a0,-1
    800016c4:	a011                	j	800016c8 <copyin+0x7c>
  return 0;
    800016c6:	4501                	li	a0,0
}
    800016c8:	60e6                	ld	ra,88(sp)
    800016ca:	6446                	ld	s0,80(sp)
    800016cc:	64a6                	ld	s1,72(sp)
    800016ce:	6906                	ld	s2,64(sp)
    800016d0:	79e2                	ld	s3,56(sp)
    800016d2:	7a42                	ld	s4,48(sp)
    800016d4:	7aa2                	ld	s5,40(sp)
    800016d6:	7b02                	ld	s6,32(sp)
    800016d8:	6be2                	ld	s7,24(sp)
    800016da:	6c42                	ld	s8,16(sp)
    800016dc:	6ca2                	ld	s9,8(sp)
    800016de:	6d02                	ld	s10,0(sp)
    800016e0:	6125                	addi	sp,sp,96
    800016e2:	8082                	ret
  return 0;
    800016e4:	4501                	li	a0,0
}
    800016e6:	8082                	ret

00000000800016e8 <copyinstr>:
  while (got_null == 0 && max > 0) {
    800016e8:	c769                	beqz	a4,800017b2 <copyinstr+0xca>
{
    800016ea:	711d                	addi	sp,sp,-96
    800016ec:	ec86                	sd	ra,88(sp)
    800016ee:	e8a2                	sd	s0,80(sp)
    800016f0:	e4a6                	sd	s1,72(sp)
    800016f2:	e0ca                	sd	s2,64(sp)
    800016f4:	fc4e                	sd	s3,56(sp)
    800016f6:	f852                	sd	s4,48(sp)
    800016f8:	f456                	sd	s5,40(sp)
    800016fa:	f05a                	sd	s6,32(sp)
    800016fc:	ec5e                	sd	s7,24(sp)
    800016fe:	e862                	sd	s8,16(sp)
    80001700:	e466                	sd	s9,8(sp)
    80001702:	1080                	addi	s0,sp,96
    80001704:	8b2a                	mv	s6,a0
    80001706:	8c2e                	mv	s8,a1
    80001708:	89b2                	mv	s3,a2
    8000170a:	84b6                	mv	s1,a3
    8000170c:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    8000170e:	7bfd                	lui	s7,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001710:	4c85                	li	s9,1
    n = PGSIZE - (srcva - va0);
    80001712:	6a85                	lui	s5,0x1
    80001714:	a881                	j	80001764 <copyinstr+0x7c>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001716:	86e6                	mv	a3,s9
    80001718:	864a                	mv	a2,s2
    8000171a:	85e2                	mv	a1,s8
    8000171c:	855a                	mv	a0,s6
    8000171e:	dedff0ef          	jal	8000150a <vmfault>
    80001722:	e921                	bnez	a0,80001772 <copyinstr+0x8a>
        return -1;
    80001724:	557d                	li	a0,-1
    80001726:	a801                	j	80001736 <copyinstr+0x4e>
        *dst = '\0';
    80001728:	00078023          	sb	zero,0(a5) # fffffffffffff000 <end+0xffffffff7ffdb740>
        got_null = 1;
    8000172c:	4785                	li	a5,1
  if (got_null) {
    8000172e:	0017c793          	xori	a5,a5,1
    80001732:	40f0053b          	negw	a0,a5
}
    80001736:	60e6                	ld	ra,88(sp)
    80001738:	6446                	ld	s0,80(sp)
    8000173a:	64a6                	ld	s1,72(sp)
    8000173c:	6906                	ld	s2,64(sp)
    8000173e:	79e2                	ld	s3,56(sp)
    80001740:	7a42                	ld	s4,48(sp)
    80001742:	7aa2                	ld	s5,40(sp)
    80001744:	7b02                	ld	s6,32(sp)
    80001746:	6be2                	ld	s7,24(sp)
    80001748:	6c42                	ld	s8,16(sp)
    8000174a:	6ca2                	ld	s9,8(sp)
    8000174c:	6125                	addi	sp,sp,96
    8000174e:	8082                	ret
    80001750:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80001754:	974e                	add	a4,a4,s3
      --max;
    80001756:	40b70a33          	sub	s4,a4,a1
    srcva = va0 + PGSIZE;
    8000175a:	015904b3          	add	s1,s2,s5
  while (got_null == 0 && max > 0) {
    8000175e:	04e58463          	beq	a1,a4,800017a6 <copyinstr+0xbe>
{
    80001762:	89be                	mv	s3,a5
    va0 = PGROUNDDOWN(srcva);
    80001764:	0174f933          	and	s2,s1,s7
    pa0 = walkaddr(pagetable, va0);
    80001768:	85ca                	mv	a1,s2
    8000176a:	855a                	mv	a0,s6
    8000176c:	8b1ff0ef          	jal	8000101c <walkaddr>
    if (pa0 == 0) {
    80001770:	d15d                	beqz	a0,80001716 <copyinstr+0x2e>
    n = PGSIZE - (srcva - va0);
    80001772:	40990633          	sub	a2,s2,s1
    80001776:	9656                	add	a2,a2,s5
    if (n > max)
    80001778:	00ca7363          	bgeu	s4,a2,8000177e <copyinstr+0x96>
    8000177c:	8652                	mv	a2,s4
    while (n > 0) {
    8000177e:	c615                	beqz	a2,800017aa <copyinstr+0xc2>
    char *p = (char *)(pa0 + (srcva - va0));
    80001780:	412484b3          	sub	s1,s1,s2
    80001784:	94aa                	add	s1,s1,a0
    80001786:	87ce                	mv	a5,s3
      if (*p == '\0') {
    80001788:	413484b3          	sub	s1,s1,s3
    while (n > 0) {
    8000178c:	964e                	add	a2,a2,s3
    8000178e:	85be                	mv	a1,a5
      if (*p == '\0') {
    80001790:	00f48733          	add	a4,s1,a5
    80001794:	00074683          	lbu	a3,0(a4)
    80001798:	dac1                	beqz	a3,80001728 <copyinstr+0x40>
        *dst = *p;
    8000179a:	00d78023          	sb	a3,0(a5)
      dst++;
    8000179e:	0785                	addi	a5,a5,1
    while (n > 0) {
    800017a0:	fec797e3          	bne	a5,a2,8000178e <copyinstr+0xa6>
    800017a4:	b775                	j	80001750 <copyinstr+0x68>
    800017a6:	4781                	li	a5,0
    800017a8:	b759                	j	8000172e <copyinstr+0x46>
    srcva = va0 + PGSIZE;
    800017aa:	6485                	lui	s1,0x1
    800017ac:	94ca                	add	s1,s1,s2
    800017ae:	87ce                	mv	a5,s3
    800017b0:	bf4d                	j	80001762 <copyinstr+0x7a>
  int got_null = 0;
    800017b2:	4781                	li	a5,0
  if (got_null) {
    800017b4:	0017c793          	xori	a5,a5,1
    800017b8:	40f0053b          	negw	a0,a5
}
    800017bc:	8082                	ret

00000000800017be <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800017be:	715d                	addi	sp,sp,-80
    800017c0:	e486                	sd	ra,72(sp)
    800017c2:	e0a2                	sd	s0,64(sp)
    800017c4:	fc26                	sd	s1,56(sp)
    800017c6:	f84a                	sd	s2,48(sp)
    800017c8:	f44e                	sd	s3,40(sp)
    800017ca:	f052                	sd	s4,32(sp)
    800017cc:	ec56                	sd	s5,24(sp)
    800017ce:	e85a                	sd	s6,16(sp)
    800017d0:	e45e                	sd	s7,8(sp)
    800017d2:	e062                	sd	s8,0(sp)
    800017d4:	0880                	addi	s0,sp,80
    800017d6:	8a2a                	mv	s4,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    800017d8:	00011497          	auipc	s1,0x11
    800017dc:	2e048493          	addi	s1,s1,736 # 80012ab8 <proc>
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    800017e0:	8c26                	mv	s8,s1
    800017e2:	000a57b7          	lui	a5,0xa5
    800017e6:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    800017ea:	07b2                	slli	a5,a5,0xc
    800017ec:	fa578793          	addi	a5,a5,-91
    800017f0:	4fa50937          	lui	s2,0x4fa50
    800017f4:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800017f8:	1902                	slli	s2,s2,0x20
    800017fa:	993e                	add	s2,s2,a5
    800017fc:	040009b7          	lui	s3,0x4000
    80001800:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001802:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001804:	4b99                	li	s7,6
    80001806:	6b05                	lui	s6,0x1
  for (p = proc; p < &proc[NPROC]; p++) {
    80001808:	00017a97          	auipc	s5,0x17
    8000180c:	cb0a8a93          	addi	s5,s5,-848 # 800184b8 <tickslock>
    char *pa = kalloc();
    80001810:	b3eff0ef          	jal	80000b4e <kalloc>
    80001814:	862a                	mv	a2,a0
    if (pa == 0)
    80001816:	c121                	beqz	a0,80001856 <proc_mapstacks+0x98>
    uint64 va = KSTACK((int)(p - proc));
    80001818:	418485b3          	sub	a1,s1,s8
    8000181c:	858d                	srai	a1,a1,0x3
    8000181e:	032585b3          	mul	a1,a1,s2
    80001822:	05b6                	slli	a1,a1,0xd
    80001824:	6789                	lui	a5,0x2
    80001826:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001828:	875e                	mv	a4,s7
    8000182a:	86da                	mv	a3,s6
    8000182c:	40b985b3          	sub	a1,s3,a1
    80001830:	8552                	mv	a0,s4
    80001832:	8dbff0ef          	jal	8000110c <kvmmap>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001836:	16848493          	addi	s1,s1,360
    8000183a:	fd549be3          	bne	s1,s5,80001810 <proc_mapstacks+0x52>
  }
}
    8000183e:	60a6                	ld	ra,72(sp)
    80001840:	6406                	ld	s0,64(sp)
    80001842:	74e2                	ld	s1,56(sp)
    80001844:	7942                	ld	s2,48(sp)
    80001846:	79a2                	ld	s3,40(sp)
    80001848:	7a02                	ld	s4,32(sp)
    8000184a:	6ae2                	ld	s5,24(sp)
    8000184c:	6b42                	ld	s6,16(sp)
    8000184e:	6ba2                	ld	s7,8(sp)
    80001850:	6c02                	ld	s8,0(sp)
    80001852:	6161                	addi	sp,sp,80
    80001854:	8082                	ret
      panic("kalloc");
    80001856:	00006517          	auipc	a0,0x6
    8000185a:	90250513          	addi	a0,a0,-1790 # 80007158 <etext+0x158>
    8000185e:	fd7fe0ef          	jal	80000834 <panic>

0000000080001862 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001862:	7139                	addi	sp,sp,-64
    80001864:	fc06                	sd	ra,56(sp)
    80001866:	f822                	sd	s0,48(sp)
    80001868:	f426                	sd	s1,40(sp)
    8000186a:	f04a                	sd	s2,32(sp)
    8000186c:	ec4e                	sd	s3,24(sp)
    8000186e:	e852                	sd	s4,16(sp)
    80001870:	e456                	sd	s5,8(sp)
    80001872:	e05a                	sd	s6,0(sp)
    80001874:	0080                	addi	s0,sp,64
  struct proc *p;

  initlock(&pid_lock, "nextpid");
    80001876:	00006597          	auipc	a1,0x6
    8000187a:	8ea58593          	addi	a1,a1,-1814 # 80007160 <etext+0x160>
    8000187e:	00011517          	auipc	a0,0x11
    80001882:	e0a50513          	addi	a0,a0,-502 # 80012688 <pid_lock>
    80001886:	b22ff0ef          	jal	80000ba8 <initlock>
  initlock(&wait_lock, "wait_lock");
    8000188a:	00006597          	auipc	a1,0x6
    8000188e:	8de58593          	addi	a1,a1,-1826 # 80007168 <etext+0x168>
    80001892:	00011517          	auipc	a0,0x11
    80001896:	e0e50513          	addi	a0,a0,-498 # 800126a0 <wait_lock>
    8000189a:	b0eff0ef          	jal	80000ba8 <initlock>
  for (p = proc; p < &proc[NPROC]; p++) {
    8000189e:	00011497          	auipc	s1,0x11
    800018a2:	21a48493          	addi	s1,s1,538 # 80012ab8 <proc>
    initlock(&p->lock, "proc");
    800018a6:	00006b17          	auipc	s6,0x6
    800018aa:	8d2b0b13          	addi	s6,s6,-1838 # 80007178 <etext+0x178>
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
    800018ae:	8aa6                	mv	s5,s1
    800018b0:	000a57b7          	lui	a5,0xa5
    800018b4:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    800018b8:	07b2                	slli	a5,a5,0xc
    800018ba:	fa578793          	addi	a5,a5,-91
    800018be:	4fa50937          	lui	s2,0x4fa50
    800018c2:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800018c6:	1902                	slli	s2,s2,0x20
    800018c8:	993e                	add	s2,s2,a5
    800018ca:	040009b7          	lui	s3,0x4000
    800018ce:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800018d0:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    800018d2:	00017a17          	auipc	s4,0x17
    800018d6:	be6a0a13          	addi	s4,s4,-1050 # 800184b8 <tickslock>
    initlock(&p->lock, "proc");
    800018da:	85da                	mv	a1,s6
    800018dc:	8526                	mv	a0,s1
    800018de:	acaff0ef          	jal	80000ba8 <initlock>
    p->state = UNUSED;
    800018e2:	0004ac23          	sw	zero,24(s1)
    p->kstack = KSTACK((int)(p - proc));
    800018e6:	415487b3          	sub	a5,s1,s5
    800018ea:	878d                	srai	a5,a5,0x3
    800018ec:	032787b3          	mul	a5,a5,s2
    800018f0:	07b6                	slli	a5,a5,0xd
    800018f2:	6709                	lui	a4,0x2
    800018f4:	9fb9                	addw	a5,a5,a4
    800018f6:	40f987b3          	sub	a5,s3,a5
    800018fa:	e0bc                	sd	a5,64(s1)
  for (p = proc; p < &proc[NPROC]; p++) {
    800018fc:	16848493          	addi	s1,s1,360
    80001900:	fd449de3          	bne	s1,s4,800018da <procinit+0x78>
  }
}
    80001904:	70e2                	ld	ra,56(sp)
    80001906:	7442                	ld	s0,48(sp)
    80001908:	74a2                	ld	s1,40(sp)
    8000190a:	7902                	ld	s2,32(sp)
    8000190c:	69e2                	ld	s3,24(sp)
    8000190e:	6a42                	ld	s4,16(sp)
    80001910:	6aa2                	ld	s5,8(sp)
    80001912:	6b02                	ld	s6,0(sp)
    80001914:	6121                	addi	sp,sp,64
    80001916:	8082                	ret

0000000080001918 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001918:	1141                	addi	sp,sp,-16
    8000191a:	e406                	sd	ra,8(sp)
    8000191c:	e022                	sd	s0,0(sp)
    8000191e:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    80001920:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001922:	2501                	sext.w	a0,a0
    80001924:	60a2                	ld	ra,8(sp)
    80001926:	6402                	ld	s0,0(sp)
    80001928:	0141                	addi	sp,sp,16
    8000192a:	8082                	ret

000000008000192c <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
    8000192c:	1141                	addi	sp,sp,-16
    8000192e:	e406                	sd	ra,8(sp)
    80001930:	e022                	sd	s0,0(sp)
    80001932:	0800                	addi	s0,sp,16
    80001934:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001936:	2781                	sext.w	a5,a5
    80001938:	079e                	slli	a5,a5,0x7
  return c;
}
    8000193a:	00011517          	auipc	a0,0x11
    8000193e:	d7e50513          	addi	a0,a0,-642 # 800126b8 <cpus>
    80001942:	953e                	add	a0,a0,a5
    80001944:	60a2                	ld	ra,8(sp)
    80001946:	6402                	ld	s0,0(sp)
    80001948:	0141                	addi	sp,sp,16
    8000194a:	8082                	ret

000000008000194c <myproc>:

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
    8000194c:	1101                	addi	sp,sp,-32
    8000194e:	ec06                	sd	ra,24(sp)
    80001950:	e822                	sd	s0,16(sp)
    80001952:	e426                	sd	s1,8(sp)
    80001954:	1000                	addi	s0,sp,32
  push_off();
    80001956:	a98ff0ef          	jal	80000bee <push_off>
    8000195a:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    8000195c:	2781                	sext.w	a5,a5
    8000195e:	079e                	slli	a5,a5,0x7
    80001960:	00011717          	auipc	a4,0x11
    80001964:	d2870713          	addi	a4,a4,-728 # 80012688 <pid_lock>
    80001968:	97ba                	add	a5,a5,a4
    8000196a:	7b9c                	ld	a5,48(a5)
    8000196c:	84be                	mv	s1,a5
  pop_off();
    8000196e:	afaff0ef          	jal	80000c68 <pop_off>
  return p;
}
    80001972:	8526                	mv	a0,s1
    80001974:	60e2                	ld	ra,24(sp)
    80001976:	6442                	ld	s0,16(sp)
    80001978:	64a2                	ld	s1,8(sp)
    8000197a:	6105                	addi	sp,sp,32
    8000197c:	8082                	ret

000000008000197e <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    8000197e:	7179                	addi	sp,sp,-48
    80001980:	f406                	sd	ra,40(sp)
    80001982:	f022                	sd	s0,32(sp)
    80001984:	ec26                	sd	s1,24(sp)
    80001986:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001988:	fc5ff0ef          	jal	8000194c <myproc>
    8000198c:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    8000198e:	b22ff0ef          	jal	80000cb0 <release>

  if (first) {
    80001992:	00009797          	auipc	a5,0x9
    80001996:	b8e7a783          	lw	a5,-1138(a5) # 8000a520 <first.1>
    8000199a:	cf85                	beqz	a5,800019d2 <forkret+0x54>
    first = 0;
    8000199c:	00009797          	auipc	a5,0x9
    800019a0:	b807a223          	sw	zero,-1148(a5) # 8000a520 <first.1>

    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    800019a4:	4505                	li	a0,1
    800019a6:	469010ef          	jal	8000360e <fsinit>

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    800019aa:	00005797          	auipc	a5,0x5
    800019ae:	7d678793          	addi	a5,a5,2006 # 80007180 <etext+0x180>
    800019b2:	fcf43823          	sd	a5,-48(s0)
    800019b6:	fc043c23          	sd	zero,-40(s0)
    800019ba:	fd040593          	addi	a1,s0,-48
    800019be:	853e                	mv	a0,a5
    800019c0:	6e9020ef          	jal	800048a8 <kexec>
    800019c4:	6cbc                	ld	a5,88(s1)
    800019c6:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    800019c8:	6cbc                	ld	a5,88(s1)
    800019ca:	7bb8                	ld	a4,112(a5)
    800019cc:	57fd                	li	a5,-1
    800019ce:	02f70d63          	beq	a4,a5,80001a08 <forkret+0x8a>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    800019d2:	2fd000ef          	jal	800024ce <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800019d6:	68a8                	ld	a0,80(s1)
    800019d8:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800019da:	04000737          	lui	a4,0x4000
    800019de:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800019e0:	0732                	slli	a4,a4,0xc
    800019e2:	00004797          	auipc	a5,0x4
    800019e6:	6ba78793          	addi	a5,a5,1722 # 8000609c <userret>
    800019ea:	00004697          	auipc	a3,0x4
    800019ee:	61668693          	addi	a3,a3,1558 # 80006000 <_trampoline>
    800019f2:	8f95                	sub	a5,a5,a3
    800019f4:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800019f6:	577d                	li	a4,-1
    800019f8:	177e                	slli	a4,a4,0x3f
    800019fa:	8d59                	or	a0,a0,a4
    800019fc:	9782                	jalr	a5
}
    800019fe:	70a2                	ld	ra,40(sp)
    80001a00:	7402                	ld	s0,32(sp)
    80001a02:	64e2                	ld	s1,24(sp)
    80001a04:	6145                	addi	sp,sp,48
    80001a06:	8082                	ret
      panic("exec");
    80001a08:	00005517          	auipc	a0,0x5
    80001a0c:	78050513          	addi	a0,a0,1920 # 80007188 <etext+0x188>
    80001a10:	e25fe0ef          	jal	80000834 <panic>

0000000080001a14 <allocpid>:
{
    80001a14:	1101                	addi	sp,sp,-32
    80001a16:	ec06                	sd	ra,24(sp)
    80001a18:	e822                	sd	s0,16(sp)
    80001a1a:	e426                	sd	s1,8(sp)
    80001a1c:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001a1e:	00011517          	auipc	a0,0x11
    80001a22:	c6a50513          	addi	a0,a0,-918 # 80012688 <pid_lock>
    80001a26:	a02ff0ef          	jal	80000c28 <acquire>
  pid = nextpid;
    80001a2a:	00009797          	auipc	a5,0x9
    80001a2e:	afa78793          	addi	a5,a5,-1286 # 8000a524 <nextpid>
    80001a32:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001a34:	0014871b          	addiw	a4,s1,1
    80001a38:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001a3a:	00011517          	auipc	a0,0x11
    80001a3e:	c4e50513          	addi	a0,a0,-946 # 80012688 <pid_lock>
    80001a42:	a6eff0ef          	jal	80000cb0 <release>
}
    80001a46:	8526                	mv	a0,s1
    80001a48:	60e2                	ld	ra,24(sp)
    80001a4a:	6442                	ld	s0,16(sp)
    80001a4c:	64a2                	ld	s1,8(sp)
    80001a4e:	6105                	addi	sp,sp,32
    80001a50:	8082                	ret

0000000080001a52 <proc_pagetable>:
{
    80001a52:	1101                	addi	sp,sp,-32
    80001a54:	ec06                	sd	ra,24(sp)
    80001a56:	e822                	sd	s0,16(sp)
    80001a58:	e426                	sd	s1,8(sp)
    80001a5a:	e04a                	sd	s2,0(sp)
    80001a5c:	1000                	addi	s0,sp,32
    80001a5e:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001a60:	f9eff0ef          	jal	800011fe <uvmcreate>
    80001a64:	84aa                	mv	s1,a0
  if (pagetable == 0)
    80001a66:	cd05                	beqz	a0,80001a9e <proc_pagetable+0x4c>
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
    80001a68:	4729                	li	a4,10
    80001a6a:	00004697          	auipc	a3,0x4
    80001a6e:	59668693          	addi	a3,a3,1430 # 80006000 <_trampoline>
    80001a72:	6605                	lui	a2,0x1
    80001a74:	040005b7          	lui	a1,0x4000
    80001a78:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a7a:	05b2                	slli	a1,a1,0xc
    80001a7c:	ddaff0ef          	jal	80001056 <mappages>
    80001a80:	02054663          	bltz	a0,80001aac <proc_pagetable+0x5a>
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
    80001a84:	4719                	li	a4,6
    80001a86:	05893683          	ld	a3,88(s2)
    80001a8a:	6605                	lui	a2,0x1
    80001a8c:	020005b7          	lui	a1,0x2000
    80001a90:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a92:	05b6                	slli	a1,a1,0xd
    80001a94:	8526                	mv	a0,s1
    80001a96:	dc0ff0ef          	jal	80001056 <mappages>
    80001a9a:	00054f63          	bltz	a0,80001ab8 <proc_pagetable+0x66>
}
    80001a9e:	8526                	mv	a0,s1
    80001aa0:	60e2                	ld	ra,24(sp)
    80001aa2:	6442                	ld	s0,16(sp)
    80001aa4:	64a2                	ld	s1,8(sp)
    80001aa6:	6902                	ld	s2,0(sp)
    80001aa8:	6105                	addi	sp,sp,32
    80001aaa:	8082                	ret
    uvmfree(pagetable, 0);
    80001aac:	4581                	li	a1,0
    80001aae:	8526                	mv	a0,s1
    80001ab0:	949ff0ef          	jal	800013f8 <uvmfree>
    return 0;
    80001ab4:	4481                	li	s1,0
    80001ab6:	b7e5                	j	80001a9e <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001ab8:	4681                	li	a3,0
    80001aba:	4605                	li	a2,1
    80001abc:	040005b7          	lui	a1,0x4000
    80001ac0:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001ac2:	05b2                	slli	a1,a1,0xc
    80001ac4:	8526                	mv	a0,s1
    80001ac6:	f5eff0ef          	jal	80001224 <uvmunmap>
    uvmfree(pagetable, 0);
    80001aca:	4581                	li	a1,0
    80001acc:	8526                	mv	a0,s1
    80001ace:	92bff0ef          	jal	800013f8 <uvmfree>
    return 0;
    80001ad2:	4481                	li	s1,0
    80001ad4:	b7e9                	j	80001a9e <proc_pagetable+0x4c>

0000000080001ad6 <proc_freepagetable>:
{
    80001ad6:	1101                	addi	sp,sp,-32
    80001ad8:	ec06                	sd	ra,24(sp)
    80001ada:	e822                	sd	s0,16(sp)
    80001adc:	e426                	sd	s1,8(sp)
    80001ade:	e04a                	sd	s2,0(sp)
    80001ae0:	1000                	addi	s0,sp,32
    80001ae2:	84aa                	mv	s1,a0
    80001ae4:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001ae6:	4681                	li	a3,0
    80001ae8:	4605                	li	a2,1
    80001aea:	040005b7          	lui	a1,0x4000
    80001aee:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001af0:	05b2                	slli	a1,a1,0xc
    80001af2:	f32ff0ef          	jal	80001224 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001af6:	4681                	li	a3,0
    80001af8:	4605                	li	a2,1
    80001afa:	020005b7          	lui	a1,0x2000
    80001afe:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001b00:	05b6                	slli	a1,a1,0xd
    80001b02:	8526                	mv	a0,s1
    80001b04:	f20ff0ef          	jal	80001224 <uvmunmap>
  uvmfree(pagetable, sz);
    80001b08:	85ca                	mv	a1,s2
    80001b0a:	8526                	mv	a0,s1
    80001b0c:	8edff0ef          	jal	800013f8 <uvmfree>
}
    80001b10:	60e2                	ld	ra,24(sp)
    80001b12:	6442                	ld	s0,16(sp)
    80001b14:	64a2                	ld	s1,8(sp)
    80001b16:	6902                	ld	s2,0(sp)
    80001b18:	6105                	addi	sp,sp,32
    80001b1a:	8082                	ret

0000000080001b1c <freeproc>:
{
    80001b1c:	1101                	addi	sp,sp,-32
    80001b1e:	ec06                	sd	ra,24(sp)
    80001b20:	e822                	sd	s0,16(sp)
    80001b22:	e426                	sd	s1,8(sp)
    80001b24:	1000                	addi	s0,sp,32
    80001b26:	84aa                	mv	s1,a0
  if (p->trapframe)
    80001b28:	6d28                	ld	a0,88(a0)
    80001b2a:	c119                	beqz	a0,80001b30 <freeproc+0x14>
    kfree((void *)p->trapframe);
    80001b2c:	f3bfe0ef          	jal	80000a66 <kfree>
  p->trapframe = 0;
    80001b30:	0404bc23          	sd	zero,88(s1)
  if (p->pagetable)
    80001b34:	68a8                	ld	a0,80(s1)
    80001b36:	c501                	beqz	a0,80001b3e <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001b38:	64ac                	ld	a1,72(s1)
    80001b3a:	f9dff0ef          	jal	80001ad6 <proc_freepagetable>
  p->pagetable = 0;
    80001b3e:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001b42:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001b46:	0204a823          	sw	zero,48(s1)
  p->name[0] = 0;
    80001b4a:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001b4e:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001b52:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001b56:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001b5a:	0004ac23          	sw	zero,24(s1)
}
    80001b5e:	60e2                	ld	ra,24(sp)
    80001b60:	6442                	ld	s0,16(sp)
    80001b62:	64a2                	ld	s1,8(sp)
    80001b64:	6105                	addi	sp,sp,32
    80001b66:	8082                	ret

0000000080001b68 <allocproc>:
{
    80001b68:	1101                	addi	sp,sp,-32
    80001b6a:	ec06                	sd	ra,24(sp)
    80001b6c:	e822                	sd	s0,16(sp)
    80001b6e:	e426                	sd	s1,8(sp)
    80001b70:	e04a                	sd	s2,0(sp)
    80001b72:	1000                	addi	s0,sp,32
  for (p = proc; p < &proc[NPROC]; p++) {
    80001b74:	00011497          	auipc	s1,0x11
    80001b78:	f4448493          	addi	s1,s1,-188 # 80012ab8 <proc>
    80001b7c:	00017917          	auipc	s2,0x17
    80001b80:	93c90913          	addi	s2,s2,-1732 # 800184b8 <tickslock>
    acquire(&p->lock);
    80001b84:	8526                	mv	a0,s1
    80001b86:	8a2ff0ef          	jal	80000c28 <acquire>
    if (p->state == UNUSED) {
    80001b8a:	4c9c                	lw	a5,24(s1)
    80001b8c:	cb91                	beqz	a5,80001ba0 <allocproc+0x38>
      release(&p->lock);
    80001b8e:	8526                	mv	a0,s1
    80001b90:	920ff0ef          	jal	80000cb0 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001b94:	16848493          	addi	s1,s1,360
    80001b98:	ff2496e3          	bne	s1,s2,80001b84 <allocproc+0x1c>
  return 0;
    80001b9c:	4481                	li	s1,0
    80001b9e:	a089                	j	80001be0 <allocproc+0x78>
  p->pid = allocpid();
    80001ba0:	e75ff0ef          	jal	80001a14 <allocpid>
    80001ba4:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001ba6:	4785                	li	a5,1
    80001ba8:	cc9c                	sw	a5,24(s1)
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    80001baa:	fa5fe0ef          	jal	80000b4e <kalloc>
    80001bae:	892a                	mv	s2,a0
    80001bb0:	eca8                	sd	a0,88(s1)
    80001bb2:	cd15                	beqz	a0,80001bee <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001bb4:	8526                	mv	a0,s1
    80001bb6:	e9dff0ef          	jal	80001a52 <proc_pagetable>
    80001bba:	892a                	mv	s2,a0
    80001bbc:	e8a8                	sd	a0,80(s1)
  if (p->pagetable == 0) {
    80001bbe:	c121                	beqz	a0,80001bfe <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001bc0:	07000613          	li	a2,112
    80001bc4:	4581                	li	a1,0
    80001bc6:	06048513          	addi	a0,s1,96
    80001bca:	91eff0ef          	jal	80000ce8 <memset>
  p->context.ra = (uint64)forkret;
    80001bce:	00000797          	auipc	a5,0x0
    80001bd2:	db078793          	addi	a5,a5,-592 # 8000197e <forkret>
    80001bd6:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001bd8:	60bc                	ld	a5,64(s1)
    80001bda:	6705                	lui	a4,0x1
    80001bdc:	97ba                	add	a5,a5,a4
    80001bde:	f4bc                	sd	a5,104(s1)
}
    80001be0:	8526                	mv	a0,s1
    80001be2:	60e2                	ld	ra,24(sp)
    80001be4:	6442                	ld	s0,16(sp)
    80001be6:	64a2                	ld	s1,8(sp)
    80001be8:	6902                	ld	s2,0(sp)
    80001bea:	6105                	addi	sp,sp,32
    80001bec:	8082                	ret
    freeproc(p);
    80001bee:	8526                	mv	a0,s1
    80001bf0:	f2dff0ef          	jal	80001b1c <freeproc>
    release(&p->lock);
    80001bf4:	8526                	mv	a0,s1
    80001bf6:	8baff0ef          	jal	80000cb0 <release>
    return 0;
    80001bfa:	84ca                	mv	s1,s2
    80001bfc:	b7d5                	j	80001be0 <allocproc+0x78>
    freeproc(p);
    80001bfe:	8526                	mv	a0,s1
    80001c00:	f1dff0ef          	jal	80001b1c <freeproc>
    release(&p->lock);
    80001c04:	8526                	mv	a0,s1
    80001c06:	8aaff0ef          	jal	80000cb0 <release>
    return 0;
    80001c0a:	84ca                	mv	s1,s2
    80001c0c:	bfd1                	j	80001be0 <allocproc+0x78>

0000000080001c0e <userinit>:
{
    80001c0e:	1101                	addi	sp,sp,-32
    80001c10:	ec06                	sd	ra,24(sp)
    80001c12:	e822                	sd	s0,16(sp)
    80001c14:	e426                	sd	s1,8(sp)
    80001c16:	1000                	addi	s0,sp,32
  p = allocproc();
    80001c18:	f51ff0ef          	jal	80001b68 <allocproc>
    80001c1c:	84aa                	mv	s1,a0
  initproc = p;
    80001c1e:	00009797          	auipc	a5,0x9
    80001c22:	94a7b923          	sd	a0,-1710(a5) # 8000a570 <initproc>
  p->cwd = namei("/");
    80001c26:	00005517          	auipc	a0,0x5
    80001c2a:	56a50513          	addi	a0,a0,1386 # 80007190 <etext+0x190>
    80001c2e:	73f010ef          	jal	80003b6c <namei>
    80001c32:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001c36:	478d                	li	a5,3
    80001c38:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001c3a:	8526                	mv	a0,s1
    80001c3c:	874ff0ef          	jal	80000cb0 <release>
}
    80001c40:	60e2                	ld	ra,24(sp)
    80001c42:	6442                	ld	s0,16(sp)
    80001c44:	64a2                	ld	s1,8(sp)
    80001c46:	6105                	addi	sp,sp,32
    80001c48:	8082                	ret

0000000080001c4a <growproc>:
{
    80001c4a:	1101                	addi	sp,sp,-32
    80001c4c:	ec06                	sd	ra,24(sp)
    80001c4e:	e822                	sd	s0,16(sp)
    80001c50:	e426                	sd	s1,8(sp)
    80001c52:	e04a                	sd	s2,0(sp)
    80001c54:	1000                	addi	s0,sp,32
    80001c56:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001c58:	cf5ff0ef          	jal	8000194c <myproc>
    80001c5c:	892a                	mv	s2,a0
  sz = p->sz;
    80001c5e:	652c                	ld	a1,72(a0)
  if (n > 0) {
    80001c60:	02905963          	blez	s1,80001c92 <growproc+0x48>
    if (sz + n > TRAPFRAME) {
    80001c64:	00b48633          	add	a2,s1,a1
    80001c68:	020007b7          	lui	a5,0x2000
    80001c6c:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001c6e:	07b6                	slli	a5,a5,0xd
    80001c70:	02c7ea63          	bltu	a5,a2,80001ca4 <growproc+0x5a>
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c74:	4691                	li	a3,4
    80001c76:	6928                	ld	a0,80(a0)
    80001c78:	e7aff0ef          	jal	800012f2 <uvmalloc>
    80001c7c:	85aa                	mv	a1,a0
    80001c7e:	c50d                	beqz	a0,80001ca8 <growproc+0x5e>
  p->sz = sz;
    80001c80:	04b93423          	sd	a1,72(s2)
  return 0;
    80001c84:	4501                	li	a0,0
}
    80001c86:	60e2                	ld	ra,24(sp)
    80001c88:	6442                	ld	s0,16(sp)
    80001c8a:	64a2                	ld	s1,8(sp)
    80001c8c:	6902                	ld	s2,0(sp)
    80001c8e:	6105                	addi	sp,sp,32
    80001c90:	8082                	ret
  } else if (n < 0) {
    80001c92:	fe04d7e3          	bgez	s1,80001c80 <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c96:	00b48633          	add	a2,s1,a1
    80001c9a:	6928                	ld	a0,80(a0)
    80001c9c:	e12ff0ef          	jal	800012ae <uvmdealloc>
    80001ca0:	85aa                	mv	a1,a0
    80001ca2:	bff9                	j	80001c80 <growproc+0x36>
      return -1;
    80001ca4:	557d                	li	a0,-1
    80001ca6:	b7c5                	j	80001c86 <growproc+0x3c>
      return -1;
    80001ca8:	557d                	li	a0,-1
    80001caa:	bff1                	j	80001c86 <growproc+0x3c>

0000000080001cac <kfork>:
{
    80001cac:	7139                	addi	sp,sp,-64
    80001cae:	fc06                	sd	ra,56(sp)
    80001cb0:	f822                	sd	s0,48(sp)
    80001cb2:	f426                	sd	s1,40(sp)
    80001cb4:	e456                	sd	s5,8(sp)
    80001cb6:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001cb8:	c95ff0ef          	jal	8000194c <myproc>
    80001cbc:	8aaa                	mv	s5,a0
  if ((np = allocproc()) == 0) {
    80001cbe:	eabff0ef          	jal	80001b68 <allocproc>
    80001cc2:	0e050a63          	beqz	a0,80001db6 <kfork+0x10a>
    80001cc6:	e852                	sd	s4,16(sp)
    80001cc8:	8a2a                	mv	s4,a0
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    80001cca:	048ab603          	ld	a2,72(s5)
    80001cce:	692c                	ld	a1,80(a0)
    80001cd0:	050ab503          	ld	a0,80(s5)
    80001cd4:	f56ff0ef          	jal	8000142a <uvmcopy>
    80001cd8:	04054863          	bltz	a0,80001d28 <kfork+0x7c>
    80001cdc:	f04a                	sd	s2,32(sp)
    80001cde:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001ce0:	048ab783          	ld	a5,72(s5)
    80001ce4:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001ce8:	058ab683          	ld	a3,88(s5)
    80001cec:	87b6                	mv	a5,a3
    80001cee:	058a3703          	ld	a4,88(s4)
    80001cf2:	12068693          	addi	a3,a3,288
    80001cf6:	6388                	ld	a0,0(a5)
    80001cf8:	678c                	ld	a1,8(a5)
    80001cfa:	6b90                	ld	a2,16(a5)
    80001cfc:	e308                	sd	a0,0(a4)
    80001cfe:	e70c                	sd	a1,8(a4)
    80001d00:	eb10                	sd	a2,16(a4)
    80001d02:	6f90                	ld	a2,24(a5)
    80001d04:	ef10                	sd	a2,24(a4)
    80001d06:	02078793          	addi	a5,a5,32
    80001d0a:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001d0e:	fed794e3          	bne	a5,a3,80001cf6 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001d12:	058a3783          	ld	a5,88(s4)
    80001d16:	0607b823          	sd	zero,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001d1a:	0d0a8493          	addi	s1,s5,208
    80001d1e:	0d0a0913          	addi	s2,s4,208
    80001d22:	150a8993          	addi	s3,s5,336
    80001d26:	a831                	j	80001d42 <kfork+0x96>
    freeproc(np);
    80001d28:	8552                	mv	a0,s4
    80001d2a:	df3ff0ef          	jal	80001b1c <freeproc>
    release(&np->lock);
    80001d2e:	8552                	mv	a0,s4
    80001d30:	f81fe0ef          	jal	80000cb0 <release>
    return -1;
    80001d34:	54fd                	li	s1,-1
    80001d36:	6a42                	ld	s4,16(sp)
    80001d38:	a885                	j	80001da8 <kfork+0xfc>
  for (i = 0; i < NOFILE; i++)
    80001d3a:	04a1                	addi	s1,s1,8
    80001d3c:	0921                	addi	s2,s2,8
    80001d3e:	01348963          	beq	s1,s3,80001d50 <kfork+0xa4>
    if (p->ofile[i])
    80001d42:	6088                	ld	a0,0(s1)
    80001d44:	d97d                	beqz	a0,80001d3a <kfork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    80001d46:	478020ef          	jal	800041be <filedup>
    80001d4a:	00a93023          	sd	a0,0(s2)
    80001d4e:	b7f5                	j	80001d3a <kfork+0x8e>
  np->cwd = idup(p->cwd);
    80001d50:	150ab503          	ld	a0,336(s5)
    80001d54:	548010ef          	jal	8000329c <idup>
    80001d58:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001d5c:	4641                	li	a2,16
    80001d5e:	158a8593          	addi	a1,s5,344
    80001d62:	158a0513          	addi	a0,s4,344
    80001d66:	8d6ff0ef          	jal	80000e3c <safestrcpy>
  pid = np->pid;
    80001d6a:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001d6e:	8552                	mv	a0,s4
    80001d70:	f41fe0ef          	jal	80000cb0 <release>
  acquire(&wait_lock);
    80001d74:	00011517          	auipc	a0,0x11
    80001d78:	92c50513          	addi	a0,a0,-1748 # 800126a0 <wait_lock>
    80001d7c:	eadfe0ef          	jal	80000c28 <acquire>
  np->parent = p;
    80001d80:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d84:	00011517          	auipc	a0,0x11
    80001d88:	91c50513          	addi	a0,a0,-1764 # 800126a0 <wait_lock>
    80001d8c:	f25fe0ef          	jal	80000cb0 <release>
  acquire(&np->lock);
    80001d90:	8552                	mv	a0,s4
    80001d92:	e97fe0ef          	jal	80000c28 <acquire>
  np->state = RUNNABLE;
    80001d96:	478d                	li	a5,3
    80001d98:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d9c:	8552                	mv	a0,s4
    80001d9e:	f13fe0ef          	jal	80000cb0 <release>
  return pid;
    80001da2:	7902                	ld	s2,32(sp)
    80001da4:	69e2                	ld	s3,24(sp)
    80001da6:	6a42                	ld	s4,16(sp)
}
    80001da8:	8526                	mv	a0,s1
    80001daa:	70e2                	ld	ra,56(sp)
    80001dac:	7442                	ld	s0,48(sp)
    80001dae:	74a2                	ld	s1,40(sp)
    80001db0:	6aa2                	ld	s5,8(sp)
    80001db2:	6121                	addi	sp,sp,64
    80001db4:	8082                	ret
    return -1;
    80001db6:	54fd                	li	s1,-1
    80001db8:	bfc5                	j	80001da8 <kfork+0xfc>

0000000080001dba <scheduler>:
{
    80001dba:	711d                	addi	sp,sp,-96
    80001dbc:	ec86                	sd	ra,88(sp)
    80001dbe:	e8a2                	sd	s0,80(sp)
    80001dc0:	e4a6                	sd	s1,72(sp)
    80001dc2:	e0ca                	sd	s2,64(sp)
    80001dc4:	fc4e                	sd	s3,56(sp)
    80001dc6:	f852                	sd	s4,48(sp)
    80001dc8:	f456                	sd	s5,40(sp)
    80001dca:	f05a                	sd	s6,32(sp)
    80001dcc:	ec5e                	sd	s7,24(sp)
    80001dce:	e862                	sd	s8,16(sp)
    80001dd0:	e466                	sd	s9,8(sp)
    80001dd2:	1080                	addi	s0,sp,96
    80001dd4:	8792                	mv	a5,tp
  int id = r_tp();
    80001dd6:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001dd8:	00779a93          	slli	s5,a5,0x7
    80001ddc:	00011717          	auipc	a4,0x11
    80001de0:	8ac70713          	addi	a4,a4,-1876 # 80012688 <pid_lock>
    80001de4:	9756                	add	a4,a4,s5
    80001de6:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001dea:	00011717          	auipc	a4,0x11
    80001dee:	8d670713          	addi	a4,a4,-1834 # 800126c0 <cpus+0x8>
    80001df2:	9aba                	add	s5,s5,a4
        p->state = RUNNING;
    80001df4:	4c11                	li	s8,4
        c->proc = p;
    80001df6:	00011b17          	auipc	s6,0x11
    80001dfa:	892b0b13          	addi	s6,s6,-1902 # 80012688 <pid_lock>
    80001dfe:	079e                	slli	a5,a5,0x7
    80001e00:	00fb0a33          	add	s4,s6,a5
        found = 1;
    80001e04:	4b85                	li	s7,1
    80001e06:	a0a9                	j	80001e50 <scheduler+0x96>
      release(&p->lock);
    80001e08:	8526                	mv	a0,s1
    80001e0a:	ea7fe0ef          	jal	80000cb0 <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    80001e0e:	16848493          	addi	s1,s1,360
    80001e12:	03248b63          	beq	s1,s2,80001e48 <scheduler+0x8e>
      acquire(&p->lock);
    80001e16:	8526                	mv	a0,s1
    80001e18:	e11fe0ef          	jal	80000c28 <acquire>
      if (p->state == RUNNABLE) {
    80001e1c:	4c9c                	lw	a5,24(s1)
    80001e1e:	ff3795e3          	bne	a5,s3,80001e08 <scheduler+0x4e>
        p->state = RUNNING;
    80001e22:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001e26:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001e2a:	06048593          	addi	a1,s1,96
    80001e2e:	8556                	mv	a0,s5
    80001e30:	5f4000ef          	jal	80002424 <swtch>
    80001e34:	8792                	mv	a5,tp
        mycpu()->intena = 0;
    80001e36:	2781                	sext.w	a5,a5
    80001e38:	079e                	slli	a5,a5,0x7
    80001e3a:	97da                	add	a5,a5,s6
    80001e3c:	0a07a623          	sw	zero,172(a5)
        c->proc = 0;
    80001e40:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001e44:	8cde                	mv	s9,s7
    80001e46:	b7c9                	j	80001e08 <scheduler+0x4e>
    if (found == 0) {
    80001e48:	000c9463          	bnez	s9,80001e50 <scheduler+0x96>
      asm volatile("wfi");
    80001e4c:	10500073          	wfi
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80001e50:	10016073          	csrsi	sstatus,2
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80001e54:	10017073          	csrci	sstatus,2
    int found = 0;
    80001e58:	4c81                	li	s9,0
    for (p = proc; p < &proc[NPROC]; p++) {
    80001e5a:	00011497          	auipc	s1,0x11
    80001e5e:	c5e48493          	addi	s1,s1,-930 # 80012ab8 <proc>
      if (p->state == RUNNABLE) {
    80001e62:	498d                	li	s3,3
    for (p = proc; p < &proc[NPROC]; p++) {
    80001e64:	00016917          	auipc	s2,0x16
    80001e68:	65490913          	addi	s2,s2,1620 # 800184b8 <tickslock>
    80001e6c:	b76d                	j	80001e16 <scheduler+0x5c>

0000000080001e6e <sched>:
{
    80001e6e:	7179                	addi	sp,sp,-48
    80001e70:	f406                	sd	ra,40(sp)
    80001e72:	f022                	sd	s0,32(sp)
    80001e74:	ec26                	sd	s1,24(sp)
    80001e76:	e84a                	sd	s2,16(sp)
    80001e78:	e44e                	sd	s3,8(sp)
    80001e7a:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e7c:	ad1ff0ef          	jal	8000194c <myproc>
    80001e80:	84aa                	mv	s1,a0
  if (!holding(&p->lock))
    80001e82:	d41fe0ef          	jal	80000bc2 <holding>
    80001e86:	c935                	beqz	a0,80001efa <sched+0x8c>
  asm volatile("mv %0, tp" : "=r"(x));
    80001e88:	8792                	mv	a5,tp
  if (mycpu()->noff != 1)
    80001e8a:	2781                	sext.w	a5,a5
    80001e8c:	079e                	slli	a5,a5,0x7
    80001e8e:	00010717          	auipc	a4,0x10
    80001e92:	7fa70713          	addi	a4,a4,2042 # 80012688 <pid_lock>
    80001e96:	97ba                	add	a5,a5,a4
    80001e98:	0a87a703          	lw	a4,168(a5)
    80001e9c:	4785                	li	a5,1
    80001e9e:	06f71463          	bne	a4,a5,80001f06 <sched+0x98>
  if (p->state == RUNNING)
    80001ea2:	4c98                	lw	a4,24(s1)
    80001ea4:	4791                	li	a5,4
    80001ea6:	06f70663          	beq	a4,a5,80001f12 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80001eaa:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001eae:	8b89                	andi	a5,a5,2
  if (intr_get())
    80001eb0:	e7bd                	bnez	a5,80001f1e <sched+0xb0>
  asm volatile("mv %0, tp" : "=r"(x));
    80001eb2:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001eb4:	00010917          	auipc	s2,0x10
    80001eb8:	7d490913          	addi	s2,s2,2004 # 80012688 <pid_lock>
    80001ebc:	2781                	sext.w	a5,a5
    80001ebe:	079e                	slli	a5,a5,0x7
    80001ec0:	97ca                	add	a5,a5,s2
    80001ec2:	0ac7a983          	lw	s3,172(a5)
    80001ec6:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001ec8:	2781                	sext.w	a5,a5
    80001eca:	079e                	slli	a5,a5,0x7
    80001ecc:	07a1                	addi	a5,a5,8
    80001ece:	00010597          	auipc	a1,0x10
    80001ed2:	7ea58593          	addi	a1,a1,2026 # 800126b8 <cpus>
    80001ed6:	95be                	add	a1,a1,a5
    80001ed8:	06048513          	addi	a0,s1,96
    80001edc:	548000ef          	jal	80002424 <swtch>
    80001ee0:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001ee2:	2781                	sext.w	a5,a5
    80001ee4:	079e                	slli	a5,a5,0x7
    80001ee6:	993e                	add	s2,s2,a5
    80001ee8:	0b392623          	sw	s3,172(s2)
}
    80001eec:	70a2                	ld	ra,40(sp)
    80001eee:	7402                	ld	s0,32(sp)
    80001ef0:	64e2                	ld	s1,24(sp)
    80001ef2:	6942                	ld	s2,16(sp)
    80001ef4:	69a2                	ld	s3,8(sp)
    80001ef6:	6145                	addi	sp,sp,48
    80001ef8:	8082                	ret
    panic("sched p->lock");
    80001efa:	00005517          	auipc	a0,0x5
    80001efe:	29e50513          	addi	a0,a0,670 # 80007198 <etext+0x198>
    80001f02:	933fe0ef          	jal	80000834 <panic>
    panic("sched locks");
    80001f06:	00005517          	auipc	a0,0x5
    80001f0a:	2a250513          	addi	a0,a0,674 # 800071a8 <etext+0x1a8>
    80001f0e:	927fe0ef          	jal	80000834 <panic>
    panic("sched RUNNING");
    80001f12:	00005517          	auipc	a0,0x5
    80001f16:	2a650513          	addi	a0,a0,678 # 800071b8 <etext+0x1b8>
    80001f1a:	91bfe0ef          	jal	80000834 <panic>
    panic("sched interruptible");
    80001f1e:	00005517          	auipc	a0,0x5
    80001f22:	2aa50513          	addi	a0,a0,682 # 800071c8 <etext+0x1c8>
    80001f26:	90ffe0ef          	jal	80000834 <panic>

0000000080001f2a <yield>:
{
    80001f2a:	1101                	addi	sp,sp,-32
    80001f2c:	ec06                	sd	ra,24(sp)
    80001f2e:	e822                	sd	s0,16(sp)
    80001f30:	e426                	sd	s1,8(sp)
    80001f32:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f34:	a19ff0ef          	jal	8000194c <myproc>
    80001f38:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001f3a:	ceffe0ef          	jal	80000c28 <acquire>
  p->state = RUNNABLE;
    80001f3e:	478d                	li	a5,3
    80001f40:	cc9c                	sw	a5,24(s1)
  sched();
    80001f42:	f2dff0ef          	jal	80001e6e <sched>
  release(&p->lock);
    80001f46:	8526                	mv	a0,s1
    80001f48:	d69fe0ef          	jal	80000cb0 <release>
}
    80001f4c:	60e2                	ld	ra,24(sp)
    80001f4e:	6442                	ld	s0,16(sp)
    80001f50:	64a2                	ld	s1,8(sp)
    80001f52:	6105                	addi	sp,sp,32
    80001f54:	8082                	ret

0000000080001f56 <sleep_prepare>:

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
    80001f56:	1101                	addi	sp,sp,-32
    80001f58:	ec06                	sd	ra,24(sp)
    80001f5a:	e822                	sd	s0,16(sp)
    80001f5c:	e426                	sd	s1,8(sp)
    80001f5e:	e04a                	sd	s2,0(sp)
    80001f60:	1000                	addi	s0,sp,32
    80001f62:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001f64:	9e9ff0ef          	jal	8000194c <myproc>
    80001f68:	892a                	mv	s2,a0

  acquire(&p->lock);
    80001f6a:	cbffe0ef          	jal	80000c28 <acquire>
  if (chan == 0)
    80001f6e:	cc81                	beqz	s1,80001f86 <sleep_prepare+0x30>
    panic("sleep_prepare: zero chan");
  p->chan = chan;
    80001f70:	02993023          	sd	s1,32(s2)
  release(&p->lock);
    80001f74:	854a                	mv	a0,s2
    80001f76:	d3bfe0ef          	jal	80000cb0 <release>
}
    80001f7a:	60e2                	ld	ra,24(sp)
    80001f7c:	6442                	ld	s0,16(sp)
    80001f7e:	64a2                	ld	s1,8(sp)
    80001f80:	6902                	ld	s2,0(sp)
    80001f82:	6105                	addi	sp,sp,32
    80001f84:	8082                	ret
    panic("sleep_prepare: zero chan");
    80001f86:	00005517          	auipc	a0,0x5
    80001f8a:	25a50513          	addi	a0,a0,602 # 800071e0 <etext+0x1e0>
    80001f8e:	8a7fe0ef          	jal	80000834 <panic>

0000000080001f92 <sleep>:
// Put the thread to sleep.  Assumes sleep_prepare() was called before.
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.
void
sleep(void)
{
    80001f92:	1101                	addi	sp,sp,-32
    80001f94:	ec06                	sd	ra,24(sp)
    80001f96:	e822                	sd	s0,16(sp)
    80001f98:	e426                	sd	s1,8(sp)
    80001f9a:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f9c:	9b1ff0ef          	jal	8000194c <myproc>
    80001fa0:	84aa                	mv	s1,a0

  acquire(&p->lock);
    80001fa2:	c87fe0ef          	jal	80000c28 <acquire>
  if (p->chan != 0) {
    80001fa6:	709c                	ld	a5,32(s1)
    80001fa8:	c789                	beqz	a5,80001fb2 <sleep+0x20>
    p->state = SLEEPING;
    80001faa:	4789                	li	a5,2
    80001fac:	cc9c                	sw	a5,24(s1)
    sched();
    80001fae:	ec1ff0ef          	jal	80001e6e <sched>
  }
  release(&p->lock);
    80001fb2:	8526                	mv	a0,s1
    80001fb4:	cfdfe0ef          	jal	80000cb0 <release>
}
    80001fb8:	60e2                	ld	ra,24(sp)
    80001fba:	6442                	ld	s0,16(sp)
    80001fbc:	64a2                	ld	s1,8(sp)
    80001fbe:	6105                	addi	sp,sp,32
    80001fc0:	8082                	ret

0000000080001fc2 <wakeup>:

// Wake up all processes sleeping on channel chan.
void
wakeup(void *chan)
{
    80001fc2:	7139                	addi	sp,sp,-64
    80001fc4:	fc06                	sd	ra,56(sp)
    80001fc6:	f822                	sd	s0,48(sp)
    80001fc8:	f426                	sd	s1,40(sp)
    80001fca:	f04a                	sd	s2,32(sp)
    80001fcc:	ec4e                	sd	s3,24(sp)
    80001fce:	e852                	sd	s4,16(sp)
    80001fd0:	e456                	sd	s5,8(sp)
    80001fd2:	0080                	addi	s0,sp,64
    80001fd4:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001fd6:	00011497          	auipc	s1,0x11
    80001fda:	ae248493          	addi	s1,s1,-1310 # 80012ab8 <proc>
      // signal that the wakeup happened by clearing p->chan.
      p->chan = 0;

      // If this waiting process has gotten so far as to actually
      // go to sleep, also set it back to RUNNING.
      if (p->state == SLEEPING) {
    80001fde:	4a09                	li	s4,2
        p->state = RUNNABLE;
    80001fe0:	4a8d                	li	s5,3
  for (p = proc; p < &proc[NPROC]; p++) {
    80001fe2:	00016997          	auipc	s3,0x16
    80001fe6:	4d698993          	addi	s3,s3,1238 # 800184b8 <tickslock>
    80001fea:	a801                	j	80001ffa <wakeup+0x38>
      }
    }
    release(&p->lock);
    80001fec:	8526                	mv	a0,s1
    80001fee:	cc3fe0ef          	jal	80000cb0 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001ff2:	16848493          	addi	s1,s1,360
    80001ff6:	03348063          	beq	s1,s3,80002016 <wakeup+0x54>
    acquire(&p->lock);
    80001ffa:	8526                	mv	a0,s1
    80001ffc:	c2dfe0ef          	jal	80000c28 <acquire>
    if (p->chan == chan) {
    80002000:	709c                	ld	a5,32(s1)
    80002002:	ff2795e3          	bne	a5,s2,80001fec <wakeup+0x2a>
      p->chan = 0;
    80002006:	0204b023          	sd	zero,32(s1)
      if (p->state == SLEEPING) {
    8000200a:	4c9c                	lw	a5,24(s1)
    8000200c:	ff4790e3          	bne	a5,s4,80001fec <wakeup+0x2a>
        p->state = RUNNABLE;
    80002010:	0154ac23          	sw	s5,24(s1)
    80002014:	bfe1                	j	80001fec <wakeup+0x2a>
  }
}
    80002016:	70e2                	ld	ra,56(sp)
    80002018:	7442                	ld	s0,48(sp)
    8000201a:	74a2                	ld	s1,40(sp)
    8000201c:	7902                	ld	s2,32(sp)
    8000201e:	69e2                	ld	s3,24(sp)
    80002020:	6a42                	ld	s4,16(sp)
    80002022:	6aa2                	ld	s5,8(sp)
    80002024:	6121                	addi	sp,sp,64
    80002026:	8082                	ret

0000000080002028 <reparent>:
{
    80002028:	7179                	addi	sp,sp,-48
    8000202a:	f406                	sd	ra,40(sp)
    8000202c:	f022                	sd	s0,32(sp)
    8000202e:	ec26                	sd	s1,24(sp)
    80002030:	e84a                	sd	s2,16(sp)
    80002032:	e44e                	sd	s3,8(sp)
    80002034:	e052                	sd	s4,0(sp)
    80002036:	1800                	addi	s0,sp,48
    80002038:	892a                	mv	s2,a0
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000203a:	00011497          	auipc	s1,0x11
    8000203e:	a7e48493          	addi	s1,s1,-1410 # 80012ab8 <proc>
      pp->parent = initproc;
    80002042:	00008a17          	auipc	s4,0x8
    80002046:	52ea0a13          	addi	s4,s4,1326 # 8000a570 <initproc>
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000204a:	00016997          	auipc	s3,0x16
    8000204e:	46e98993          	addi	s3,s3,1134 # 800184b8 <tickslock>
    80002052:	a029                	j	8000205c <reparent+0x34>
    80002054:	16848493          	addi	s1,s1,360
    80002058:	01348b63          	beq	s1,s3,8000206e <reparent+0x46>
    if (pp->parent == p) {
    8000205c:	7c9c                	ld	a5,56(s1)
    8000205e:	ff279be3          	bne	a5,s2,80002054 <reparent+0x2c>
      pp->parent = initproc;
    80002062:	000a3503          	ld	a0,0(s4)
    80002066:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80002068:	f5bff0ef          	jal	80001fc2 <wakeup>
    8000206c:	b7e5                	j	80002054 <reparent+0x2c>
}
    8000206e:	70a2                	ld	ra,40(sp)
    80002070:	7402                	ld	s0,32(sp)
    80002072:	64e2                	ld	s1,24(sp)
    80002074:	6942                	ld	s2,16(sp)
    80002076:	69a2                	ld	s3,8(sp)
    80002078:	6a02                	ld	s4,0(sp)
    8000207a:	6145                	addi	sp,sp,48
    8000207c:	8082                	ret

000000008000207e <kexit>:
{
    8000207e:	7179                	addi	sp,sp,-48
    80002080:	f406                	sd	ra,40(sp)
    80002082:	f022                	sd	s0,32(sp)
    80002084:	ec26                	sd	s1,24(sp)
    80002086:	e84a                	sd	s2,16(sp)
    80002088:	e44e                	sd	s3,8(sp)
    8000208a:	e052                	sd	s4,0(sp)
    8000208c:	1800                	addi	s0,sp,48
    8000208e:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002090:	8bdff0ef          	jal	8000194c <myproc>
    80002094:	89aa                	mv	s3,a0
  if (p == initproc)
    80002096:	00008797          	auipc	a5,0x8
    8000209a:	4da7b783          	ld	a5,1242(a5) # 8000a570 <initproc>
    8000209e:	0d050493          	addi	s1,a0,208
    800020a2:	15050913          	addi	s2,a0,336
    800020a6:	00a79b63          	bne	a5,a0,800020bc <kexit+0x3e>
    panic("init exiting");
    800020aa:	00005517          	auipc	a0,0x5
    800020ae:	15650513          	addi	a0,a0,342 # 80007200 <etext+0x200>
    800020b2:	f82fe0ef          	jal	80000834 <panic>
  for (int fd = 0; fd < NOFILE; fd++) {
    800020b6:	04a1                	addi	s1,s1,8
    800020b8:	01248963          	beq	s1,s2,800020ca <kexit+0x4c>
    if (p->ofile[fd]) {
    800020bc:	6088                	ld	a0,0(s1)
    800020be:	dd65                	beqz	a0,800020b6 <kexit+0x38>
      fileclose(f);
    800020c0:	144020ef          	jal	80004204 <fileclose>
      p->ofile[fd] = 0;
    800020c4:	0004b023          	sd	zero,0(s1)
    800020c8:	b7fd                	j	800020b6 <kexit+0x38>
  begin_op();
    800020ca:	481010ef          	jal	80003d4a <begin_op>
  iput(p->cwd);
    800020ce:	1509b503          	ld	a0,336(s3)
    800020d2:	382010ef          	jal	80003454 <iput>
  end_op();
    800020d6:	501010ef          	jal	80003dd6 <end_op>
  p->cwd = 0;
    800020da:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800020de:	00010517          	auipc	a0,0x10
    800020e2:	5c250513          	addi	a0,a0,1474 # 800126a0 <wait_lock>
    800020e6:	b43fe0ef          	jal	80000c28 <acquire>
  reparent(p);
    800020ea:	854e                	mv	a0,s3
    800020ec:	f3dff0ef          	jal	80002028 <reparent>
  wakeup(p->parent);
    800020f0:	0389b503          	ld	a0,56(s3)
    800020f4:	ecfff0ef          	jal	80001fc2 <wakeup>
  acquire(&p->lock);
    800020f8:	854e                	mv	a0,s3
    800020fa:	b2ffe0ef          	jal	80000c28 <acquire>
  p->xstate = status;
    800020fe:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002102:	4795                	li	a5,5
    80002104:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80002108:	00010517          	auipc	a0,0x10
    8000210c:	59850513          	addi	a0,a0,1432 # 800126a0 <wait_lock>
    80002110:	ba1fe0ef          	jal	80000cb0 <release>
  sched();
    80002114:	d5bff0ef          	jal	80001e6e <sched>
  panic("zombie exit");
    80002118:	00005517          	auipc	a0,0x5
    8000211c:	0f850513          	addi	a0,a0,248 # 80007210 <etext+0x210>
    80002120:	f14fe0ef          	jal	80000834 <panic>

0000000080002124 <kkill>:
int
kkill(int pid)
{
  struct proc *p;

  if (pid == 0)
    80002124:	c525                	beqz	a0,8000218c <kkill+0x68>
{
    80002126:	7179                	addi	sp,sp,-48
    80002128:	f406                	sd	ra,40(sp)
    8000212a:	f022                	sd	s0,32(sp)
    8000212c:	ec26                	sd	s1,24(sp)
    8000212e:	e84a                	sd	s2,16(sp)
    80002130:	e44e                	sd	s3,8(sp)
    80002132:	1800                	addi	s0,sp,48
    80002134:	892a                	mv	s2,a0
    return -1;

  for (p = proc; p < &proc[NPROC]; p++) {
    80002136:	00011497          	auipc	s1,0x11
    8000213a:	98248493          	addi	s1,s1,-1662 # 80012ab8 <proc>
    8000213e:	00016997          	auipc	s3,0x16
    80002142:	37a98993          	addi	s3,s3,890 # 800184b8 <tickslock>
    acquire(&p->lock);
    80002146:	8526                	mv	a0,s1
    80002148:	ae1fe0ef          	jal	80000c28 <acquire>
    if (p->pid == pid) {
    8000214c:	589c                	lw	a5,48(s1)
    8000214e:	01278b63          	beq	a5,s2,80002164 <kkill+0x40>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002152:	8526                	mv	a0,s1
    80002154:	b5dfe0ef          	jal	80000cb0 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002158:	16848493          	addi	s1,s1,360
    8000215c:	ff3495e3          	bne	s1,s3,80002146 <kkill+0x22>
  }
  return -1;
    80002160:	557d                	li	a0,-1
    80002162:	a819                	j	80002178 <kkill+0x54>
      p->killed = 1;
    80002164:	4785                	li	a5,1
    80002166:	d49c                	sw	a5,40(s1)
      if (p->state == SLEEPING) {
    80002168:	4c98                	lw	a4,24(s1)
    8000216a:	4789                	li	a5,2
    8000216c:	00f70d63          	beq	a4,a5,80002186 <kkill+0x62>
      release(&p->lock);
    80002170:	8526                	mv	a0,s1
    80002172:	b3ffe0ef          	jal	80000cb0 <release>
      return 0;
    80002176:	4501                	li	a0,0
}
    80002178:	70a2                	ld	ra,40(sp)
    8000217a:	7402                	ld	s0,32(sp)
    8000217c:	64e2                	ld	s1,24(sp)
    8000217e:	6942                	ld	s2,16(sp)
    80002180:	69a2                	ld	s3,8(sp)
    80002182:	6145                	addi	sp,sp,48
    80002184:	8082                	ret
        p->state = RUNNABLE;
    80002186:	478d                	li	a5,3
    80002188:	cc9c                	sw	a5,24(s1)
    8000218a:	b7dd                	j	80002170 <kkill+0x4c>
    return -1;
    8000218c:	557d                	li	a0,-1
}
    8000218e:	8082                	ret

0000000080002190 <setkilled>:

void
setkilled(struct proc *p)
{
    80002190:	1101                	addi	sp,sp,-32
    80002192:	ec06                	sd	ra,24(sp)
    80002194:	e822                	sd	s0,16(sp)
    80002196:	e426                	sd	s1,8(sp)
    80002198:	1000                	addi	s0,sp,32
    8000219a:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000219c:	a8dfe0ef          	jal	80000c28 <acquire>
  p->killed = 1;
    800021a0:	4785                	li	a5,1
    800021a2:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800021a4:	8526                	mv	a0,s1
    800021a6:	b0bfe0ef          	jal	80000cb0 <release>
}
    800021aa:	60e2                	ld	ra,24(sp)
    800021ac:	6442                	ld	s0,16(sp)
    800021ae:	64a2                	ld	s1,8(sp)
    800021b0:	6105                	addi	sp,sp,32
    800021b2:	8082                	ret

00000000800021b4 <killed>:

int
killed(struct proc *p)
{
    800021b4:	1101                	addi	sp,sp,-32
    800021b6:	ec06                	sd	ra,24(sp)
    800021b8:	e822                	sd	s0,16(sp)
    800021ba:	e426                	sd	s1,8(sp)
    800021bc:	e04a                	sd	s2,0(sp)
    800021be:	1000                	addi	s0,sp,32
    800021c0:	84aa                	mv	s1,a0
  int k;

  acquire(&p->lock);
    800021c2:	a67fe0ef          	jal	80000c28 <acquire>
  k = p->killed;
    800021c6:	549c                	lw	a5,40(s1)
    800021c8:	893e                	mv	s2,a5
  release(&p->lock);
    800021ca:	8526                	mv	a0,s1
    800021cc:	ae5fe0ef          	jal	80000cb0 <release>
  return k;
}
    800021d0:	854a                	mv	a0,s2
    800021d2:	60e2                	ld	ra,24(sp)
    800021d4:	6442                	ld	s0,16(sp)
    800021d6:	64a2                	ld	s1,8(sp)
    800021d8:	6902                	ld	s2,0(sp)
    800021da:	6105                	addi	sp,sp,32
    800021dc:	8082                	ret

00000000800021de <kwait>:
{
    800021de:	715d                	addi	sp,sp,-80
    800021e0:	e486                	sd	ra,72(sp)
    800021e2:	e0a2                	sd	s0,64(sp)
    800021e4:	fc26                	sd	s1,56(sp)
    800021e6:	f84a                	sd	s2,48(sp)
    800021e8:	f44e                	sd	s3,40(sp)
    800021ea:	f052                	sd	s4,32(sp)
    800021ec:	ec56                	sd	s5,24(sp)
    800021ee:	e85a                	sd	s6,16(sp)
    800021f0:	e45e                	sd	s7,8(sp)
    800021f2:	0880                	addi	s0,sp,80
    800021f4:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    800021f6:	f56ff0ef          	jal	8000194c <myproc>
    800021fa:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800021fc:	00010517          	auipc	a0,0x10
    80002200:	4a450513          	addi	a0,a0,1188 # 800126a0 <wait_lock>
    80002204:	a25fe0ef          	jal	80000c28 <acquire>
        if (pp->state == ZOMBIE) {
    80002208:	4a15                	li	s4,5
        havekids = 1;
    8000220a:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000220c:	00016997          	auipc	s3,0x16
    80002210:	2ac98993          	addi	s3,s3,684 # 800184b8 <tickslock>
    release(&wait_lock);
    80002214:	00010b17          	auipc	s6,0x10
    80002218:	48cb0b13          	addi	s6,s6,1164 # 800126a0 <wait_lock>
    8000221c:	a845                	j	800022cc <kwait+0xee>
          pid = pp->pid;
    8000221e:	0304a983          	lw	s3,48(s1)
          if (addr != 0 &&
    80002222:	000b8e63          	beqz	s7,8000223e <kwait+0x60>
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
    80002226:	4711                	li	a4,4
    80002228:	02c48693          	addi	a3,s1,44
    8000222c:	865e                	mv	a2,s7
    8000222e:	04893583          	ld	a1,72(s2)
    80002232:	05093503          	ld	a0,80(s2)
    80002236:	b50ff0ef          	jal	80001586 <copyout>
          if (addr != 0 &&
    8000223a:	02054c63          	bltz	a0,80002272 <kwait+0x94>
          pp->parent = 0;
    8000223e:	0204bc23          	sd	zero,56(s1)
          freeproc(pp);
    80002242:	8526                	mv	a0,s1
    80002244:	8d9ff0ef          	jal	80001b1c <freeproc>
          release(&pp->lock);
    80002248:	8526                	mv	a0,s1
    8000224a:	a67fe0ef          	jal	80000cb0 <release>
          release(&wait_lock);
    8000224e:	00010517          	auipc	a0,0x10
    80002252:	45250513          	addi	a0,a0,1106 # 800126a0 <wait_lock>
    80002256:	a5bfe0ef          	jal	80000cb0 <release>
}
    8000225a:	854e                	mv	a0,s3
    8000225c:	60a6                	ld	ra,72(sp)
    8000225e:	6406                	ld	s0,64(sp)
    80002260:	74e2                	ld	s1,56(sp)
    80002262:	7942                	ld	s2,48(sp)
    80002264:	79a2                	ld	s3,40(sp)
    80002266:	7a02                	ld	s4,32(sp)
    80002268:	6ae2                	ld	s5,24(sp)
    8000226a:	6b42                	ld	s6,16(sp)
    8000226c:	6ba2                	ld	s7,8(sp)
    8000226e:	6161                	addi	sp,sp,80
    80002270:	8082                	ret
            release(&pp->lock);
    80002272:	8526                	mv	a0,s1
    80002274:	a3dfe0ef          	jal	80000cb0 <release>
            release(&wait_lock);
    80002278:	00010517          	auipc	a0,0x10
    8000227c:	42850513          	addi	a0,a0,1064 # 800126a0 <wait_lock>
    80002280:	a31fe0ef          	jal	80000cb0 <release>
            return -1;
    80002284:	59fd                	li	s3,-1
    80002286:	bfd1                	j	8000225a <kwait+0x7c>
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002288:	16848493          	addi	s1,s1,360
    8000228c:	03348063          	beq	s1,s3,800022ac <kwait+0xce>
      if (pp->parent == p) {
    80002290:	7c9c                	ld	a5,56(s1)
    80002292:	ff279be3          	bne	a5,s2,80002288 <kwait+0xaa>
        acquire(&pp->lock);
    80002296:	8526                	mv	a0,s1
    80002298:	991fe0ef          	jal	80000c28 <acquire>
        if (pp->state == ZOMBIE) {
    8000229c:	4c9c                	lw	a5,24(s1)
    8000229e:	f94780e3          	beq	a5,s4,8000221e <kwait+0x40>
        release(&pp->lock);
    800022a2:	8526                	mv	a0,s1
    800022a4:	a0dfe0ef          	jal	80000cb0 <release>
        havekids = 1;
    800022a8:	8756                	mv	a4,s5
    800022aa:	bff9                	j	80002288 <kwait+0xaa>
    if (!havekids || killed(p)) {
    800022ac:	c715                	beqz	a4,800022d8 <kwait+0xfa>
    800022ae:	854a                	mv	a0,s2
    800022b0:	f05ff0ef          	jal	800021b4 <killed>
    800022b4:	e115                	bnez	a0,800022d8 <kwait+0xfa>
    sleep_prepare(p); //DOC: wait-sleep
    800022b6:	854a                	mv	a0,s2
    800022b8:	c9fff0ef          	jal	80001f56 <sleep_prepare>
    release(&wait_lock);
    800022bc:	855a                	mv	a0,s6
    800022be:	9f3fe0ef          	jal	80000cb0 <release>
    sleep();
    800022c2:	cd1ff0ef          	jal	80001f92 <sleep>
    acquire(&wait_lock);
    800022c6:	855a                	mv	a0,s6
    800022c8:	961fe0ef          	jal	80000c28 <acquire>
    havekids = 0;
    800022cc:	4701                	li	a4,0
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800022ce:	00010497          	auipc	s1,0x10
    800022d2:	7ea48493          	addi	s1,s1,2026 # 80012ab8 <proc>
    800022d6:	bf6d                	j	80002290 <kwait+0xb2>
      release(&wait_lock);
    800022d8:	00010517          	auipc	a0,0x10
    800022dc:	3c850513          	addi	a0,a0,968 # 800126a0 <wait_lock>
    800022e0:	9d1fe0ef          	jal	80000cb0 <release>
      return -1;
    800022e4:	59fd                	li	s3,-1
    800022e6:	bf95                	j	8000225a <kwait+0x7c>

00000000800022e8 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800022e8:	7179                	addi	sp,sp,-48
    800022ea:	f406                	sd	ra,40(sp)
    800022ec:	f022                	sd	s0,32(sp)
    800022ee:	ec26                	sd	s1,24(sp)
    800022f0:	e84a                	sd	s2,16(sp)
    800022f2:	e44e                	sd	s3,8(sp)
    800022f4:	e052                	sd	s4,0(sp)
    800022f6:	1800                	addi	s0,sp,48
    800022f8:	84aa                	mv	s1,a0
    800022fa:	8a2e                	mv	s4,a1
    800022fc:	89b2                	mv	s3,a2
    800022fe:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002300:	e4cff0ef          	jal	8000194c <myproc>
  if (user_dst) {
    80002304:	c085                	beqz	s1,80002324 <either_copyout+0x3c>
    return copyout(p->pagetable, p->sz, dst, src, len);
    80002306:	874a                	mv	a4,s2
    80002308:	86ce                	mv	a3,s3
    8000230a:	8652                	mv	a2,s4
    8000230c:	652c                	ld	a1,72(a0)
    8000230e:	6928                	ld	a0,80(a0)
    80002310:	a76ff0ef          	jal	80001586 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002314:	70a2                	ld	ra,40(sp)
    80002316:	7402                	ld	s0,32(sp)
    80002318:	64e2                	ld	s1,24(sp)
    8000231a:	6942                	ld	s2,16(sp)
    8000231c:	69a2                	ld	s3,8(sp)
    8000231e:	6a02                	ld	s4,0(sp)
    80002320:	6145                	addi	sp,sp,48
    80002322:	8082                	ret
    memmove((char *)dst, src, len);
    80002324:	0009061b          	sext.w	a2,s2
    80002328:	85ce                	mv	a1,s3
    8000232a:	8552                	mv	a0,s4
    8000232c:	a1dfe0ef          	jal	80000d48 <memmove>
    return 0;
    80002330:	8526                	mv	a0,s1
    80002332:	b7cd                	j	80002314 <either_copyout+0x2c>

0000000080002334 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002334:	7179                	addi	sp,sp,-48
    80002336:	f406                	sd	ra,40(sp)
    80002338:	f022                	sd	s0,32(sp)
    8000233a:	ec26                	sd	s1,24(sp)
    8000233c:	e84a                	sd	s2,16(sp)
    8000233e:	e44e                	sd	s3,8(sp)
    80002340:	e052                	sd	s4,0(sp)
    80002342:	1800                	addi	s0,sp,48
    80002344:	8a2a                	mv	s4,a0
    80002346:	84ae                	mv	s1,a1
    80002348:	89b2                	mv	s3,a2
    8000234a:	8936                	mv	s2,a3
  struct proc *p = myproc();
    8000234c:	e00ff0ef          	jal	8000194c <myproc>
  if (user_src) {
    80002350:	c085                	beqz	s1,80002370 <either_copyin+0x3c>
    return copyin(p->pagetable, p->sz, dst, src, len);
    80002352:	874a                	mv	a4,s2
    80002354:	86ce                	mv	a3,s3
    80002356:	8652                	mv	a2,s4
    80002358:	652c                	ld	a1,72(a0)
    8000235a:	6928                	ld	a0,80(a0)
    8000235c:	af0ff0ef          	jal	8000164c <copyin>
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}
    80002360:	70a2                	ld	ra,40(sp)
    80002362:	7402                	ld	s0,32(sp)
    80002364:	64e2                	ld	s1,24(sp)
    80002366:	6942                	ld	s2,16(sp)
    80002368:	69a2                	ld	s3,8(sp)
    8000236a:	6a02                	ld	s4,0(sp)
    8000236c:	6145                	addi	sp,sp,48
    8000236e:	8082                	ret
    memmove(dst, (char *)src, len);
    80002370:	0009061b          	sext.w	a2,s2
    80002374:	85ce                	mv	a1,s3
    80002376:	8552                	mv	a0,s4
    80002378:	9d1fe0ef          	jal	80000d48 <memmove>
    return 0;
    8000237c:	8526                	mv	a0,s1
    8000237e:	b7cd                	j	80002360 <either_copyin+0x2c>

0000000080002380 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80002380:	715d                	addi	sp,sp,-80
    80002382:	e486                	sd	ra,72(sp)
    80002384:	e0a2                	sd	s0,64(sp)
    80002386:	fc26                	sd	s1,56(sp)
    80002388:	f84a                	sd	s2,48(sp)
    8000238a:	f44e                	sd	s3,40(sp)
    8000238c:	f052                	sd	s4,32(sp)
    8000238e:	ec56                	sd	s5,24(sp)
    80002390:	e85a                	sd	s6,16(sp)
    80002392:	e45e                	sd	s7,8(sp)
    80002394:	0880                	addi	s0,sp,80
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
    80002396:	00005517          	auipc	a0,0x5
    8000239a:	ce250513          	addi	a0,a0,-798 # 80007078 <etext+0x78>
    8000239e:	96cfe0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    800023a2:	00011497          	auipc	s1,0x11
    800023a6:	86e48493          	addi	s1,s1,-1938 # 80012c10 <proc+0x158>
    800023aa:	00016917          	auipc	s2,0x16
    800023ae:	26690913          	addi	s2,s2,614 # 80018610 <bcache+0x140>
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023b2:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800023b4:	00005997          	auipc	s3,0x5
    800023b8:	e6c98993          	addi	s3,s3,-404 # 80007220 <etext+0x220>
    printk("%d %s %s", p->pid, state, p->name);
    800023bc:	00005a97          	auipc	s5,0x5
    800023c0:	e6ca8a93          	addi	s5,s5,-404 # 80007228 <etext+0x228>
    printk("\n");
    800023c4:	00005a17          	auipc	s4,0x5
    800023c8:	cb4a0a13          	addi	s4,s4,-844 # 80007078 <etext+0x78>
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023cc:	00005b97          	auipc	s7,0x5
    800023d0:	494b8b93          	addi	s7,s7,1172 # 80007860 <states.0>
    800023d4:	a829                	j	800023ee <procdump+0x6e>
    printk("%d %s %s", p->pid, state, p->name);
    800023d6:	ed86a583          	lw	a1,-296(a3)
    800023da:	8556                	mv	a0,s5
    800023dc:	92efe0ef          	jal	8000050a <printk>
    printk("\n");
    800023e0:	8552                	mv	a0,s4
    800023e2:	928fe0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    800023e6:	16848493          	addi	s1,s1,360
    800023ea:	03248263          	beq	s1,s2,8000240e <procdump+0x8e>
    if (p->state == UNUSED)
    800023ee:	86a6                	mv	a3,s1
    800023f0:	ec04a783          	lw	a5,-320(s1)
    800023f4:	dbed                	beqz	a5,800023e6 <procdump+0x66>
      state = "???";
    800023f6:	864e                	mv	a2,s3
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023f8:	fcfb6fe3          	bltu	s6,a5,800023d6 <procdump+0x56>
    800023fc:	02079713          	slli	a4,a5,0x20
    80002400:	01d75793          	srli	a5,a4,0x1d
    80002404:	97de                	add	a5,a5,s7
    80002406:	6390                	ld	a2,0(a5)
    80002408:	f679                	bnez	a2,800023d6 <procdump+0x56>
      state = "???";
    8000240a:	864e                	mv	a2,s3
    8000240c:	b7e9                	j	800023d6 <procdump+0x56>
  }
}
    8000240e:	60a6                	ld	ra,72(sp)
    80002410:	6406                	ld	s0,64(sp)
    80002412:	74e2                	ld	s1,56(sp)
    80002414:	7942                	ld	s2,48(sp)
    80002416:	79a2                	ld	s3,40(sp)
    80002418:	7a02                	ld	s4,32(sp)
    8000241a:	6ae2                	ld	s5,24(sp)
    8000241c:	6b42                	ld	s6,16(sp)
    8000241e:	6ba2                	ld	s7,8(sp)
    80002420:	6161                	addi	sp,sp,80
    80002422:	8082                	ret

0000000080002424 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    80002424:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    80002428:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    8000242c:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    8000242e:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    80002430:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    80002434:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    80002438:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    8000243c:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    80002440:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    80002444:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    80002448:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    8000244c:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    80002450:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    80002454:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    80002458:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    8000245c:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    80002460:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    80002462:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002464:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    80002468:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    8000246c:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    80002470:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002474:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    80002478:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    8000247c:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    80002480:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002484:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    80002488:	0685bd83          	ld	s11,104(a1)
        
        ret
    8000248c:	8082                	ret

000000008000248e <trapinit>:

extern int devintr();

void
trapinit(void)
{
    8000248e:	1141                	addi	sp,sp,-16
    80002490:	e406                	sd	ra,8(sp)
    80002492:	e022                	sd	s0,0(sp)
    80002494:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002496:	00005597          	auipc	a1,0x5
    8000249a:	dd258593          	addi	a1,a1,-558 # 80007268 <etext+0x268>
    8000249e:	00016517          	auipc	a0,0x16
    800024a2:	01a50513          	addi	a0,a0,26 # 800184b8 <tickslock>
    800024a6:	f02fe0ef          	jal	80000ba8 <initlock>
}
    800024aa:	60a2                	ld	ra,8(sp)
    800024ac:	6402                	ld	s0,0(sp)
    800024ae:	0141                	addi	sp,sp,16
    800024b0:	8082                	ret

00000000800024b2 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    800024b2:	1141                	addi	sp,sp,-16
    800024b4:	e406                	sd	ra,8(sp)
    800024b6:	e022                	sd	s0,0(sp)
    800024b8:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    800024ba:	00003797          	auipc	a5,0x3
    800024be:	1b678793          	addi	a5,a5,438 # 80005670 <kernelvec>
    800024c2:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    800024c6:	60a2                	ld	ra,8(sp)
    800024c8:	6402                	ld	s0,0(sp)
    800024ca:	0141                	addi	sp,sp,16
    800024cc:	8082                	ret

00000000800024ce <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    800024ce:	1141                	addi	sp,sp,-16
    800024d0:	e406                	sd	ra,8(sp)
    800024d2:	e022                	sd	s0,0(sp)
    800024d4:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800024d6:	c76ff0ef          	jal	8000194c <myproc>
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    800024da:	10017073          	csrci	sstatus,2
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800024de:	04000737          	lui	a4,0x4000
    800024e2:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800024e4:	0732                	slli	a4,a4,0xc
    800024e6:	00004797          	auipc	a5,0x4
    800024ea:	b1a78793          	addi	a5,a5,-1254 # 80006000 <_trampoline>
    800024ee:	00004697          	auipc	a3,0x4
    800024f2:	b1268693          	addi	a3,a3,-1262 # 80006000 <_trampoline>
    800024f6:	8f95                	sub	a5,a5,a3
    800024f8:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r"(x));
    800024fa:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800024fe:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    80002500:	18002773          	csrr	a4,satp
    80002504:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002506:	6d38                	ld	a4,88(a0)
    80002508:	613c                	ld	a5,64(a0)
    8000250a:	6685                	lui	a3,0x1
    8000250c:	97b6                	add	a5,a5,a3
    8000250e:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002510:	6d3c                	ld	a5,88(a0)
    80002512:	00000717          	auipc	a4,0x0
    80002516:	0fc70713          	addi	a4,a4,252 # 8000260e <usertrap>
    8000251a:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    8000251c:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    8000251e:	8712                	mv	a4,tp
    80002520:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002522:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002526:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    8000252a:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    8000252e:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002532:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    80002534:	6f9c                	ld	a5,24(a5)
    80002536:	14179073          	csrw	sepc,a5
}
    8000253a:	60a2                	ld	ra,8(sp)
    8000253c:	6402                	ld	s0,0(sp)
    8000253e:	0141                	addi	sp,sp,16
    80002540:	8082                	ret

0000000080002542 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002542:	1141                	addi	sp,sp,-16
    80002544:	e406                	sd	ra,8(sp)
    80002546:	e022                	sd	s0,0(sp)
    80002548:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    8000254a:	bceff0ef          	jal	80001918 <cpuid>
    8000254e:	cd11                	beqz	a0,8000256a <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r"(x));
    80002550:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80002554:	000f4737          	lui	a4,0xf4
    80002558:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000255c:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000255e:	14d79073          	csrw	stimecmp,a5
}
    80002562:	60a2                	ld	ra,8(sp)
    80002564:	6402                	ld	s0,0(sp)
    80002566:	0141                	addi	sp,sp,16
    80002568:	8082                	ret
    acquire(&tickslock);
    8000256a:	00016517          	auipc	a0,0x16
    8000256e:	f4e50513          	addi	a0,a0,-178 # 800184b8 <tickslock>
    80002572:	eb6fe0ef          	jal	80000c28 <acquire>
    ticks++;
    80002576:	00008717          	auipc	a4,0x8
    8000257a:	00270713          	addi	a4,a4,2 # 8000a578 <ticks>
    8000257e:	431c                	lw	a5,0(a4)
    80002580:	2785                	addiw	a5,a5,1
    80002582:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80002584:	853a                	mv	a0,a4
    80002586:	a3dff0ef          	jal	80001fc2 <wakeup>
    release(&tickslock);
    8000258a:	00016517          	auipc	a0,0x16
    8000258e:	f2e50513          	addi	a0,a0,-210 # 800184b8 <tickslock>
    80002592:	f1efe0ef          	jal	80000cb0 <release>
    80002596:	bf6d                	j	80002550 <clockintr+0xe>

0000000080002598 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002598:	1101                	addi	sp,sp,-32
    8000259a:	ec06                	sd	ra,24(sp)
    8000259c:	e822                	sd	s0,16(sp)
    8000259e:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    800025a0:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if (scause == 0x8000000000000009L) {
    800025a4:	57fd                	li	a5,-1
    800025a6:	17fe                	slli	a5,a5,0x3f
    800025a8:	07a5                	addi	a5,a5,9
    800025aa:	00f70c63          	beq	a4,a5,800025c2 <devintr+0x2a>
    // now allowed to interrupt again.
    if (irq)
      plic_complete(irq);

    return 1;
  } else if (scause == 0x8000000000000005L) {
    800025ae:	57fd                	li	a5,-1
    800025b0:	17fe                	slli	a5,a5,0x3f
    800025b2:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    800025b4:	4501                	li	a0,0
  } else if (scause == 0x8000000000000005L) {
    800025b6:	04f70863          	beq	a4,a5,80002606 <devintr+0x6e>
  }
}
    800025ba:	60e2                	ld	ra,24(sp)
    800025bc:	6442                	ld	s0,16(sp)
    800025be:	6105                	addi	sp,sp,32
    800025c0:	8082                	ret
    800025c2:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    800025c4:	15a030ef          	jal	8000571e <plic_claim>
    800025c8:	872a                	mv	a4,a0
    800025ca:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ) {
    800025cc:	47a9                	li	a5,10
    800025ce:	00f50963          	beq	a0,a5,800025e0 <devintr+0x48>
    } else if (irq == VIRTIO0_IRQ) {
    800025d2:	4785                	li	a5,1
    800025d4:	00f50963          	beq	a0,a5,800025e6 <devintr+0x4e>
    return 1;
    800025d8:	4505                	li	a0,1
    } else if (irq) {
    800025da:	eb09                	bnez	a4,800025ec <devintr+0x54>
    800025dc:	64a2                	ld	s1,8(sp)
    800025de:	bff1                	j	800025ba <devintr+0x22>
      uartintr();
    800025e0:	c0efe0ef          	jal	800009ee <uartintr>
    if (irq)
    800025e4:	a819                	j	800025fa <devintr+0x62>
      virtio_disk_intr();
    800025e6:	5f4030ef          	jal	80005bda <virtio_disk_intr>
    if (irq)
    800025ea:	a801                	j	800025fa <devintr+0x62>
      printk("unexpected interrupt irq=%d\n", irq);
    800025ec:	85ba                	mv	a1,a4
    800025ee:	00005517          	auipc	a0,0x5
    800025f2:	c8250513          	addi	a0,a0,-894 # 80007270 <etext+0x270>
    800025f6:	f15fd0ef          	jal	8000050a <printk>
      plic_complete(irq);
    800025fa:	8526                	mv	a0,s1
    800025fc:	144030ef          	jal	80005740 <plic_complete>
    return 1;
    80002600:	4505                	li	a0,1
    80002602:	64a2                	ld	s1,8(sp)
    80002604:	bf5d                	j	800025ba <devintr+0x22>
    clockintr();
    80002606:	f3dff0ef          	jal	80002542 <clockintr>
    return 2;
    8000260a:	4509                	li	a0,2
    8000260c:	b77d                	j	800025ba <devintr+0x22>

000000008000260e <usertrap>:
{
    8000260e:	1101                	addi	sp,sp,-32
    80002610:	ec06                	sd	ra,24(sp)
    80002612:	e822                	sd	s0,16(sp)
    80002614:	e426                	sd	s1,8(sp)
    80002616:	e04a                	sd	s2,0(sp)
    80002618:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    8000261a:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    8000261e:	1007f793          	andi	a5,a5,256
    80002622:	eba5                	bnez	a5,80002692 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002624:	00003797          	auipc	a5,0x3
    80002628:	04c78793          	addi	a5,a5,76 # 80005670 <kernelvec>
    8000262c:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80002630:	b1cff0ef          	jal	8000194c <myproc>
    80002634:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002636:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002638:	14102773          	csrr	a4,sepc
    8000263c:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    8000263e:	14202773          	csrr	a4,scause
  if (r_scause() == 8) {
    80002642:	47a1                	li	a5,8
    80002644:	04f70d63          	beq	a4,a5,8000269e <usertrap+0x90>
  } else if ((which_dev = devintr()) != 0) {
    80002648:	f51ff0ef          	jal	80002598 <devintr>
    8000264c:	892a                	mv	s2,a0
    8000264e:	e54d                	bnez	a0,800026f8 <usertrap+0xea>
    80002650:	14202773          	csrr	a4,scause
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002654:	47bd                	li	a5,15
    80002656:	08f70463          	beq	a4,a5,800026de <usertrap+0xd0>
    8000265a:	14202773          	csrr	a4,scause
    8000265e:	47b5                	li	a5,13
    80002660:	06f70f63          	beq	a4,a5,800026de <usertrap+0xd0>
    80002664:	142025f3          	csrr	a1,scause
    printk("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002668:	5890                	lw	a2,48(s1)
    8000266a:	00005517          	auipc	a0,0x5
    8000266e:	c4650513          	addi	a0,a0,-954 # 800072b0 <etext+0x2b0>
    80002672:	e99fd0ef          	jal	8000050a <printk>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002676:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    8000267a:	14302673          	csrr	a2,stval
    printk("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    8000267e:	00005517          	auipc	a0,0x5
    80002682:	c6250513          	addi	a0,a0,-926 # 800072e0 <etext+0x2e0>
    80002686:	e85fd0ef          	jal	8000050a <printk>
    setkilled(p);
    8000268a:	8526                	mv	a0,s1
    8000268c:	b05ff0ef          	jal	80002190 <setkilled>
    80002690:	a015                	j	800026b4 <usertrap+0xa6>
    panic("usertrap: not from user mode");
    80002692:	00005517          	auipc	a0,0x5
    80002696:	bfe50513          	addi	a0,a0,-1026 # 80007290 <etext+0x290>
    8000269a:	99afe0ef          	jal	80000834 <panic>
    if (killed(p))
    8000269e:	b17ff0ef          	jal	800021b4 <killed>
    800026a2:	e915                	bnez	a0,800026d6 <usertrap+0xc8>
    p->trapframe->epc += 4;
    800026a4:	6cb8                	ld	a4,88(s1)
    800026a6:	6f1c                	ld	a5,24(a4)
    800026a8:	0791                	addi	a5,a5,4
    800026aa:	ef1c                	sd	a5,24(a4)
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    800026ac:	10016073          	csrsi	sstatus,2
    syscall();
    800026b0:	244000ef          	jal	800028f4 <syscall>
  if (killed(p))
    800026b4:	8526                	mv	a0,s1
    800026b6:	affff0ef          	jal	800021b4 <killed>
    800026ba:	e521                	bnez	a0,80002702 <usertrap+0xf4>
  prepare_return();
    800026bc:	e13ff0ef          	jal	800024ce <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800026c0:	68a8                	ld	a0,80(s1)
    800026c2:	8131                	srli	a0,a0,0xc
    800026c4:	57fd                	li	a5,-1
    800026c6:	17fe                	slli	a5,a5,0x3f
    800026c8:	8d5d                	or	a0,a0,a5
}
    800026ca:	60e2                	ld	ra,24(sp)
    800026cc:	6442                	ld	s0,16(sp)
    800026ce:	64a2                	ld	s1,8(sp)
    800026d0:	6902                	ld	s2,0(sp)
    800026d2:	6105                	addi	sp,sp,32
    800026d4:	8082                	ret
      kexit(-1);
    800026d6:	557d                	li	a0,-1
    800026d8:	9a7ff0ef          	jal	8000207e <kexit>
    800026dc:	b7e1                	j	800026a4 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r"(x));
    800026de:	14302673          	csrr	a2,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    800026e2:	142026f3          	csrr	a3,scause
             vmfault(p->pagetable, p->sz, r_stval(),
    800026e6:	16cd                	addi	a3,a3,-13 # ff3 <_entry-0x7ffff00d>
    800026e8:	0016b693          	seqz	a3,a3
    800026ec:	64ac                	ld	a1,72(s1)
    800026ee:	68a8                	ld	a0,80(s1)
    800026f0:	e1bfe0ef          	jal	8000150a <vmfault>
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    800026f4:	f161                	bnez	a0,800026b4 <usertrap+0xa6>
    800026f6:	b7bd                	j	80002664 <usertrap+0x56>
  if (killed(p))
    800026f8:	8526                	mv	a0,s1
    800026fa:	abbff0ef          	jal	800021b4 <killed>
    800026fe:	c511                	beqz	a0,8000270a <usertrap+0xfc>
    80002700:	a011                	j	80002704 <usertrap+0xf6>
    80002702:	4901                	li	s2,0
    kexit(-1);
    80002704:	557d                	li	a0,-1
    80002706:	979ff0ef          	jal	8000207e <kexit>
  if (which_dev == 2)
    8000270a:	4789                	li	a5,2
    8000270c:	faf918e3          	bne	s2,a5,800026bc <usertrap+0xae>
    yield();
    80002710:	81bff0ef          	jal	80001f2a <yield>
    80002714:	b765                	j	800026bc <usertrap+0xae>

0000000080002716 <kerneltrap>:
{
    80002716:	7179                	addi	sp,sp,-48
    80002718:	f406                	sd	ra,40(sp)
    8000271a:	f022                	sd	s0,32(sp)
    8000271c:	ec26                	sd	s1,24(sp)
    8000271e:	e84a                	sd	s2,16(sp)
    80002720:	e44e                	sd	s3,8(sp)
    80002722:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002724:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002728:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    8000272c:	142027f3          	csrr	a5,scause
    80002730:	89be                	mv	s3,a5
  if ((sstatus & SSTATUS_SPP) == 0)
    80002732:	1004f793          	andi	a5,s1,256
    80002736:	c795                	beqz	a5,80002762 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002738:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000273c:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    8000273e:	eb85                	bnez	a5,8000276e <kerneltrap+0x58>
  if ((which_dev = devintr()) == 0) {
    80002740:	e59ff0ef          	jal	80002598 <devintr>
    80002744:	c91d                	beqz	a0,8000277a <kerneltrap+0x64>
  if (which_dev == 2 && myproc() != 0)
    80002746:	4789                	li	a5,2
    80002748:	04f50a63          	beq	a0,a5,8000279c <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r"(x));
    8000274c:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002750:	10049073          	csrw	sstatus,s1
}
    80002754:	70a2                	ld	ra,40(sp)
    80002756:	7402                	ld	s0,32(sp)
    80002758:	64e2                	ld	s1,24(sp)
    8000275a:	6942                	ld	s2,16(sp)
    8000275c:	69a2                	ld	s3,8(sp)
    8000275e:	6145                	addi	sp,sp,48
    80002760:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002762:	00005517          	auipc	a0,0x5
    80002766:	ba650513          	addi	a0,a0,-1114 # 80007308 <etext+0x308>
    8000276a:	8cafe0ef          	jal	80000834 <panic>
    panic("kerneltrap: interrupts enabled");
    8000276e:	00005517          	auipc	a0,0x5
    80002772:	bc250513          	addi	a0,a0,-1086 # 80007330 <etext+0x330>
    80002776:	8befe0ef          	jal	80000834 <panic>
  asm volatile("csrr %0, sepc" : "=r"(x));
    8000277a:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    8000277e:	143026f3          	csrr	a3,stval
    printk("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(),
    80002782:	85ce                	mv	a1,s3
    80002784:	00005517          	auipc	a0,0x5
    80002788:	bcc50513          	addi	a0,a0,-1076 # 80007350 <etext+0x350>
    8000278c:	d7ffd0ef          	jal	8000050a <printk>
    panic("kerneltrap");
    80002790:	00005517          	auipc	a0,0x5
    80002794:	be850513          	addi	a0,a0,-1048 # 80007378 <etext+0x378>
    80002798:	89cfe0ef          	jal	80000834 <panic>
  if (which_dev == 2 && myproc() != 0)
    8000279c:	9b0ff0ef          	jal	8000194c <myproc>
    800027a0:	d555                	beqz	a0,8000274c <kerneltrap+0x36>
    yield();
    800027a2:	f88ff0ef          	jal	80001f2a <yield>
    800027a6:	b75d                	j	8000274c <kerneltrap+0x36>

00000000800027a8 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    800027a8:	1101                	addi	sp,sp,-32
    800027aa:	ec06                	sd	ra,24(sp)
    800027ac:	e822                	sd	s0,16(sp)
    800027ae:	e426                	sd	s1,8(sp)
    800027b0:	1000                	addi	s0,sp,32
    800027b2:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    800027b4:	998ff0ef          	jal	8000194c <myproc>
  switch (n) {
    800027b8:	4795                	li	a5,5
    800027ba:	0497e163          	bltu	a5,s1,800027fc <argraw+0x54>
    800027be:	048a                	slli	s1,s1,0x2
    800027c0:	00005717          	auipc	a4,0x5
    800027c4:	0d070713          	addi	a4,a4,208 # 80007890 <states.0+0x30>
    800027c8:	94ba                	add	s1,s1,a4
    800027ca:	409c                	lw	a5,0(s1)
    800027cc:	97ba                	add	a5,a5,a4
    800027ce:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    800027d0:	6d3c                	ld	a5,88(a0)
    800027d2:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    800027d4:	60e2                	ld	ra,24(sp)
    800027d6:	6442                	ld	s0,16(sp)
    800027d8:	64a2                	ld	s1,8(sp)
    800027da:	6105                	addi	sp,sp,32
    800027dc:	8082                	ret
    return p->trapframe->a1;
    800027de:	6d3c                	ld	a5,88(a0)
    800027e0:	7fa8                	ld	a0,120(a5)
    800027e2:	bfcd                	j	800027d4 <argraw+0x2c>
    return p->trapframe->a2;
    800027e4:	6d3c                	ld	a5,88(a0)
    800027e6:	63c8                	ld	a0,128(a5)
    800027e8:	b7f5                	j	800027d4 <argraw+0x2c>
    return p->trapframe->a3;
    800027ea:	6d3c                	ld	a5,88(a0)
    800027ec:	67c8                	ld	a0,136(a5)
    800027ee:	b7dd                	j	800027d4 <argraw+0x2c>
    return p->trapframe->a4;
    800027f0:	6d3c                	ld	a5,88(a0)
    800027f2:	6bc8                	ld	a0,144(a5)
    800027f4:	b7c5                	j	800027d4 <argraw+0x2c>
    return p->trapframe->a5;
    800027f6:	6d3c                	ld	a5,88(a0)
    800027f8:	6fc8                	ld	a0,152(a5)
    800027fa:	bfe9                	j	800027d4 <argraw+0x2c>
  panic("argraw");
    800027fc:	00005517          	auipc	a0,0x5
    80002800:	b8c50513          	addi	a0,a0,-1140 # 80007388 <etext+0x388>
    80002804:	830fe0ef          	jal	80000834 <panic>

0000000080002808 <fetchaddr>:
{
    80002808:	1101                	addi	sp,sp,-32
    8000280a:	ec06                	sd	ra,24(sp)
    8000280c:	e822                	sd	s0,16(sp)
    8000280e:	e426                	sd	s1,8(sp)
    80002810:	e04a                	sd	s2,0(sp)
    80002812:	1000                	addi	s0,sp,32
    80002814:	84aa                	mv	s1,a0
    80002816:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002818:	934ff0ef          	jal	8000194c <myproc>
  if (addr >= p->sz ||
    8000281c:	652c                	ld	a1,72(a0)
    8000281e:	02b4f663          	bgeu	s1,a1,8000284a <fetchaddr+0x42>
      addr + sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002822:	00848793          	addi	a5,s1,8
  if (addr >= p->sz ||
    80002826:	02f5e463          	bltu	a1,a5,8000284e <fetchaddr+0x46>
  if (copyin(p->pagetable, p->sz, (char *)ip, addr, sizeof(*ip)) != 0)
    8000282a:	4721                	li	a4,8
    8000282c:	86a6                	mv	a3,s1
    8000282e:	864a                	mv	a2,s2
    80002830:	6928                	ld	a0,80(a0)
    80002832:	e1bfe0ef          	jal	8000164c <copyin>
    80002836:	00a03533          	snez	a0,a0
    8000283a:	40a0053b          	negw	a0,a0
}
    8000283e:	60e2                	ld	ra,24(sp)
    80002840:	6442                	ld	s0,16(sp)
    80002842:	64a2                	ld	s1,8(sp)
    80002844:	6902                	ld	s2,0(sp)
    80002846:	6105                	addi	sp,sp,32
    80002848:	8082                	ret
    return -1;
    8000284a:	557d                	li	a0,-1
    8000284c:	bfcd                	j	8000283e <fetchaddr+0x36>
    8000284e:	557d                	li	a0,-1
    80002850:	b7fd                	j	8000283e <fetchaddr+0x36>

0000000080002852 <fetchstr>:
{
    80002852:	7179                	addi	sp,sp,-48
    80002854:	f406                	sd	ra,40(sp)
    80002856:	f022                	sd	s0,32(sp)
    80002858:	ec26                	sd	s1,24(sp)
    8000285a:	e84a                	sd	s2,16(sp)
    8000285c:	e44e                	sd	s3,8(sp)
    8000285e:	1800                	addi	s0,sp,48
    80002860:	89aa                	mv	s3,a0
    80002862:	84ae                	mv	s1,a1
    80002864:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80002866:	8e6ff0ef          	jal	8000194c <myproc>
  if (copyinstr(p->pagetable, p->sz, buf, addr, max) < 0)
    8000286a:	874a                	mv	a4,s2
    8000286c:	86ce                	mv	a3,s3
    8000286e:	8626                	mv	a2,s1
    80002870:	652c                	ld	a1,72(a0)
    80002872:	6928                	ld	a0,80(a0)
    80002874:	e75fe0ef          	jal	800016e8 <copyinstr>
    80002878:	00054c63          	bltz	a0,80002890 <fetchstr+0x3e>
  return strlen(buf);
    8000287c:	8526                	mv	a0,s1
    8000287e:	df4fe0ef          	jal	80000e72 <strlen>
}
    80002882:	70a2                	ld	ra,40(sp)
    80002884:	7402                	ld	s0,32(sp)
    80002886:	64e2                	ld	s1,24(sp)
    80002888:	6942                	ld	s2,16(sp)
    8000288a:	69a2                	ld	s3,8(sp)
    8000288c:	6145                	addi	sp,sp,48
    8000288e:	8082                	ret
    return -1;
    80002890:	557d                	li	a0,-1
    80002892:	bfc5                	j	80002882 <fetchstr+0x30>

0000000080002894 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002894:	1101                	addi	sp,sp,-32
    80002896:	ec06                	sd	ra,24(sp)
    80002898:	e822                	sd	s0,16(sp)
    8000289a:	e426                	sd	s1,8(sp)
    8000289c:	1000                	addi	s0,sp,32
    8000289e:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800028a0:	f09ff0ef          	jal	800027a8 <argraw>
    800028a4:	c088                	sw	a0,0(s1)
}
    800028a6:	60e2                	ld	ra,24(sp)
    800028a8:	6442                	ld	s0,16(sp)
    800028aa:	64a2                	ld	s1,8(sp)
    800028ac:	6105                	addi	sp,sp,32
    800028ae:	8082                	ret

00000000800028b0 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    800028b0:	1101                	addi	sp,sp,-32
    800028b2:	ec06                	sd	ra,24(sp)
    800028b4:	e822                	sd	s0,16(sp)
    800028b6:	e426                	sd	s1,8(sp)
    800028b8:	1000                	addi	s0,sp,32
    800028ba:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800028bc:	eedff0ef          	jal	800027a8 <argraw>
    800028c0:	e088                	sd	a0,0(s1)
}
    800028c2:	60e2                	ld	ra,24(sp)
    800028c4:	6442                	ld	s0,16(sp)
    800028c6:	64a2                	ld	s1,8(sp)
    800028c8:	6105                	addi	sp,sp,32
    800028ca:	8082                	ret

00000000800028cc <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (not including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    800028cc:	1101                	addi	sp,sp,-32
    800028ce:	ec06                	sd	ra,24(sp)
    800028d0:	e822                	sd	s0,16(sp)
    800028d2:	e426                	sd	s1,8(sp)
    800028d4:	e04a                	sd	s2,0(sp)
    800028d6:	1000                	addi	s0,sp,32
    800028d8:	892e                	mv	s2,a1
    800028da:	84b2                	mv	s1,a2
  *ip = argraw(n);
    800028dc:	ecdff0ef          	jal	800027a8 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    800028e0:	8626                	mv	a2,s1
    800028e2:	85ca                	mv	a1,s2
    800028e4:	f6fff0ef          	jal	80002852 <fetchstr>
}
    800028e8:	60e2                	ld	ra,24(sp)
    800028ea:	6442                	ld	s0,16(sp)
    800028ec:	64a2                	ld	s1,8(sp)
    800028ee:	6902                	ld	s2,0(sp)
    800028f0:	6105                	addi	sp,sp,32
    800028f2:	8082                	ret

00000000800028f4 <syscall>:
  // clang-format on
};

void
syscall(void)
{
    800028f4:	1101                	addi	sp,sp,-32
    800028f6:	ec06                	sd	ra,24(sp)
    800028f8:	e822                	sd	s0,16(sp)
    800028fa:	e426                	sd	s1,8(sp)
    800028fc:	e04a                	sd	s2,0(sp)
    800028fe:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002900:	84cff0ef          	jal	8000194c <myproc>
    80002904:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002906:	05853903          	ld	s2,88(a0)
    8000290a:	0a893783          	ld	a5,168(s2)
    8000290e:	0007869b          	sext.w	a3,a5
  if (num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002912:	37fd                	addiw	a5,a5,-1
    80002914:	475d                	li	a4,23
    80002916:	00f76f63          	bltu	a4,a5,80002934 <syscall+0x40>
    8000291a:	00369713          	slli	a4,a3,0x3
    8000291e:	00005797          	auipc	a5,0x5
    80002922:	f8a78793          	addi	a5,a5,-118 # 800078a8 <syscalls>
    80002926:	97ba                	add	a5,a5,a4
    80002928:	639c                	ld	a5,0(a5)
    8000292a:	c789                	beqz	a5,80002934 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    8000292c:	9782                	jalr	a5
    8000292e:	06a93823          	sd	a0,112(s2)
    80002932:	a829                	j	8000294c <syscall+0x58>
  } else {
    printk("%d %s: unknown sys call %d\n", p->pid, p->name, num);
    80002934:	15848613          	addi	a2,s1,344
    80002938:	588c                	lw	a1,48(s1)
    8000293a:	00005517          	auipc	a0,0x5
    8000293e:	a5650513          	addi	a0,a0,-1450 # 80007390 <etext+0x390>
    80002942:	bc9fd0ef          	jal	8000050a <printk>
    p->trapframe->a0 = -1;
    80002946:	6cbc                	ld	a5,88(s1)
    80002948:	577d                	li	a4,-1
    8000294a:	fbb8                	sd	a4,112(a5)
  }
}
    8000294c:	60e2                	ld	ra,24(sp)
    8000294e:	6442                	ld	s0,16(sp)
    80002950:	64a2                	ld	s1,8(sp)
    80002952:	6902                	ld	s2,0(sp)
    80002954:	6105                	addi	sp,sp,32
    80002956:	8082                	ret

0000000080002958 <sys_exit>:
void qlock_basic_test(void);
void qlock_concurrent_test(void);

uint64
sys_exit(void)
{
    80002958:	1101                	addi	sp,sp,-32
    8000295a:	ec06                	sd	ra,24(sp)
    8000295c:	e822                	sd	s0,16(sp)
    8000295e:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002960:	fec40593          	addi	a1,s0,-20
    80002964:	4501                	li	a0,0
    80002966:	f2fff0ef          	jal	80002894 <argint>
  kexit(n);
    8000296a:	fec42503          	lw	a0,-20(s0)
    8000296e:	f10ff0ef          	jal	8000207e <kexit>
  return 0; // not reached
}
    80002972:	4501                	li	a0,0
    80002974:	60e2                	ld	ra,24(sp)
    80002976:	6442                	ld	s0,16(sp)
    80002978:	6105                	addi	sp,sp,32
    8000297a:	8082                	ret

000000008000297c <sys_getpid>:

uint64
sys_getpid(void)
{
    8000297c:	1141                	addi	sp,sp,-16
    8000297e:	e406                	sd	ra,8(sp)
    80002980:	e022                	sd	s0,0(sp)
    80002982:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002984:	fc9fe0ef          	jal	8000194c <myproc>
}
    80002988:	5908                	lw	a0,48(a0)
    8000298a:	60a2                	ld	ra,8(sp)
    8000298c:	6402                	ld	s0,0(sp)
    8000298e:	0141                	addi	sp,sp,16
    80002990:	8082                	ret

0000000080002992 <sys_fork>:

uint64
sys_fork(void)
{
    80002992:	1141                	addi	sp,sp,-16
    80002994:	e406                	sd	ra,8(sp)
    80002996:	e022                	sd	s0,0(sp)
    80002998:	0800                	addi	s0,sp,16
  return kfork();
    8000299a:	b12ff0ef          	jal	80001cac <kfork>
}
    8000299e:	60a2                	ld	ra,8(sp)
    800029a0:	6402                	ld	s0,0(sp)
    800029a2:	0141                	addi	sp,sp,16
    800029a4:	8082                	ret

00000000800029a6 <sys_wait>:

uint64
sys_wait(void)
{
    800029a6:	1101                	addi	sp,sp,-32
    800029a8:	ec06                	sd	ra,24(sp)
    800029aa:	e822                	sd	s0,16(sp)
    800029ac:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    800029ae:	fe840593          	addi	a1,s0,-24
    800029b2:	4501                	li	a0,0
    800029b4:	efdff0ef          	jal	800028b0 <argaddr>
  return kwait(p);
    800029b8:	fe843503          	ld	a0,-24(s0)
    800029bc:	823ff0ef          	jal	800021de <kwait>
}
    800029c0:	60e2                	ld	ra,24(sp)
    800029c2:	6442                	ld	s0,16(sp)
    800029c4:	6105                	addi	sp,sp,32
    800029c6:	8082                	ret

00000000800029c8 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    800029c8:	7179                	addi	sp,sp,-48
    800029ca:	f406                	sd	ra,40(sp)
    800029cc:	f022                	sd	s0,32(sp)
    800029ce:	ec26                	sd	s1,24(sp)
    800029d0:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    800029d2:	fd840593          	addi	a1,s0,-40
    800029d6:	4501                	li	a0,0
    800029d8:	ebdff0ef          	jal	80002894 <argint>
  argint(1, &t);
    800029dc:	fdc40593          	addi	a1,s0,-36
    800029e0:	4505                	li	a0,1
    800029e2:	eb3ff0ef          	jal	80002894 <argint>
  addr = myproc()->sz;
    800029e6:	f67fe0ef          	jal	8000194c <myproc>
    800029ea:	6524                	ld	s1,72(a0)

  if (t == SBRK_EAGER || n < 0) {
    800029ec:	fdc42703          	lw	a4,-36(s0)
    800029f0:	4785                	li	a5,1
    800029f2:	02f70763          	beq	a4,a5,80002a20 <sys_sbrk+0x58>
    800029f6:	fd842783          	lw	a5,-40(s0)
    800029fa:	0207c363          	bltz	a5,80002a20 <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
    800029fe:	97a6                	add	a5,a5,s1
      return -1;
    if (addr + n > TRAPFRAME)
    80002a00:	02000737          	lui	a4,0x2000
    80002a04:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    80002a06:	0736                	slli	a4,a4,0xd
    80002a08:	02f76a63          	bltu	a4,a5,80002a3c <sys_sbrk+0x74>
    80002a0c:	0297e863          	bltu	a5,s1,80002a3c <sys_sbrk+0x74>
      return -1;
    myproc()->sz += n;
    80002a10:	f3dfe0ef          	jal	8000194c <myproc>
    80002a14:	fd842703          	lw	a4,-40(s0)
    80002a18:	653c                	ld	a5,72(a0)
    80002a1a:	97ba                	add	a5,a5,a4
    80002a1c:	e53c                	sd	a5,72(a0)
    80002a1e:	a039                	j	80002a2c <sys_sbrk+0x64>
    if (growproc(n) < 0) {
    80002a20:	fd842503          	lw	a0,-40(s0)
    80002a24:	a26ff0ef          	jal	80001c4a <growproc>
    80002a28:	00054863          	bltz	a0,80002a38 <sys_sbrk+0x70>
  }
  return addr;
}
    80002a2c:	8526                	mv	a0,s1
    80002a2e:	70a2                	ld	ra,40(sp)
    80002a30:	7402                	ld	s0,32(sp)
    80002a32:	64e2                	ld	s1,24(sp)
    80002a34:	6145                	addi	sp,sp,48
    80002a36:	8082                	ret
      return -1;
    80002a38:	54fd                	li	s1,-1
    80002a3a:	bfcd                	j	80002a2c <sys_sbrk+0x64>
      return -1;
    80002a3c:	54fd                	li	s1,-1
    80002a3e:	b7fd                	j	80002a2c <sys_sbrk+0x64>

0000000080002a40 <sys_pause>:

uint64
sys_pause(void)
{
    80002a40:	7139                	addi	sp,sp,-64
    80002a42:	fc06                	sd	ra,56(sp)
    80002a44:	f822                	sd	s0,48(sp)
    80002a46:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002a48:	fcc40593          	addi	a1,s0,-52
    80002a4c:	4501                	li	a0,0
    80002a4e:	e47ff0ef          	jal	80002894 <argint>
  if (n < 0)
    80002a52:	fcc42783          	lw	a5,-52(s0)
    80002a56:	0807c063          	bltz	a5,80002ad6 <sys_pause+0x96>
    n = 0;
  acquire(&tickslock);
    80002a5a:	00016517          	auipc	a0,0x16
    80002a5e:	a5e50513          	addi	a0,a0,-1442 # 800184b8 <tickslock>
    80002a62:	9c6fe0ef          	jal	80000c28 <acquire>
  ticks0 = ticks;
  while (ticks - ticks0 < n) {
    80002a66:	fcc42783          	lw	a5,-52(s0)
    80002a6a:	cbb9                	beqz	a5,80002ac0 <sys_pause+0x80>
    80002a6c:	f426                	sd	s1,40(sp)
    80002a6e:	f04a                	sd	s2,32(sp)
    80002a70:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002a72:	00008997          	auipc	s3,0x8
    80002a76:	b069a983          	lw	s3,-1274(s3) # 8000a578 <ticks>
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    80002a7a:	00008917          	auipc	s2,0x8
    80002a7e:	afe90913          	addi	s2,s2,-1282 # 8000a578 <ticks>
    release(&tickslock);
    80002a82:	00016497          	auipc	s1,0x16
    80002a86:	a3648493          	addi	s1,s1,-1482 # 800184b8 <tickslock>
    if (killed(myproc())) {
    80002a8a:	ec3fe0ef          	jal	8000194c <myproc>
    80002a8e:	f26ff0ef          	jal	800021b4 <killed>
    80002a92:	e529                	bnez	a0,80002adc <sys_pause+0x9c>
    sleep_prepare(&ticks);
    80002a94:	854a                	mv	a0,s2
    80002a96:	cc0ff0ef          	jal	80001f56 <sleep_prepare>
    release(&tickslock);
    80002a9a:	8526                	mv	a0,s1
    80002a9c:	a14fe0ef          	jal	80000cb0 <release>
    sleep();
    80002aa0:	cf2ff0ef          	jal	80001f92 <sleep>
    acquire(&tickslock);
    80002aa4:	8526                	mv	a0,s1
    80002aa6:	982fe0ef          	jal	80000c28 <acquire>
  while (ticks - ticks0 < n) {
    80002aaa:	00092783          	lw	a5,0(s2)
    80002aae:	413787bb          	subw	a5,a5,s3
    80002ab2:	fcc42703          	lw	a4,-52(s0)
    80002ab6:	fce7eae3          	bltu	a5,a4,80002a8a <sys_pause+0x4a>
    80002aba:	74a2                	ld	s1,40(sp)
    80002abc:	7902                	ld	s2,32(sp)
    80002abe:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002ac0:	00016517          	auipc	a0,0x16
    80002ac4:	9f850513          	addi	a0,a0,-1544 # 800184b8 <tickslock>
    80002ac8:	9e8fe0ef          	jal	80000cb0 <release>
  return 0;
    80002acc:	4501                	li	a0,0
}
    80002ace:	70e2                	ld	ra,56(sp)
    80002ad0:	7442                	ld	s0,48(sp)
    80002ad2:	6121                	addi	sp,sp,64
    80002ad4:	8082                	ret
    n = 0;
    80002ad6:	fc042623          	sw	zero,-52(s0)
    80002ada:	b741                	j	80002a5a <sys_pause+0x1a>
      release(&tickslock);
    80002adc:	00016517          	auipc	a0,0x16
    80002ae0:	9dc50513          	addi	a0,a0,-1572 # 800184b8 <tickslock>
    80002ae4:	9ccfe0ef          	jal	80000cb0 <release>
      return -1;
    80002ae8:	557d                	li	a0,-1
    80002aea:	74a2                	ld	s1,40(sp)
    80002aec:	7902                	ld	s2,32(sp)
    80002aee:	69e2                	ld	s3,24(sp)
    80002af0:	bff9                	j	80002ace <sys_pause+0x8e>

0000000080002af2 <sys_kill>:

uint64
sys_kill(void)
{
    80002af2:	1101                	addi	sp,sp,-32
    80002af4:	ec06                	sd	ra,24(sp)
    80002af6:	e822                	sd	s0,16(sp)
    80002af8:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002afa:	fec40593          	addi	a1,s0,-20
    80002afe:	4501                	li	a0,0
    80002b00:	d95ff0ef          	jal	80002894 <argint>
  return kkill(pid);
    80002b04:	fec42503          	lw	a0,-20(s0)
    80002b08:	e1cff0ef          	jal	80002124 <kkill>
}
    80002b0c:	60e2                	ld	ra,24(sp)
    80002b0e:	6442                	ld	s0,16(sp)
    80002b10:	6105                	addi	sp,sp,32
    80002b12:	8082                	ret

0000000080002b14 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002b14:	1101                	addi	sp,sp,-32
    80002b16:	ec06                	sd	ra,24(sp)
    80002b18:	e822                	sd	s0,16(sp)
    80002b1a:	e426                	sd	s1,8(sp)
    80002b1c:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002b1e:	00016517          	auipc	a0,0x16
    80002b22:	99a50513          	addi	a0,a0,-1638 # 800184b8 <tickslock>
    80002b26:	902fe0ef          	jal	80000c28 <acquire>
  xticks = ticks;
    80002b2a:	00008797          	auipc	a5,0x8
    80002b2e:	a4e7a783          	lw	a5,-1458(a5) # 8000a578 <ticks>
    80002b32:	84be                	mv	s1,a5
  release(&tickslock);
    80002b34:	00016517          	auipc	a0,0x16
    80002b38:	98450513          	addi	a0,a0,-1660 # 800184b8 <tickslock>
    80002b3c:	974fe0ef          	jal	80000cb0 <release>
  return xticks;
}
    80002b40:	02049513          	slli	a0,s1,0x20
    80002b44:	9101                	srli	a0,a0,0x20
    80002b46:	60e2                	ld	ra,24(sp)
    80002b48:	6442                	ld	s0,16(sp)
    80002b4a:	64a2                	ld	s1,8(sp)
    80002b4c:	6105                	addi	sp,sp,32
    80002b4e:	8082                	ret

0000000080002b50 <sys_getprocs>:
uint64
sys_getprocs(void)
{
    80002b50:	7179                	addi	sp,sp,-48
    80002b52:	f406                	sd	ra,40(sp)
    80002b54:	f022                	sd	s0,32(sp)
    80002b56:	ec26                	sd	s1,24(sp)
    80002b58:	e84a                	sd	s2,16(sp)
    80002b5a:	e44e                	sd	s3,8(sp)
    80002b5c:	1800                	addi	s0,sp,48
	int count = 0;
	struct proc *p;

	for(p=proc;p < &proc[NPROC];p++){
    80002b5e:	00010497          	auipc	s1,0x10
    80002b62:	f5a48493          	addi	s1,s1,-166 # 80012ab8 <proc>
	int count = 0;
    80002b66:	4901                	li	s2,0
	for(p=proc;p < &proc[NPROC];p++){
    80002b68:	00016997          	auipc	s3,0x16
    80002b6c:	95098993          	addi	s3,s3,-1712 # 800184b8 <tickslock>
    80002b70:	a801                	j	80002b80 <sys_getprocs+0x30>
	
	if(p->state != UNUSED)
	count++;


	release(&p->lock);
    80002b72:	8526                	mv	a0,s1
    80002b74:	93cfe0ef          	jal	80000cb0 <release>
	for(p=proc;p < &proc[NPROC];p++){
    80002b78:	16848493          	addi	s1,s1,360
    80002b7c:	01348963          	beq	s1,s3,80002b8e <sys_getprocs+0x3e>
	acquire(&p->lock);
    80002b80:	8526                	mv	a0,s1
    80002b82:	8a6fe0ef          	jal	80000c28 <acquire>
	if(p->state != UNUSED)
    80002b86:	4c9c                	lw	a5,24(s1)
    80002b88:	d7ed                	beqz	a5,80002b72 <sys_getprocs+0x22>
	count++;
    80002b8a:	2905                	addiw	s2,s2,1
    80002b8c:	b7dd                	j	80002b72 <sys_getprocs+0x22>
  }

return count;

}
    80002b8e:	854a                	mv	a0,s2
    80002b90:	70a2                	ld	ra,40(sp)
    80002b92:	7402                	ld	s0,32(sp)
    80002b94:	64e2                	ld	s1,24(sp)
    80002b96:	6942                	ld	s2,16(sp)
    80002b98:	69a2                	ld	s3,8(sp)
    80002b9a:	6145                	addi	sp,sp,48
    80002b9c:	8082                	ret

0000000080002b9e <sys_qlocktest>:
uint64
sys_qlocktest(void)
{
    80002b9e:	1141                	addi	sp,sp,-16
    80002ba0:	e406                	sd	ra,8(sp)
    80002ba2:	e022                	sd	s0,0(sp)
    80002ba4:	0800                	addi	s0,sp,16
	qlock_concurrent_test();
    80002ba6:	206030ef          	jal	80005dac <qlock_concurrent_test>
	return 0;
}
    80002baa:	4501                	li	a0,0
    80002bac:	60a2                	ld	ra,8(sp)
    80002bae:	6402                	ld	s0,0(sp)
    80002bb0:	0141                	addi	sp,sp,16
    80002bb2:	8082                	ret

0000000080002bb4 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002bb4:	7179                	addi	sp,sp,-48
    80002bb6:	f406                	sd	ra,40(sp)
    80002bb8:	f022                	sd	s0,32(sp)
    80002bba:	ec26                	sd	s1,24(sp)
    80002bbc:	e84a                	sd	s2,16(sp)
    80002bbe:	e44e                	sd	s3,8(sp)
    80002bc0:	e052                	sd	s4,0(sp)
    80002bc2:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002bc4:	00004597          	auipc	a1,0x4
    80002bc8:	7ec58593          	addi	a1,a1,2028 # 800073b0 <etext+0x3b0>
    80002bcc:	00016517          	auipc	a0,0x16
    80002bd0:	90450513          	addi	a0,a0,-1788 # 800184d0 <bcache>
    80002bd4:	fd5fd0ef          	jal	80000ba8 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002bd8:	0001e797          	auipc	a5,0x1e
    80002bdc:	8f878793          	addi	a5,a5,-1800 # 800204d0 <bcache+0x8000>
    80002be0:	0001e717          	auipc	a4,0x1e
    80002be4:	b5870713          	addi	a4,a4,-1192 # 80020738 <bcache+0x8268>
    80002be8:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002bec:	2ae7bc23          	sd	a4,696(a5)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002bf0:	00016497          	auipc	s1,0x16
    80002bf4:	8f848493          	addi	s1,s1,-1800 # 800184e8 <bcache+0x18>
    b->next = bcache.head.next;
    80002bf8:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002bfa:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002bfc:	00004a17          	auipc	s4,0x4
    80002c00:	7bca0a13          	addi	s4,s4,1980 # 800073b8 <etext+0x3b8>
    b->next = bcache.head.next;
    80002c04:	2b893783          	ld	a5,696(s2)
    80002c08:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002c0a:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002c0e:	85d2                	mv	a1,s4
    80002c10:	01048513          	addi	a0,s1,16
    80002c14:	41c010ef          	jal	80004030 <initsleeplock>
    bcache.head.next->prev = b;
    80002c18:	2b893783          	ld	a5,696(s2)
    80002c1c:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002c1e:	2a993c23          	sd	s1,696(s2)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002c22:	45848493          	addi	s1,s1,1112
    80002c26:	fd349fe3          	bne	s1,s3,80002c04 <binit+0x50>
  }
}
    80002c2a:	70a2                	ld	ra,40(sp)
    80002c2c:	7402                	ld	s0,32(sp)
    80002c2e:	64e2                	ld	s1,24(sp)
    80002c30:	6942                	ld	s2,16(sp)
    80002c32:	69a2                	ld	s3,8(sp)
    80002c34:	6a02                	ld	s4,0(sp)
    80002c36:	6145                	addi	sp,sp,48
    80002c38:	8082                	ret

0000000080002c3a <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf *
bread(uint dev, uint blockno)
{
    80002c3a:	7179                	addi	sp,sp,-48
    80002c3c:	f406                	sd	ra,40(sp)
    80002c3e:	f022                	sd	s0,32(sp)
    80002c40:	ec26                	sd	s1,24(sp)
    80002c42:	e84a                	sd	s2,16(sp)
    80002c44:	e44e                	sd	s3,8(sp)
    80002c46:	1800                	addi	s0,sp,48
    80002c48:	892a                	mv	s2,a0
    80002c4a:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002c4c:	00016517          	auipc	a0,0x16
    80002c50:	88450513          	addi	a0,a0,-1916 # 800184d0 <bcache>
    80002c54:	fd5fd0ef          	jal	80000c28 <acquire>
  for (b = bcache.head.next; b != &bcache.head; b = b->next) {
    80002c58:	0001e497          	auipc	s1,0x1e
    80002c5c:	b304b483          	ld	s1,-1232(s1) # 80020788 <bcache+0x82b8>
    80002c60:	0001e797          	auipc	a5,0x1e
    80002c64:	ad878793          	addi	a5,a5,-1320 # 80020738 <bcache+0x8268>
    80002c68:	02f48b63          	beq	s1,a5,80002c9e <bread+0x64>
    80002c6c:	873e                	mv	a4,a5
    80002c6e:	a021                	j	80002c76 <bread+0x3c>
    80002c70:	68a4                	ld	s1,80(s1)
    80002c72:	02e48663          	beq	s1,a4,80002c9e <bread+0x64>
    if (b->dev == dev && b->blockno == blockno) {
    80002c76:	449c                	lw	a5,8(s1)
    80002c78:	ff279ce3          	bne	a5,s2,80002c70 <bread+0x36>
    80002c7c:	44dc                	lw	a5,12(s1)
    80002c7e:	ff3799e3          	bne	a5,s3,80002c70 <bread+0x36>
      b->refcnt++;
    80002c82:	40bc                	lw	a5,64(s1)
    80002c84:	2785                	addiw	a5,a5,1
    80002c86:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c88:	00016517          	auipc	a0,0x16
    80002c8c:	84850513          	addi	a0,a0,-1976 # 800184d0 <bcache>
    80002c90:	820fe0ef          	jal	80000cb0 <release>
      acquiresleep(&b->lock);
    80002c94:	01048513          	addi	a0,s1,16
    80002c98:	3ce010ef          	jal	80004066 <acquiresleep>
      return b;
    80002c9c:	a889                	j	80002cee <bread+0xb4>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002c9e:	0001e497          	auipc	s1,0x1e
    80002ca2:	ae24b483          	ld	s1,-1310(s1) # 80020780 <bcache+0x82b0>
    80002ca6:	0001e797          	auipc	a5,0x1e
    80002caa:	a9278793          	addi	a5,a5,-1390 # 80020738 <bcache+0x8268>
    80002cae:	00f48863          	beq	s1,a5,80002cbe <bread+0x84>
    80002cb2:	873e                	mv	a4,a5
    if (b->refcnt == 0) {
    80002cb4:	40bc                	lw	a5,64(s1)
    80002cb6:	cb91                	beqz	a5,80002cca <bread+0x90>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002cb8:	64a4                	ld	s1,72(s1)
    80002cba:	fee49de3          	bne	s1,a4,80002cb4 <bread+0x7a>
  panic("bget: no buffers");
    80002cbe:	00004517          	auipc	a0,0x4
    80002cc2:	70250513          	addi	a0,a0,1794 # 800073c0 <etext+0x3c0>
    80002cc6:	b6ffd0ef          	jal	80000834 <panic>
      b->dev = dev;
    80002cca:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002cce:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002cd2:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002cd6:	4785                	li	a5,1
    80002cd8:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002cda:	00015517          	auipc	a0,0x15
    80002cde:	7f650513          	addi	a0,a0,2038 # 800184d0 <bcache>
    80002ce2:	fcffd0ef          	jal	80000cb0 <release>
      acquiresleep(&b->lock);
    80002ce6:	01048513          	addi	a0,s1,16
    80002cea:	37c010ef          	jal	80004066 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if (!b->valid) {
    80002cee:	409c                	lw	a5,0(s1)
    80002cf0:	cb89                	beqz	a5,80002d02 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002cf2:	8526                	mv	a0,s1
    80002cf4:	70a2                	ld	ra,40(sp)
    80002cf6:	7402                	ld	s0,32(sp)
    80002cf8:	64e2                	ld	s1,24(sp)
    80002cfa:	6942                	ld	s2,16(sp)
    80002cfc:	69a2                	ld	s3,8(sp)
    80002cfe:	6145                	addi	sp,sp,48
    80002d00:	8082                	ret
    virtio_disk_rw(b, 0);
    80002d02:	4581                	li	a1,0
    80002d04:	8526                	mv	a0,s1
    80002d06:	4a1020ef          	jal	800059a6 <virtio_disk_rw>
    b->valid = 1;
    80002d0a:	4785                	li	a5,1
    80002d0c:	c09c                	sw	a5,0(s1)
  return b;
    80002d0e:	b7d5                	j	80002cf2 <bread+0xb8>

0000000080002d10 <bwrite>:

// Write b's contents to disk.  Must be locked.
// Only the log calls bwrite.
void
bwrite(struct buf *b)
{
    80002d10:	1101                	addi	sp,sp,-32
    80002d12:	ec06                	sd	ra,24(sp)
    80002d14:	e822                	sd	s0,16(sp)
    80002d16:	e426                	sd	s1,8(sp)
    80002d18:	1000                	addi	s0,sp,32
    80002d1a:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002d1c:	0541                	addi	a0,a0,16
    80002d1e:	3d4010ef          	jal	800040f2 <holdingsleep>
    80002d22:	c911                	beqz	a0,80002d36 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002d24:	4585                	li	a1,1
    80002d26:	8526                	mv	a0,s1
    80002d28:	47f020ef          	jal	800059a6 <virtio_disk_rw>
}
    80002d2c:	60e2                	ld	ra,24(sp)
    80002d2e:	6442                	ld	s0,16(sp)
    80002d30:	64a2                	ld	s1,8(sp)
    80002d32:	6105                	addi	sp,sp,32
    80002d34:	8082                	ret
    panic("bwrite");
    80002d36:	00004517          	auipc	a0,0x4
    80002d3a:	6a250513          	addi	a0,a0,1698 # 800073d8 <etext+0x3d8>
    80002d3e:	af7fd0ef          	jal	80000834 <panic>

0000000080002d42 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002d42:	1101                	addi	sp,sp,-32
    80002d44:	ec06                	sd	ra,24(sp)
    80002d46:	e822                	sd	s0,16(sp)
    80002d48:	e426                	sd	s1,8(sp)
    80002d4a:	e04a                	sd	s2,0(sp)
    80002d4c:	1000                	addi	s0,sp,32
    80002d4e:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002d50:	01050913          	addi	s2,a0,16
    80002d54:	854a                	mv	a0,s2
    80002d56:	39c010ef          	jal	800040f2 <holdingsleep>
    80002d5a:	c125                	beqz	a0,80002dba <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002d5c:	854a                	mv	a0,s2
    80002d5e:	35c010ef          	jal	800040ba <releasesleep>

  acquire(&bcache.lock);
    80002d62:	00015517          	auipc	a0,0x15
    80002d66:	76e50513          	addi	a0,a0,1902 # 800184d0 <bcache>
    80002d6a:	ebffd0ef          	jal	80000c28 <acquire>
  b->refcnt--;
    80002d6e:	40bc                	lw	a5,64(s1)
    80002d70:	37fd                	addiw	a5,a5,-1
    80002d72:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002d74:	e79d                	bnez	a5,80002da2 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002d76:	68b8                	ld	a4,80(s1)
    80002d78:	64bc                	ld	a5,72(s1)
    80002d7a:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002d7c:	68b8                	ld	a4,80(s1)
    80002d7e:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002d80:	0001d797          	auipc	a5,0x1d
    80002d84:	75078793          	addi	a5,a5,1872 # 800204d0 <bcache+0x8000>
    80002d88:	2b87b703          	ld	a4,696(a5)
    80002d8c:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002d8e:	0001e717          	auipc	a4,0x1e
    80002d92:	9aa70713          	addi	a4,a4,-1622 # 80020738 <bcache+0x8268>
    80002d96:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002d98:	2b87b703          	ld	a4,696(a5)
    80002d9c:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002d9e:	2a97bc23          	sd	s1,696(a5)
  }

  release(&bcache.lock);
    80002da2:	00015517          	auipc	a0,0x15
    80002da6:	72e50513          	addi	a0,a0,1838 # 800184d0 <bcache>
    80002daa:	f07fd0ef          	jal	80000cb0 <release>
}
    80002dae:	60e2                	ld	ra,24(sp)
    80002db0:	6442                	ld	s0,16(sp)
    80002db2:	64a2                	ld	s1,8(sp)
    80002db4:	6902                	ld	s2,0(sp)
    80002db6:	6105                	addi	sp,sp,32
    80002db8:	8082                	ret
    panic("brelse");
    80002dba:	00004517          	auipc	a0,0x4
    80002dbe:	62650513          	addi	a0,a0,1574 # 800073e0 <etext+0x3e0>
    80002dc2:	a73fd0ef          	jal	80000834 <panic>

0000000080002dc6 <bpin>:

void
bpin(struct buf *b)
{
    80002dc6:	1101                	addi	sp,sp,-32
    80002dc8:	ec06                	sd	ra,24(sp)
    80002dca:	e822                	sd	s0,16(sp)
    80002dcc:	e426                	sd	s1,8(sp)
    80002dce:	1000                	addi	s0,sp,32
    80002dd0:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002dd2:	00015517          	auipc	a0,0x15
    80002dd6:	6fe50513          	addi	a0,a0,1790 # 800184d0 <bcache>
    80002dda:	e4ffd0ef          	jal	80000c28 <acquire>
  b->refcnt++;
    80002dde:	40bc                	lw	a5,64(s1)
    80002de0:	2785                	addiw	a5,a5,1
    80002de2:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002de4:	00015517          	auipc	a0,0x15
    80002de8:	6ec50513          	addi	a0,a0,1772 # 800184d0 <bcache>
    80002dec:	ec5fd0ef          	jal	80000cb0 <release>
}
    80002df0:	60e2                	ld	ra,24(sp)
    80002df2:	6442                	ld	s0,16(sp)
    80002df4:	64a2                	ld	s1,8(sp)
    80002df6:	6105                	addi	sp,sp,32
    80002df8:	8082                	ret

0000000080002dfa <bunpin>:

void
bunpin(struct buf *b)
{
    80002dfa:	1101                	addi	sp,sp,-32
    80002dfc:	ec06                	sd	ra,24(sp)
    80002dfe:	e822                	sd	s0,16(sp)
    80002e00:	e426                	sd	s1,8(sp)
    80002e02:	1000                	addi	s0,sp,32
    80002e04:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002e06:	00015517          	auipc	a0,0x15
    80002e0a:	6ca50513          	addi	a0,a0,1738 # 800184d0 <bcache>
    80002e0e:	e1bfd0ef          	jal	80000c28 <acquire>
  b->refcnt--;
    80002e12:	40bc                	lw	a5,64(s1)
    80002e14:	37fd                	addiw	a5,a5,-1
    80002e16:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002e18:	00015517          	auipc	a0,0x15
    80002e1c:	6b850513          	addi	a0,a0,1720 # 800184d0 <bcache>
    80002e20:	e91fd0ef          	jal	80000cb0 <release>
}
    80002e24:	60e2                	ld	ra,24(sp)
    80002e26:	6442                	ld	s0,16(sp)
    80002e28:	64a2                	ld	s1,8(sp)
    80002e2a:	6105                	addi	sp,sp,32
    80002e2c:	8082                	ret

0000000080002e2e <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002e2e:	1101                	addi	sp,sp,-32
    80002e30:	ec06                	sd	ra,24(sp)
    80002e32:	e822                	sd	s0,16(sp)
    80002e34:	e426                	sd	s1,8(sp)
    80002e36:	e04a                	sd	s2,0(sp)
    80002e38:	1000                	addi	s0,sp,32
    80002e3a:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002e3c:	00d5d79b          	srliw	a5,a1,0xd
    80002e40:	0001e597          	auipc	a1,0x1e
    80002e44:	d6c5a583          	lw	a1,-660(a1) # 80020bac <sb+0x1c>
    80002e48:	9dbd                	addw	a1,a1,a5
    80002e4a:	df1ff0ef          	jal	80002c3a <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002e4e:	0074f713          	andi	a4,s1,7
    80002e52:	4785                	li	a5,1
    80002e54:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002e58:	14ce                	slli	s1,s1,0x33
  if ((bp->data[bi / 8] & m) == 0)
    80002e5a:	90d9                	srli	s1,s1,0x36
    80002e5c:	00950733          	add	a4,a0,s1
    80002e60:	05874703          	lbu	a4,88(a4)
    80002e64:	00e7f6b3          	and	a3,a5,a4
    80002e68:	c29d                	beqz	a3,80002e8e <bfree+0x60>
    80002e6a:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi / 8] &= ~m;
    80002e6c:	94aa                	add	s1,s1,a0
    80002e6e:	fff7c793          	not	a5,a5
    80002e72:	8f7d                	and	a4,a4,a5
    80002e74:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002e78:	080010ef          	jal	80003ef8 <log_write>
  brelse(bp);
    80002e7c:	854a                	mv	a0,s2
    80002e7e:	ec5ff0ef          	jal	80002d42 <brelse>
}
    80002e82:	60e2                	ld	ra,24(sp)
    80002e84:	6442                	ld	s0,16(sp)
    80002e86:	64a2                	ld	s1,8(sp)
    80002e88:	6902                	ld	s2,0(sp)
    80002e8a:	6105                	addi	sp,sp,32
    80002e8c:	8082                	ret
    panic("freeing free block");
    80002e8e:	00004517          	auipc	a0,0x4
    80002e92:	55a50513          	addi	a0,a0,1370 # 800073e8 <etext+0x3e8>
    80002e96:	99ffd0ef          	jal	80000834 <panic>

0000000080002e9a <balloc>:
{
    80002e9a:	715d                	addi	sp,sp,-80
    80002e9c:	e486                	sd	ra,72(sp)
    80002e9e:	e0a2                	sd	s0,64(sp)
    80002ea0:	fc26                	sd	s1,56(sp)
    80002ea2:	0880                	addi	s0,sp,80
  for (b = 0; b < sb.size; b += BPB) {
    80002ea4:	0001e797          	auipc	a5,0x1e
    80002ea8:	cf07a783          	lw	a5,-784(a5) # 80020b94 <sb+0x4>
    80002eac:	0e078263          	beqz	a5,80002f90 <balloc+0xf6>
    80002eb0:	f84a                	sd	s2,48(sp)
    80002eb2:	f44e                	sd	s3,40(sp)
    80002eb4:	f052                	sd	s4,32(sp)
    80002eb6:	ec56                	sd	s5,24(sp)
    80002eb8:	e85a                	sd	s6,16(sp)
    80002eba:	e45e                	sd	s7,8(sp)
    80002ebc:	e062                	sd	s8,0(sp)
    80002ebe:	8baa                	mv	s7,a0
    80002ec0:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002ec2:	0001eb17          	auipc	s6,0x1e
    80002ec6:	cceb0b13          	addi	s6,s6,-818 # 80020b90 <sb>
      m = 1 << (bi % 8);
    80002eca:	4985                	li	s3,1
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002ecc:	6a09                	lui	s4,0x2
  for (b = 0; b < sb.size; b += BPB) {
    80002ece:	6c09                	lui	s8,0x2
    80002ed0:	a09d                	j	80002f36 <balloc+0x9c>
        bp->data[bi / 8] |= m;           // Mark block in use.
    80002ed2:	97ca                	add	a5,a5,s2
    80002ed4:	8e55                	or	a2,a2,a3
    80002ed6:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002eda:	854a                	mv	a0,s2
    80002edc:	01c010ef          	jal	80003ef8 <log_write>
        brelse(bp);
    80002ee0:	854a                	mv	a0,s2
    80002ee2:	e61ff0ef          	jal	80002d42 <brelse>
  bp = bread(dev, bno);
    80002ee6:	85a6                	mv	a1,s1
    80002ee8:	855e                	mv	a0,s7
    80002eea:	d51ff0ef          	jal	80002c3a <bread>
    80002eee:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002ef0:	40000613          	li	a2,1024
    80002ef4:	4581                	li	a1,0
    80002ef6:	05850513          	addi	a0,a0,88
    80002efa:	deffd0ef          	jal	80000ce8 <memset>
  log_write(bp);
    80002efe:	854a                	mv	a0,s2
    80002f00:	7f9000ef          	jal	80003ef8 <log_write>
  brelse(bp);
    80002f04:	854a                	mv	a0,s2
    80002f06:	e3dff0ef          	jal	80002d42 <brelse>
}
    80002f0a:	7942                	ld	s2,48(sp)
    80002f0c:	79a2                	ld	s3,40(sp)
    80002f0e:	7a02                	ld	s4,32(sp)
    80002f10:	6ae2                	ld	s5,24(sp)
    80002f12:	6b42                	ld	s6,16(sp)
    80002f14:	6ba2                	ld	s7,8(sp)
    80002f16:	6c02                	ld	s8,0(sp)
}
    80002f18:	8526                	mv	a0,s1
    80002f1a:	60a6                	ld	ra,72(sp)
    80002f1c:	6406                	ld	s0,64(sp)
    80002f1e:	74e2                	ld	s1,56(sp)
    80002f20:	6161                	addi	sp,sp,80
    80002f22:	8082                	ret
    brelse(bp);
    80002f24:	854a                	mv	a0,s2
    80002f26:	e1dff0ef          	jal	80002d42 <brelse>
  for (b = 0; b < sb.size; b += BPB) {
    80002f2a:	015c0abb          	addw	s5,s8,s5
    80002f2e:	004b2783          	lw	a5,4(s6)
    80002f32:	04faf863          	bgeu	s5,a5,80002f82 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002f36:	40dad59b          	sraiw	a1,s5,0xd
    80002f3a:	01cb2783          	lw	a5,28(s6)
    80002f3e:	9dbd                	addw	a1,a1,a5
    80002f40:	855e                	mv	a0,s7
    80002f42:	cf9ff0ef          	jal	80002c3a <bread>
    80002f46:	892a                	mv	s2,a0
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002f48:	004b2503          	lw	a0,4(s6)
    80002f4c:	84d6                	mv	s1,s5
    80002f4e:	4701                	li	a4,0
    80002f50:	fca4fae3          	bgeu	s1,a0,80002f24 <balloc+0x8a>
      m = 1 << (bi % 8);
    80002f54:	00777693          	andi	a3,a4,7
    80002f58:	00d996bb          	sllw	a3,s3,a3
      if ((bp->data[bi / 8] & m) == 0) { // Is block free?
    80002f5c:	41f7579b          	sraiw	a5,a4,0x1f
    80002f60:	01d7d79b          	srliw	a5,a5,0x1d
    80002f64:	9fb9                	addw	a5,a5,a4
    80002f66:	4037d79b          	sraiw	a5,a5,0x3
    80002f6a:	00f90633          	add	a2,s2,a5
    80002f6e:	05864603          	lbu	a2,88(a2) # 1058 <_entry-0x7fffefa8>
    80002f72:	00c6f5b3          	and	a1,a3,a2
    80002f76:	ddb1                	beqz	a1,80002ed2 <balloc+0x38>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80002f78:	2705                	addiw	a4,a4,1
    80002f7a:	2485                	addiw	s1,s1,1
    80002f7c:	fd471ae3          	bne	a4,s4,80002f50 <balloc+0xb6>
    80002f80:	b755                	j	80002f24 <balloc+0x8a>
    80002f82:	7942                	ld	s2,48(sp)
    80002f84:	79a2                	ld	s3,40(sp)
    80002f86:	7a02                	ld	s4,32(sp)
    80002f88:	6ae2                	ld	s5,24(sp)
    80002f8a:	6b42                	ld	s6,16(sp)
    80002f8c:	6ba2                	ld	s7,8(sp)
    80002f8e:	6c02                	ld	s8,0(sp)
  printk("balloc: out of blocks\n");
    80002f90:	00004517          	auipc	a0,0x4
    80002f94:	47050513          	addi	a0,a0,1136 # 80007400 <etext+0x400>
    80002f98:	d72fd0ef          	jal	8000050a <printk>
  return 0;
    80002f9c:	4481                	li	s1,0
    80002f9e:	bfad                	j	80002f18 <balloc+0x7e>

0000000080002fa0 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002fa0:	7179                	addi	sp,sp,-48
    80002fa2:	f406                	sd	ra,40(sp)
    80002fa4:	f022                	sd	s0,32(sp)
    80002fa6:	ec26                	sd	s1,24(sp)
    80002fa8:	e84a                	sd	s2,16(sp)
    80002faa:	e44e                	sd	s3,8(sp)
    80002fac:	1800                	addi	s0,sp,48
    80002fae:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if (bn < NDIRECT) {
    80002fb0:	47ad                	li	a5,11
    80002fb2:	02b7e363          	bltu	a5,a1,80002fd8 <bmap+0x38>
    if ((addr = ip->addrs[bn]) == 0) {
    80002fb6:	02059793          	slli	a5,a1,0x20
    80002fba:	01e7d593          	srli	a1,a5,0x1e
    80002fbe:	00b509b3          	add	s3,a0,a1
    80002fc2:	0509a483          	lw	s1,80(s3)
    80002fc6:	e0b5                	bnez	s1,8000302a <bmap+0x8a>
      addr = balloc(ip->dev);
    80002fc8:	4108                	lw	a0,0(a0)
    80002fca:	ed1ff0ef          	jal	80002e9a <balloc>
    80002fce:	84aa                	mv	s1,a0
      if (addr == 0)
    80002fd0:	cd29                	beqz	a0,8000302a <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80002fd2:	04a9a823          	sw	a0,80(s3)
    80002fd6:	a891                	j	8000302a <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002fd8:	ff45879b          	addiw	a5,a1,-12
    80002fdc:	873e                	mv	a4,a5
    80002fde:	89be                	mv	s3,a5

  if (bn < NINDIRECT) {
    80002fe0:	0ff00793          	li	a5,255
    80002fe4:	06e7e763          	bltu	a5,a4,80003052 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if ((addr = ip->addrs[NDIRECT]) == 0) {
    80002fe8:	08052483          	lw	s1,128(a0)
    80002fec:	e891                	bnez	s1,80003000 <bmap+0x60>
      addr = balloc(ip->dev);
    80002fee:	4108                	lw	a0,0(a0)
    80002ff0:	eabff0ef          	jal	80002e9a <balloc>
    80002ff4:	84aa                	mv	s1,a0
      if (addr == 0)
    80002ff6:	c915                	beqz	a0,8000302a <bmap+0x8a>
    80002ff8:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002ffa:	08a92023          	sw	a0,128(s2)
    80002ffe:	a011                	j	80003002 <bmap+0x62>
    80003000:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80003002:	85a6                	mv	a1,s1
    80003004:	00092503          	lw	a0,0(s2)
    80003008:	c33ff0ef          	jal	80002c3a <bread>
    8000300c:	8a2a                	mv	s4,a0
    a = (uint *)bp->data;
    8000300e:	05850793          	addi	a5,a0,88
    if ((addr = a[bn]) == 0) {
    80003012:	02099713          	slli	a4,s3,0x20
    80003016:	01e75593          	srli	a1,a4,0x1e
    8000301a:	97ae                	add	a5,a5,a1
    8000301c:	89be                	mv	s3,a5
    8000301e:	4384                	lw	s1,0(a5)
    80003020:	cc89                	beqz	s1,8000303a <bmap+0x9a>
      if (addr) {
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80003022:	8552                	mv	a0,s4
    80003024:	d1fff0ef          	jal	80002d42 <brelse>
    return addr;
    80003028:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    8000302a:	8526                	mv	a0,s1
    8000302c:	70a2                	ld	ra,40(sp)
    8000302e:	7402                	ld	s0,32(sp)
    80003030:	64e2                	ld	s1,24(sp)
    80003032:	6942                	ld	s2,16(sp)
    80003034:	69a2                	ld	s3,8(sp)
    80003036:	6145                	addi	sp,sp,48
    80003038:	8082                	ret
      addr = balloc(ip->dev);
    8000303a:	00092503          	lw	a0,0(s2)
    8000303e:	e5dff0ef          	jal	80002e9a <balloc>
    80003042:	84aa                	mv	s1,a0
      if (addr) {
    80003044:	dd79                	beqz	a0,80003022 <bmap+0x82>
        a[bn] = addr;
    80003046:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    8000304a:	8552                	mv	a0,s4
    8000304c:	6ad000ef          	jal	80003ef8 <log_write>
    80003050:	bfc9                	j	80003022 <bmap+0x82>
    80003052:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80003054:	00004517          	auipc	a0,0x4
    80003058:	3c450513          	addi	a0,a0,964 # 80007418 <etext+0x418>
    8000305c:	fd8fd0ef          	jal	80000834 <panic>

0000000080003060 <iget>:
{
    80003060:	7179                	addi	sp,sp,-48
    80003062:	f406                	sd	ra,40(sp)
    80003064:	f022                	sd	s0,32(sp)
    80003066:	ec26                	sd	s1,24(sp)
    80003068:	e84a                	sd	s2,16(sp)
    8000306a:	e44e                	sd	s3,8(sp)
    8000306c:	e052                	sd	s4,0(sp)
    8000306e:	1800                	addi	s0,sp,48
    80003070:	892a                	mv	s2,a0
    80003072:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003074:	0001e517          	auipc	a0,0x1e
    80003078:	b3c50513          	addi	a0,a0,-1220 # 80020bb0 <itable>
    8000307c:	badfd0ef          	jal	80000c28 <acquire>
  empty = 0;
    80003080:	4981                	li	s3,0
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    80003082:	0001e497          	auipc	s1,0x1e
    80003086:	b4648493          	addi	s1,s1,-1210 # 80020bc8 <itable+0x18>
    8000308a:	0001f697          	auipc	a3,0x1f
    8000308e:	5ce68693          	addi	a3,a3,1486 # 80022658 <log>
    80003092:	a809                	j	800030a4 <iget+0x44>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    80003094:	e781                	bnez	a5,8000309c <iget+0x3c>
    80003096:	00099363          	bnez	s3,8000309c <iget+0x3c>
      empty = ip;
    8000309a:	89a6                	mv	s3,s1
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    8000309c:	08848493          	addi	s1,s1,136
    800030a0:	02d48563          	beq	s1,a3,800030ca <iget+0x6a>
    if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    800030a4:	449c                	lw	a5,8(s1)
    800030a6:	fef057e3          	blez	a5,80003094 <iget+0x34>
    800030aa:	4098                	lw	a4,0(s1)
    800030ac:	ff2718e3          	bne	a4,s2,8000309c <iget+0x3c>
    800030b0:	40d8                	lw	a4,4(s1)
    800030b2:	ff4715e3          	bne	a4,s4,8000309c <iget+0x3c>
      ip->ref++;
    800030b6:	2785                	addiw	a5,a5,1
    800030b8:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800030ba:	0001e517          	auipc	a0,0x1e
    800030be:	af650513          	addi	a0,a0,-1290 # 80020bb0 <itable>
    800030c2:	beffd0ef          	jal	80000cb0 <release>
      return ip;
    800030c6:	89a6                	mv	s3,s1
    800030c8:	a015                	j	800030ec <iget+0x8c>
  if (empty == 0)
    800030ca:	02098a63          	beqz	s3,800030fe <iget+0x9e>
  ip->dev = dev;
    800030ce:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    800030d2:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    800030d6:	4785                	li	a5,1
    800030d8:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    800030dc:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    800030e0:	0001e517          	auipc	a0,0x1e
    800030e4:	ad050513          	addi	a0,a0,-1328 # 80020bb0 <itable>
    800030e8:	bc9fd0ef          	jal	80000cb0 <release>
}
    800030ec:	854e                	mv	a0,s3
    800030ee:	70a2                	ld	ra,40(sp)
    800030f0:	7402                	ld	s0,32(sp)
    800030f2:	64e2                	ld	s1,24(sp)
    800030f4:	6942                	ld	s2,16(sp)
    800030f6:	69a2                	ld	s3,8(sp)
    800030f8:	6a02                	ld	s4,0(sp)
    800030fa:	6145                	addi	sp,sp,48
    800030fc:	8082                	ret
    panic("iget: no inodes");
    800030fe:	00004517          	auipc	a0,0x4
    80003102:	33250513          	addi	a0,a0,818 # 80007430 <etext+0x430>
    80003106:	f2efd0ef          	jal	80000834 <panic>

000000008000310a <iinit>:
{
    8000310a:	7179                	addi	sp,sp,-48
    8000310c:	f406                	sd	ra,40(sp)
    8000310e:	f022                	sd	s0,32(sp)
    80003110:	ec26                	sd	s1,24(sp)
    80003112:	e84a                	sd	s2,16(sp)
    80003114:	e44e                	sd	s3,8(sp)
    80003116:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003118:	00004597          	auipc	a1,0x4
    8000311c:	32858593          	addi	a1,a1,808 # 80007440 <etext+0x440>
    80003120:	0001e517          	auipc	a0,0x1e
    80003124:	a9050513          	addi	a0,a0,-1392 # 80020bb0 <itable>
    80003128:	a81fd0ef          	jal	80000ba8 <initlock>
  for (i = 0; i < NINODE; i++) {
    8000312c:	0001e497          	auipc	s1,0x1e
    80003130:	aac48493          	addi	s1,s1,-1364 # 80020bd8 <itable+0x28>
    80003134:	0001f997          	auipc	s3,0x1f
    80003138:	53498993          	addi	s3,s3,1332 # 80022668 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    8000313c:	00004917          	auipc	s2,0x4
    80003140:	30c90913          	addi	s2,s2,780 # 80007448 <etext+0x448>
    80003144:	85ca                	mv	a1,s2
    80003146:	8526                	mv	a0,s1
    80003148:	6e9000ef          	jal	80004030 <initsleeplock>
  for (i = 0; i < NINODE; i++) {
    8000314c:	08848493          	addi	s1,s1,136
    80003150:	ff349ae3          	bne	s1,s3,80003144 <iinit+0x3a>
}
    80003154:	70a2                	ld	ra,40(sp)
    80003156:	7402                	ld	s0,32(sp)
    80003158:	64e2                	ld	s1,24(sp)
    8000315a:	6942                	ld	s2,16(sp)
    8000315c:	69a2                	ld	s3,8(sp)
    8000315e:	6145                	addi	sp,sp,48
    80003160:	8082                	ret

0000000080003162 <ialloc>:
{
    80003162:	7139                	addi	sp,sp,-64
    80003164:	fc06                	sd	ra,56(sp)
    80003166:	f822                	sd	s0,48(sp)
    80003168:	0080                	addi	s0,sp,64
  for (inum = 1; inum < sb.ninodes; inum++) {
    8000316a:	0001e717          	auipc	a4,0x1e
    8000316e:	a3272703          	lw	a4,-1486(a4) # 80020b9c <sb+0xc>
    80003172:	4785                	li	a5,1
    80003174:	06e7f063          	bgeu	a5,a4,800031d4 <ialloc+0x72>
    80003178:	f426                	sd	s1,40(sp)
    8000317a:	f04a                	sd	s2,32(sp)
    8000317c:	ec4e                	sd	s3,24(sp)
    8000317e:	e852                	sd	s4,16(sp)
    80003180:	e456                	sd	s5,8(sp)
    80003182:	e05a                	sd	s6,0(sp)
    80003184:	8aaa                	mv	s5,a0
    80003186:	8b2e                	mv	s6,a1
    80003188:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    8000318a:	0001ea17          	auipc	s4,0x1e
    8000318e:	a06a0a13          	addi	s4,s4,-1530 # 80020b90 <sb>
    80003192:	00495593          	srli	a1,s2,0x4
    80003196:	018a2783          	lw	a5,24(s4)
    8000319a:	9dbd                	addw	a1,a1,a5
    8000319c:	8556                	mv	a0,s5
    8000319e:	a9dff0ef          	jal	80002c3a <bread>
    800031a2:	84aa                	mv	s1,a0
    dip = (struct dinode *)bp->data + inum % IPB;
    800031a4:	05850993          	addi	s3,a0,88
    800031a8:	00f97793          	andi	a5,s2,15
    800031ac:	079a                	slli	a5,a5,0x6
    800031ae:	99be                	add	s3,s3,a5
    if (dip->type == 0) { // a free inode
    800031b0:	00099783          	lh	a5,0(s3)
    800031b4:	cb9d                	beqz	a5,800031ea <ialloc+0x88>
    brelse(bp);
    800031b6:	b8dff0ef          	jal	80002d42 <brelse>
  for (inum = 1; inum < sb.ninodes; inum++) {
    800031ba:	0905                	addi	s2,s2,1
    800031bc:	00ca2703          	lw	a4,12(s4)
    800031c0:	0009079b          	sext.w	a5,s2
    800031c4:	fce7e7e3          	bltu	a5,a4,80003192 <ialloc+0x30>
    800031c8:	74a2                	ld	s1,40(sp)
    800031ca:	7902                	ld	s2,32(sp)
    800031cc:	69e2                	ld	s3,24(sp)
    800031ce:	6a42                	ld	s4,16(sp)
    800031d0:	6aa2                	ld	s5,8(sp)
    800031d2:	6b02                	ld	s6,0(sp)
  printk("ialloc: no inodes\n");
    800031d4:	00004517          	auipc	a0,0x4
    800031d8:	27c50513          	addi	a0,a0,636 # 80007450 <etext+0x450>
    800031dc:	b2efd0ef          	jal	8000050a <printk>
  return 0;
    800031e0:	4501                	li	a0,0
}
    800031e2:	70e2                	ld	ra,56(sp)
    800031e4:	7442                	ld	s0,48(sp)
    800031e6:	6121                	addi	sp,sp,64
    800031e8:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800031ea:	04000613          	li	a2,64
    800031ee:	4581                	li	a1,0
    800031f0:	854e                	mv	a0,s3
    800031f2:	af7fd0ef          	jal	80000ce8 <memset>
      dip->type = type;
    800031f6:	01699023          	sh	s6,0(s3)
      log_write(bp); // mark it allocated on the disk
    800031fa:	8526                	mv	a0,s1
    800031fc:	4fd000ef          	jal	80003ef8 <log_write>
      brelse(bp);
    80003200:	8526                	mv	a0,s1
    80003202:	b41ff0ef          	jal	80002d42 <brelse>
      return iget(dev, inum);
    80003206:	0009059b          	sext.w	a1,s2
    8000320a:	8556                	mv	a0,s5
    8000320c:	e55ff0ef          	jal	80003060 <iget>
    80003210:	74a2                	ld	s1,40(sp)
    80003212:	7902                	ld	s2,32(sp)
    80003214:	69e2                	ld	s3,24(sp)
    80003216:	6a42                	ld	s4,16(sp)
    80003218:	6aa2                	ld	s5,8(sp)
    8000321a:	6b02                	ld	s6,0(sp)
    8000321c:	b7d9                	j	800031e2 <ialloc+0x80>

000000008000321e <iupdate>:
{
    8000321e:	1101                	addi	sp,sp,-32
    80003220:	ec06                	sd	ra,24(sp)
    80003222:	e822                	sd	s0,16(sp)
    80003224:	e426                	sd	s1,8(sp)
    80003226:	e04a                	sd	s2,0(sp)
    80003228:	1000                	addi	s0,sp,32
    8000322a:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000322c:	415c                	lw	a5,4(a0)
    8000322e:	0047d79b          	srliw	a5,a5,0x4
    80003232:	0001e597          	auipc	a1,0x1e
    80003236:	9765a583          	lw	a1,-1674(a1) # 80020ba8 <sb+0x18>
    8000323a:	9dbd                	addw	a1,a1,a5
    8000323c:	4108                	lw	a0,0(a0)
    8000323e:	9fdff0ef          	jal	80002c3a <bread>
    80003242:	892a                	mv	s2,a0
  dip = (struct dinode *)bp->data + ip->inum % IPB;
    80003244:	05850793          	addi	a5,a0,88
    80003248:	40d8                	lw	a4,4(s1)
    8000324a:	8b3d                	andi	a4,a4,15
    8000324c:	071a                	slli	a4,a4,0x6
    8000324e:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003250:	04449703          	lh	a4,68(s1)
    80003254:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80003258:	04649703          	lh	a4,70(s1)
    8000325c:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003260:	04849703          	lh	a4,72(s1)
    80003264:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80003268:	04a49703          	lh	a4,74(s1)
    8000326c:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003270:	44f8                	lw	a4,76(s1)
    80003272:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003274:	03400613          	li	a2,52
    80003278:	05048593          	addi	a1,s1,80
    8000327c:	00c78513          	addi	a0,a5,12
    80003280:	ac9fd0ef          	jal	80000d48 <memmove>
  log_write(bp);
    80003284:	854a                	mv	a0,s2
    80003286:	473000ef          	jal	80003ef8 <log_write>
  brelse(bp);
    8000328a:	854a                	mv	a0,s2
    8000328c:	ab7ff0ef          	jal	80002d42 <brelse>
}
    80003290:	60e2                	ld	ra,24(sp)
    80003292:	6442                	ld	s0,16(sp)
    80003294:	64a2                	ld	s1,8(sp)
    80003296:	6902                	ld	s2,0(sp)
    80003298:	6105                	addi	sp,sp,32
    8000329a:	8082                	ret

000000008000329c <idup>:
{
    8000329c:	1101                	addi	sp,sp,-32
    8000329e:	ec06                	sd	ra,24(sp)
    800032a0:	e822                	sd	s0,16(sp)
    800032a2:	e426                	sd	s1,8(sp)
    800032a4:	1000                	addi	s0,sp,32
    800032a6:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800032a8:	0001e517          	auipc	a0,0x1e
    800032ac:	90850513          	addi	a0,a0,-1784 # 80020bb0 <itable>
    800032b0:	979fd0ef          	jal	80000c28 <acquire>
  ip->ref++;
    800032b4:	449c                	lw	a5,8(s1)
    800032b6:	2785                	addiw	a5,a5,1
    800032b8:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800032ba:	0001e517          	auipc	a0,0x1e
    800032be:	8f650513          	addi	a0,a0,-1802 # 80020bb0 <itable>
    800032c2:	9effd0ef          	jal	80000cb0 <release>
}
    800032c6:	8526                	mv	a0,s1
    800032c8:	60e2                	ld	ra,24(sp)
    800032ca:	6442                	ld	s0,16(sp)
    800032cc:	64a2                	ld	s1,8(sp)
    800032ce:	6105                	addi	sp,sp,32
    800032d0:	8082                	ret

00000000800032d2 <ilock>:
{
    800032d2:	1101                	addi	sp,sp,-32
    800032d4:	ec06                	sd	ra,24(sp)
    800032d6:	e822                	sd	s0,16(sp)
    800032d8:	e426                	sd	s1,8(sp)
    800032da:	1000                	addi	s0,sp,32
  if (ip == 0 || ip->ref < 1)
    800032dc:	cd19                	beqz	a0,800032fa <ilock+0x28>
    800032de:	84aa                	mv	s1,a0
    800032e0:	451c                	lw	a5,8(a0)
    800032e2:	00f05c63          	blez	a5,800032fa <ilock+0x28>
  acquiresleep(&ip->lock);
    800032e6:	0541                	addi	a0,a0,16
    800032e8:	57f000ef          	jal	80004066 <acquiresleep>
  if (ip->valid == 0) {
    800032ec:	40bc                	lw	a5,64(s1)
    800032ee:	cf89                	beqz	a5,80003308 <ilock+0x36>
}
    800032f0:	60e2                	ld	ra,24(sp)
    800032f2:	6442                	ld	s0,16(sp)
    800032f4:	64a2                	ld	s1,8(sp)
    800032f6:	6105                	addi	sp,sp,32
    800032f8:	8082                	ret
    800032fa:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800032fc:	00004517          	auipc	a0,0x4
    80003300:	16c50513          	addi	a0,a0,364 # 80007468 <etext+0x468>
    80003304:	d30fd0ef          	jal	80000834 <panic>
    80003308:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000330a:	40dc                	lw	a5,4(s1)
    8000330c:	0047d79b          	srliw	a5,a5,0x4
    80003310:	0001e597          	auipc	a1,0x1e
    80003314:	8985a583          	lw	a1,-1896(a1) # 80020ba8 <sb+0x18>
    80003318:	9dbd                	addw	a1,a1,a5
    8000331a:	4088                	lw	a0,0(s1)
    8000331c:	91fff0ef          	jal	80002c3a <bread>
    80003320:	892a                	mv	s2,a0
    dip = (struct dinode *)bp->data + ip->inum % IPB;
    80003322:	05850593          	addi	a1,a0,88
    80003326:	40dc                	lw	a5,4(s1)
    80003328:	8bbd                	andi	a5,a5,15
    8000332a:	079a                	slli	a5,a5,0x6
    8000332c:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    8000332e:	00059783          	lh	a5,0(a1)
    80003332:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003336:	00259783          	lh	a5,2(a1)
    8000333a:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    8000333e:	00459783          	lh	a5,4(a1)
    80003342:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003346:	00659783          	lh	a5,6(a1)
    8000334a:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    8000334e:	459c                	lw	a5,8(a1)
    80003350:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003352:	03400613          	li	a2,52
    80003356:	05b1                	addi	a1,a1,12
    80003358:	05048513          	addi	a0,s1,80
    8000335c:	9edfd0ef          	jal	80000d48 <memmove>
    brelse(bp);
    80003360:	854a                	mv	a0,s2
    80003362:	9e1ff0ef          	jal	80002d42 <brelse>
    ip->valid = 1;
    80003366:	4785                	li	a5,1
    80003368:	c0bc                	sw	a5,64(s1)
    if (ip->type == 0)
    8000336a:	04449783          	lh	a5,68(s1)
    8000336e:	c399                	beqz	a5,80003374 <ilock+0xa2>
    80003370:	6902                	ld	s2,0(sp)
    80003372:	bfbd                	j	800032f0 <ilock+0x1e>
      panic("ilock: no type");
    80003374:	00004517          	auipc	a0,0x4
    80003378:	0fc50513          	addi	a0,a0,252 # 80007470 <etext+0x470>
    8000337c:	cb8fd0ef          	jal	80000834 <panic>

0000000080003380 <iunlock>:
{
    80003380:	1101                	addi	sp,sp,-32
    80003382:	ec06                	sd	ra,24(sp)
    80003384:	e822                	sd	s0,16(sp)
    80003386:	e426                	sd	s1,8(sp)
    80003388:	e04a                	sd	s2,0(sp)
    8000338a:	1000                	addi	s0,sp,32
  if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    8000338c:	c505                	beqz	a0,800033b4 <iunlock+0x34>
    8000338e:	84aa                	mv	s1,a0
    80003390:	01050913          	addi	s2,a0,16
    80003394:	854a                	mv	a0,s2
    80003396:	55d000ef          	jal	800040f2 <holdingsleep>
    8000339a:	cd09                	beqz	a0,800033b4 <iunlock+0x34>
    8000339c:	449c                	lw	a5,8(s1)
    8000339e:	00f05b63          	blez	a5,800033b4 <iunlock+0x34>
  releasesleep(&ip->lock);
    800033a2:	854a                	mv	a0,s2
    800033a4:	517000ef          	jal	800040ba <releasesleep>
}
    800033a8:	60e2                	ld	ra,24(sp)
    800033aa:	6442                	ld	s0,16(sp)
    800033ac:	64a2                	ld	s1,8(sp)
    800033ae:	6902                	ld	s2,0(sp)
    800033b0:	6105                	addi	sp,sp,32
    800033b2:	8082                	ret
    panic("iunlock");
    800033b4:	00004517          	auipc	a0,0x4
    800033b8:	0cc50513          	addi	a0,a0,204 # 80007480 <etext+0x480>
    800033bc:	c78fd0ef          	jal	80000834 <panic>

00000000800033c0 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800033c0:	7179                	addi	sp,sp,-48
    800033c2:	f406                	sd	ra,40(sp)
    800033c4:	f022                	sd	s0,32(sp)
    800033c6:	ec26                	sd	s1,24(sp)
    800033c8:	e84a                	sd	s2,16(sp)
    800033ca:	e44e                	sd	s3,8(sp)
    800033cc:	1800                	addi	s0,sp,48
    800033ce:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for (i = 0; i < NDIRECT; i++) {
    800033d0:	05050493          	addi	s1,a0,80
    800033d4:	08050913          	addi	s2,a0,128
    800033d8:	a021                	j	800033e0 <itrunc+0x20>
    800033da:	0491                	addi	s1,s1,4
    800033dc:	01248b63          	beq	s1,s2,800033f2 <itrunc+0x32>
    if (ip->addrs[i]) {
    800033e0:	408c                	lw	a1,0(s1)
    800033e2:	dde5                	beqz	a1,800033da <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    800033e4:	0009a503          	lw	a0,0(s3)
    800033e8:	a47ff0ef          	jal	80002e2e <bfree>
      ip->addrs[i] = 0;
    800033ec:	0004a023          	sw	zero,0(s1)
    800033f0:	b7ed                	j	800033da <itrunc+0x1a>
    }
  }

  if (ip->addrs[NDIRECT]) {
    800033f2:	0809a583          	lw	a1,128(s3)
    800033f6:	ed89                	bnez	a1,80003410 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800033f8:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800033fc:	854e                	mv	a0,s3
    800033fe:	e21ff0ef          	jal	8000321e <iupdate>
}
    80003402:	70a2                	ld	ra,40(sp)
    80003404:	7402                	ld	s0,32(sp)
    80003406:	64e2                	ld	s1,24(sp)
    80003408:	6942                	ld	s2,16(sp)
    8000340a:	69a2                	ld	s3,8(sp)
    8000340c:	6145                	addi	sp,sp,48
    8000340e:	8082                	ret
    80003410:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003412:	0009a503          	lw	a0,0(s3)
    80003416:	825ff0ef          	jal	80002c3a <bread>
    8000341a:	8a2a                	mv	s4,a0
    for (j = 0; j < NINDIRECT; j++) {
    8000341c:	05850493          	addi	s1,a0,88
    80003420:	45850913          	addi	s2,a0,1112
    80003424:	a021                	j	8000342c <itrunc+0x6c>
    80003426:	0491                	addi	s1,s1,4
    80003428:	01248963          	beq	s1,s2,8000343a <itrunc+0x7a>
      if (a[j])
    8000342c:	408c                	lw	a1,0(s1)
    8000342e:	dde5                	beqz	a1,80003426 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80003430:	0009a503          	lw	a0,0(s3)
    80003434:	9fbff0ef          	jal	80002e2e <bfree>
    80003438:	b7fd                	j	80003426 <itrunc+0x66>
    brelse(bp);
    8000343a:	8552                	mv	a0,s4
    8000343c:	907ff0ef          	jal	80002d42 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003440:	0809a583          	lw	a1,128(s3)
    80003444:	0009a503          	lw	a0,0(s3)
    80003448:	9e7ff0ef          	jal	80002e2e <bfree>
    ip->addrs[NDIRECT] = 0;
    8000344c:	0809a023          	sw	zero,128(s3)
    80003450:	6a02                	ld	s4,0(sp)
    80003452:	b75d                	j	800033f8 <itrunc+0x38>

0000000080003454 <iput>:
{
    80003454:	7179                	addi	sp,sp,-48
    80003456:	f406                	sd	ra,40(sp)
    80003458:	f022                	sd	s0,32(sp)
    8000345a:	ec26                	sd	s1,24(sp)
    8000345c:	1800                	addi	s0,sp,48
    8000345e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003460:	0001d517          	auipc	a0,0x1d
    80003464:	75050513          	addi	a0,a0,1872 # 80020bb0 <itable>
    80003468:	fc0fd0ef          	jal	80000c28 <acquire>
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    8000346c:	449c                	lw	a5,8(s1)
    8000346e:	4705                	li	a4,1
    80003470:	00e78f63          	beq	a5,a4,8000348e <iput+0x3a>
  ip->ref--;
    80003474:	37fd                	addiw	a5,a5,-1
    80003476:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003478:	0001d517          	auipc	a0,0x1d
    8000347c:	73850513          	addi	a0,a0,1848 # 80020bb0 <itable>
    80003480:	831fd0ef          	jal	80000cb0 <release>
}
    80003484:	70a2                	ld	ra,40(sp)
    80003486:	7402                	ld	s0,32(sp)
    80003488:	64e2                	ld	s1,24(sp)
    8000348a:	6145                	addi	sp,sp,48
    8000348c:	8082                	ret
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    8000348e:	40b8                	lw	a4,64(s1)
    80003490:	d375                	beqz	a4,80003474 <iput+0x20>
    80003492:	e84a                	sd	s2,16(sp)
    80003494:	e052                	sd	s4,0(sp)
  uint dev = ip->dev, inum = ip->inum;
    80003496:	0004aa03          	lw	s4,0(s1)
    8000349a:	0044a903          	lw	s2,4(s1)
  if (last) {
    8000349e:	04a49703          	lh	a4,74(s1)
    800034a2:	ef3d                	bnez	a4,80003520 <iput+0xcc>
    800034a4:	e44e                	sd	s3,8(sp)
    acquiresleep(&ip->lock);
    800034a6:	01048793          	addi	a5,s1,16
    800034aa:	89be                	mv	s3,a5
    800034ac:	853e                	mv	a0,a5
    800034ae:	3b9000ef          	jal	80004066 <acquiresleep>
    release(&itable.lock);
    800034b2:	0001d517          	auipc	a0,0x1d
    800034b6:	6fe50513          	addi	a0,a0,1790 # 80020bb0 <itable>
    800034ba:	ff6fd0ef          	jal	80000cb0 <release>
    itrunc(ip); // free the data blocks (type stays nonzero on disk)
    800034be:	8526                	mv	a0,s1
    800034c0:	f01ff0ef          	jal	800033c0 <itrunc>
    ip->valid = 0;
    800034c4:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800034c8:	854e                	mv	a0,s3
    800034ca:	3f1000ef          	jal	800040ba <releasesleep>
    acquire(&itable.lock);
    800034ce:	0001d517          	auipc	a0,0x1d
    800034d2:	6e250513          	addi	a0,a0,1762 # 80020bb0 <itable>
    800034d6:	f52fd0ef          	jal	80000c28 <acquire>
  ip->ref--;
    800034da:	449c                	lw	a5,8(s1)
    800034dc:	37fd                	addiw	a5,a5,-1
    800034de:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800034e0:	0001d517          	auipc	a0,0x1d
    800034e4:	6d050513          	addi	a0,a0,1744 # 80020bb0 <itable>
    800034e8:	fc8fd0ef          	jal	80000cb0 <release>
  struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800034ec:	0049579b          	srliw	a5,s2,0x4
    800034f0:	0001d597          	auipc	a1,0x1d
    800034f4:	6b85a583          	lw	a1,1720(a1) # 80020ba8 <sb+0x18>
    800034f8:	9dbd                	addw	a1,a1,a5
    800034fa:	8552                	mv	a0,s4
    800034fc:	f3eff0ef          	jal	80002c3a <bread>
    80003500:	84aa                	mv	s1,a0
  struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003502:	00f97793          	andi	a5,s2,15
  dip->type = 0;
    80003506:	079a                	slli	a5,a5,0x6
    80003508:	97aa                	add	a5,a5,a0
    8000350a:	04079c23          	sh	zero,88(a5)
  log_write(bp);
    8000350e:	1eb000ef          	jal	80003ef8 <log_write>
  brelse(bp);
    80003512:	8526                	mv	a0,s1
    80003514:	82fff0ef          	jal	80002d42 <brelse>
}
    80003518:	6942                	ld	s2,16(sp)
    8000351a:	69a2                	ld	s3,8(sp)
    8000351c:	6a02                	ld	s4,0(sp)
    8000351e:	b79d                	j	80003484 <iput+0x30>
    80003520:	6942                	ld	s2,16(sp)
    80003522:	6a02                	ld	s4,0(sp)
    80003524:	bf81                	j	80003474 <iput+0x20>

0000000080003526 <iunlockput>:
{
    80003526:	1101                	addi	sp,sp,-32
    80003528:	ec06                	sd	ra,24(sp)
    8000352a:	e822                	sd	s0,16(sp)
    8000352c:	e426                	sd	s1,8(sp)
    8000352e:	1000                	addi	s0,sp,32
    80003530:	84aa                	mv	s1,a0
  iunlock(ip);
    80003532:	e4fff0ef          	jal	80003380 <iunlock>
  iput(ip);
    80003536:	8526                	mv	a0,s1
    80003538:	f1dff0ef          	jal	80003454 <iput>
}
    8000353c:	60e2                	ld	ra,24(sp)
    8000353e:	6442                	ld	s0,16(sp)
    80003540:	64a2                	ld	s1,8(sp)
    80003542:	6105                	addi	sp,sp,32
    80003544:	8082                	ret

0000000080003546 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003546:	0001d717          	auipc	a4,0x1d
    8000354a:	65672703          	lw	a4,1622(a4) # 80020b9c <sb+0xc>
    8000354e:	4785                	li	a5,1
    80003550:	0ae7fe63          	bgeu	a5,a4,8000360c <ireclaim+0xc6>
{
    80003554:	7139                	addi	sp,sp,-64
    80003556:	fc06                	sd	ra,56(sp)
    80003558:	f822                	sd	s0,48(sp)
    8000355a:	f426                	sd	s1,40(sp)
    8000355c:	f04a                	sd	s2,32(sp)
    8000355e:	ec4e                	sd	s3,24(sp)
    80003560:	e852                	sd	s4,16(sp)
    80003562:	e456                	sd	s5,8(sp)
    80003564:	e05a                	sd	s6,0(sp)
    80003566:	0080                	addi	s0,sp,64
    80003568:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000356a:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    8000356c:	0001da17          	auipc	s4,0x1d
    80003570:	624a0a13          	addi	s4,s4,1572 # 80020b90 <sb>
      printk("ireclaim: orphaned inode %d\n", inum);
    80003574:	00004b17          	auipc	s6,0x4
    80003578:	f14b0b13          	addi	s6,s6,-236 # 80007488 <etext+0x488>
    8000357c:	a099                	j	800035c2 <ireclaim+0x7c>
    8000357e:	85ce                	mv	a1,s3
    80003580:	855a                	mv	a0,s6
    80003582:	f89fc0ef          	jal	8000050a <printk>
      ip = iget(dev, inum);
    80003586:	85ce                	mv	a1,s3
    80003588:	8556                	mv	a0,s5
    8000358a:	ad7ff0ef          	jal	80003060 <iget>
    8000358e:	89aa                	mv	s3,a0
    brelse(bp);
    80003590:	854a                	mv	a0,s2
    80003592:	fb0ff0ef          	jal	80002d42 <brelse>
    if (ip) {
    80003596:	00098f63          	beqz	s3,800035b4 <ireclaim+0x6e>
      begin_op();
    8000359a:	7b0000ef          	jal	80003d4a <begin_op>
      ilock(ip);
    8000359e:	854e                	mv	a0,s3
    800035a0:	d33ff0ef          	jal	800032d2 <ilock>
      iunlock(ip);
    800035a4:	854e                	mv	a0,s3
    800035a6:	ddbff0ef          	jal	80003380 <iunlock>
      iput(ip);
    800035aa:	854e                	mv	a0,s3
    800035ac:	ea9ff0ef          	jal	80003454 <iput>
      end_op();
    800035b0:	027000ef          	jal	80003dd6 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800035b4:	0485                	addi	s1,s1,1
    800035b6:	00ca2703          	lw	a4,12(s4)
    800035ba:	0004879b          	sext.w	a5,s1
    800035be:	02e7fd63          	bgeu	a5,a4,800035f8 <ireclaim+0xb2>
    800035c2:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800035c6:	0044d593          	srli	a1,s1,0x4
    800035ca:	018a2783          	lw	a5,24(s4)
    800035ce:	9dbd                	addw	a1,a1,a5
    800035d0:	8556                	mv	a0,s5
    800035d2:	e68ff0ef          	jal	80002c3a <bread>
    800035d6:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    800035d8:	05850793          	addi	a5,a0,88
    800035dc:	00f9f713          	andi	a4,s3,15
    800035e0:	071a                	slli	a4,a4,0x6
    800035e2:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) { // is an orphaned inode
    800035e4:	00079703          	lh	a4,0(a5)
    800035e8:	c701                	beqz	a4,800035f0 <ireclaim+0xaa>
    800035ea:	00679783          	lh	a5,6(a5)
    800035ee:	dbc1                	beqz	a5,8000357e <ireclaim+0x38>
    brelse(bp);
    800035f0:	854a                	mv	a0,s2
    800035f2:	f50ff0ef          	jal	80002d42 <brelse>
    if (ip) {
    800035f6:	bf7d                	j	800035b4 <ireclaim+0x6e>
}
    800035f8:	70e2                	ld	ra,56(sp)
    800035fa:	7442                	ld	s0,48(sp)
    800035fc:	74a2                	ld	s1,40(sp)
    800035fe:	7902                	ld	s2,32(sp)
    80003600:	69e2                	ld	s3,24(sp)
    80003602:	6a42                	ld	s4,16(sp)
    80003604:	6aa2                	ld	s5,8(sp)
    80003606:	6b02                	ld	s6,0(sp)
    80003608:	6121                	addi	sp,sp,64
    8000360a:	8082                	ret
    8000360c:	8082                	ret

000000008000360e <fsinit>:
{
    8000360e:	1101                	addi	sp,sp,-32
    80003610:	ec06                	sd	ra,24(sp)
    80003612:	e822                	sd	s0,16(sp)
    80003614:	e426                	sd	s1,8(sp)
    80003616:	e04a                	sd	s2,0(sp)
    80003618:	1000                	addi	s0,sp,32
    8000361a:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    8000361c:	4585                	li	a1,1
    8000361e:	e1cff0ef          	jal	80002c3a <bread>
    80003622:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003624:	02000613          	li	a2,32
    80003628:	05850593          	addi	a1,a0,88
    8000362c:	0001d517          	auipc	a0,0x1d
    80003630:	56450513          	addi	a0,a0,1380 # 80020b90 <sb>
    80003634:	f14fd0ef          	jal	80000d48 <memmove>
  brelse(bp);
    80003638:	8526                	mv	a0,s1
    8000363a:	f08ff0ef          	jal	80002d42 <brelse>
  if (sb.magic != FSMAGIC)
    8000363e:	0001d717          	auipc	a4,0x1d
    80003642:	55272703          	lw	a4,1362(a4) # 80020b90 <sb>
    80003646:	102037b7          	lui	a5,0x10203
    8000364a:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    8000364e:	02f71263          	bne	a4,a5,80003672 <fsinit+0x64>
  initlog(dev, &sb);
    80003652:	0001d597          	auipc	a1,0x1d
    80003656:	53e58593          	addi	a1,a1,1342 # 80020b90 <sb>
    8000365a:	854a                	mv	a0,s2
    8000365c:	66c000ef          	jal	80003cc8 <initlog>
  ireclaim(dev);
    80003660:	854a                	mv	a0,s2
    80003662:	ee5ff0ef          	jal	80003546 <ireclaim>
}
    80003666:	60e2                	ld	ra,24(sp)
    80003668:	6442                	ld	s0,16(sp)
    8000366a:	64a2                	ld	s1,8(sp)
    8000366c:	6902                	ld	s2,0(sp)
    8000366e:	6105                	addi	sp,sp,32
    80003670:	8082                	ret
    panic("invalid file system");
    80003672:	00004517          	auipc	a0,0x4
    80003676:	e3650513          	addi	a0,a0,-458 # 800074a8 <etext+0x4a8>
    8000367a:	9bafd0ef          	jal	80000834 <panic>

000000008000367e <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    8000367e:	1141                	addi	sp,sp,-16
    80003680:	e406                	sd	ra,8(sp)
    80003682:	e022                	sd	s0,0(sp)
    80003684:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003686:	411c                	lw	a5,0(a0)
    80003688:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    8000368a:	415c                	lw	a5,4(a0)
    8000368c:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    8000368e:	04451783          	lh	a5,68(a0)
    80003692:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003696:	04a51783          	lh	a5,74(a0)
    8000369a:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    8000369e:	04c56783          	lwu	a5,76(a0)
    800036a2:	e99c                	sd	a5,16(a1)
}
    800036a4:	60a2                	ld	ra,8(sp)
    800036a6:	6402                	ld	s0,0(sp)
    800036a8:	0141                	addi	sp,sp,16
    800036aa:	8082                	ret

00000000800036ac <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    800036ac:	457c                	lw	a5,76(a0)
    800036ae:	0ed7e663          	bltu	a5,a3,8000379a <readi+0xee>
{
    800036b2:	7159                	addi	sp,sp,-112
    800036b4:	f486                	sd	ra,104(sp)
    800036b6:	f0a2                	sd	s0,96(sp)
    800036b8:	eca6                	sd	s1,88(sp)
    800036ba:	e0d2                	sd	s4,64(sp)
    800036bc:	fc56                	sd	s5,56(sp)
    800036be:	f85a                	sd	s6,48(sp)
    800036c0:	f45e                	sd	s7,40(sp)
    800036c2:	1880                	addi	s0,sp,112
    800036c4:	8b2a                	mv	s6,a0
    800036c6:	8bae                	mv	s7,a1
    800036c8:	8a32                	mv	s4,a2
    800036ca:	84b6                	mv	s1,a3
    800036cc:	8aba                	mv	s5,a4
  if (off > ip->size || off + n < off)
    800036ce:	9f35                	addw	a4,a4,a3
    return 0;
    800036d0:	4501                	li	a0,0
  if (off > ip->size || off + n < off)
    800036d2:	0ad76b63          	bltu	a4,a3,80003788 <readi+0xdc>
    800036d6:	e4ce                	sd	s3,72(sp)
  if (off + n > ip->size)
    800036d8:	00e7f463          	bgeu	a5,a4,800036e0 <readi+0x34>
    n = ip->size - off;
    800036dc:	40d78abb          	subw	s5,a5,a3

  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    800036e0:	080a8b63          	beqz	s5,80003776 <readi+0xca>
    800036e4:	e8ca                	sd	s2,80(sp)
    800036e6:	f062                	sd	s8,32(sp)
    800036e8:	ec66                	sd	s9,24(sp)
    800036ea:	e86a                	sd	s10,16(sp)
    800036ec:	e46e                	sd	s11,8(sp)
    800036ee:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    800036f0:	40000c93          	li	s9,1024
    if (either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800036f4:	5c7d                	li	s8,-1
    800036f6:	a80d                	j	80003728 <readi+0x7c>
    800036f8:	020d1d93          	slli	s11,s10,0x20
    800036fc:	020ddd93          	srli	s11,s11,0x20
    80003700:	05890613          	addi	a2,s2,88
    80003704:	86ee                	mv	a3,s11
    80003706:	963e                	add	a2,a2,a5
    80003708:	85d2                	mv	a1,s4
    8000370a:	855e                	mv	a0,s7
    8000370c:	bddfe0ef          	jal	800022e8 <either_copyout>
    80003710:	05850363          	beq	a0,s8,80003756 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003714:	854a                	mv	a0,s2
    80003716:	e2cff0ef          	jal	80002d42 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    8000371a:	013d09bb          	addw	s3,s10,s3
    8000371e:	009d04bb          	addw	s1,s10,s1
    80003722:	9a6e                	add	s4,s4,s11
    80003724:	0559f363          	bgeu	s3,s5,8000376a <readi+0xbe>
    uint addr = bmap(ip, off / BSIZE);
    80003728:	00a4d59b          	srliw	a1,s1,0xa
    8000372c:	855a                	mv	a0,s6
    8000372e:	873ff0ef          	jal	80002fa0 <bmap>
    80003732:	85aa                	mv	a1,a0
    if (addr == 0)
    80003734:	c139                	beqz	a0,8000377a <readi+0xce>
    bp = bread(ip->dev, addr);
    80003736:	000b2503          	lw	a0,0(s6)
    8000373a:	d00ff0ef          	jal	80002c3a <bread>
    8000373e:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    80003740:	3ff4f793          	andi	a5,s1,1023
    80003744:	40fc873b          	subw	a4,s9,a5
    80003748:	413a86bb          	subw	a3,s5,s3
    8000374c:	8d3a                	mv	s10,a4
    8000374e:	fae6f5e3          	bgeu	a3,a4,800036f8 <readi+0x4c>
    80003752:	8d36                	mv	s10,a3
    80003754:	b755                	j	800036f8 <readi+0x4c>
      brelse(bp);
    80003756:	854a                	mv	a0,s2
    80003758:	deaff0ef          	jal	80002d42 <brelse>
      tot = -1;
    8000375c:	59fd                	li	s3,-1
      break;
    8000375e:	6946                	ld	s2,80(sp)
    80003760:	7c02                	ld	s8,32(sp)
    80003762:	6ce2                	ld	s9,24(sp)
    80003764:	6d42                	ld	s10,16(sp)
    80003766:	6da2                	ld	s11,8(sp)
    80003768:	a831                	j	80003784 <readi+0xd8>
    8000376a:	6946                	ld	s2,80(sp)
    8000376c:	7c02                	ld	s8,32(sp)
    8000376e:	6ce2                	ld	s9,24(sp)
    80003770:	6d42                	ld	s10,16(sp)
    80003772:	6da2                	ld	s11,8(sp)
    80003774:	a801                	j	80003784 <readi+0xd8>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003776:	89d6                	mv	s3,s5
    80003778:	a031                	j	80003784 <readi+0xd8>
    8000377a:	6946                	ld	s2,80(sp)
    8000377c:	7c02                	ld	s8,32(sp)
    8000377e:	6ce2                	ld	s9,24(sp)
    80003780:	6d42                	ld	s10,16(sp)
    80003782:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003784:	854e                	mv	a0,s3
    80003786:	69a6                	ld	s3,72(sp)
}
    80003788:	70a6                	ld	ra,104(sp)
    8000378a:	7406                	ld	s0,96(sp)
    8000378c:	64e6                	ld	s1,88(sp)
    8000378e:	6a06                	ld	s4,64(sp)
    80003790:	7ae2                	ld	s5,56(sp)
    80003792:	7b42                	ld	s6,48(sp)
    80003794:	7ba2                	ld	s7,40(sp)
    80003796:	6165                	addi	sp,sp,112
    80003798:	8082                	ret
    return 0;
    8000379a:	4501                	li	a0,0
}
    8000379c:	8082                	ret

000000008000379e <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    8000379e:	457c                	lw	a5,76(a0)
    800037a0:	0ed7ee63          	bltu	a5,a3,8000389c <writei+0xfe>
{
    800037a4:	7159                	addi	sp,sp,-112
    800037a6:	f486                	sd	ra,104(sp)
    800037a8:	f0a2                	sd	s0,96(sp)
    800037aa:	e8ca                	sd	s2,80(sp)
    800037ac:	e0d2                	sd	s4,64(sp)
    800037ae:	fc56                	sd	s5,56(sp)
    800037b0:	f85a                	sd	s6,48(sp)
    800037b2:	f45e                	sd	s7,40(sp)
    800037b4:	1880                	addi	s0,sp,112
    800037b6:	8aaa                	mv	s5,a0
    800037b8:	8bae                	mv	s7,a1
    800037ba:	8a32                	mv	s4,a2
    800037bc:	8936                	mv	s2,a3
    800037be:	8b3a                	mv	s6,a4
  if (off > ip->size || off + n < off)
    800037c0:	00e687bb          	addw	a5,a3,a4
    return -1;
  if (off + n > MAXFILE * BSIZE)
    800037c4:	00043737          	lui	a4,0x43
    800037c8:	0cf76c63          	bltu	a4,a5,800038a0 <writei+0x102>
    800037cc:	0cd7ea63          	bltu	a5,a3,800038a0 <writei+0x102>
    800037d0:	e4ce                	sd	s3,72(sp)
    return -1;

  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    800037d2:	0a0b0d63          	beqz	s6,8000388c <writei+0xee>
    800037d6:	eca6                	sd	s1,88(sp)
    800037d8:	f062                	sd	s8,32(sp)
    800037da:	ec66                	sd	s9,24(sp)
    800037dc:	e86a                	sd	s10,16(sp)
    800037de:	e46e                	sd	s11,8(sp)
    800037e0:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    800037e2:	40000c93          	li	s9,1024
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    800037e6:	5c7d                	li	s8,-1
    800037e8:	a825                	j	80003820 <writei+0x82>
    800037ea:	020d1d93          	slli	s11,s10,0x20
    800037ee:	020ddd93          	srli	s11,s11,0x20
    800037f2:	05848513          	addi	a0,s1,88
    800037f6:	86ee                	mv	a3,s11
    800037f8:	8652                	mv	a2,s4
    800037fa:	85de                	mv	a1,s7
    800037fc:	953e                	add	a0,a0,a5
    800037fe:	b37fe0ef          	jal	80002334 <either_copyin>
    80003802:	05850663          	beq	a0,s8,8000384e <writei+0xb0>
      // Might have partially updated the block, so we need to log it.
      log_write(bp);
      brelse(bp);
      break;
    }
    log_write(bp);
    80003806:	8526                	mv	a0,s1
    80003808:	6f0000ef          	jal	80003ef8 <log_write>
    brelse(bp);
    8000380c:	8526                	mv	a0,s1
    8000380e:	d34ff0ef          	jal	80002d42 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003812:	013d09bb          	addw	s3,s10,s3
    80003816:	012d093b          	addw	s2,s10,s2
    8000381a:	9a6e                	add	s4,s4,s11
    8000381c:	0369ff63          	bgeu	s3,s6,8000385a <writei+0xbc>
    uint addr = bmap(ip, off / BSIZE);
    80003820:	00a9559b          	srliw	a1,s2,0xa
    80003824:	8556                	mv	a0,s5
    80003826:	f7aff0ef          	jal	80002fa0 <bmap>
    8000382a:	85aa                	mv	a1,a0
    if (addr == 0)
    8000382c:	c51d                	beqz	a0,8000385a <writei+0xbc>
    bp = bread(ip->dev, addr);
    8000382e:	000aa503          	lw	a0,0(s5)
    80003832:	c08ff0ef          	jal	80002c3a <bread>
    80003836:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    80003838:	3ff97793          	andi	a5,s2,1023
    8000383c:	40fc873b          	subw	a4,s9,a5
    80003840:	413b06bb          	subw	a3,s6,s3
    80003844:	8d3a                	mv	s10,a4
    80003846:	fae6f2e3          	bgeu	a3,a4,800037ea <writei+0x4c>
    8000384a:	8d36                	mv	s10,a3
    8000384c:	bf79                	j	800037ea <writei+0x4c>
      log_write(bp);
    8000384e:	8526                	mv	a0,s1
    80003850:	6a8000ef          	jal	80003ef8 <log_write>
      brelse(bp);
    80003854:	8526                	mv	a0,s1
    80003856:	cecff0ef          	jal	80002d42 <brelse>
  }

  if (off > ip->size)
    8000385a:	04caa783          	lw	a5,76(s5)
    8000385e:	0327f963          	bgeu	a5,s2,80003890 <writei+0xf2>
    ip->size = off;
    80003862:	052aa623          	sw	s2,76(s5)
    80003866:	64e6                	ld	s1,88(sp)
    80003868:	7c02                	ld	s8,32(sp)
    8000386a:	6ce2                	ld	s9,24(sp)
    8000386c:	6d42                	ld	s10,16(sp)
    8000386e:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003870:	8556                	mv	a0,s5
    80003872:	9adff0ef          	jal	8000321e <iupdate>

  return tot;
    80003876:	854e                	mv	a0,s3
    80003878:	69a6                	ld	s3,72(sp)
}
    8000387a:	70a6                	ld	ra,104(sp)
    8000387c:	7406                	ld	s0,96(sp)
    8000387e:	6946                	ld	s2,80(sp)
    80003880:	6a06                	ld	s4,64(sp)
    80003882:	7ae2                	ld	s5,56(sp)
    80003884:	7b42                	ld	s6,48(sp)
    80003886:	7ba2                	ld	s7,40(sp)
    80003888:	6165                	addi	sp,sp,112
    8000388a:	8082                	ret
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    8000388c:	89da                	mv	s3,s6
    8000388e:	b7cd                	j	80003870 <writei+0xd2>
    80003890:	64e6                	ld	s1,88(sp)
    80003892:	7c02                	ld	s8,32(sp)
    80003894:	6ce2                	ld	s9,24(sp)
    80003896:	6d42                	ld	s10,16(sp)
    80003898:	6da2                	ld	s11,8(sp)
    8000389a:	bfd9                	j	80003870 <writei+0xd2>
    return -1;
    8000389c:	557d                	li	a0,-1
}
    8000389e:	8082                	ret
    return -1;
    800038a0:	557d                	li	a0,-1
    800038a2:	bfe1                	j	8000387a <writei+0xdc>

00000000800038a4 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    800038a4:	1141                	addi	sp,sp,-16
    800038a6:	e406                	sd	ra,8(sp)
    800038a8:	e022                	sd	s0,0(sp)
    800038aa:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    800038ac:	4639                	li	a2,14
    800038ae:	d0efd0ef          	jal	80000dbc <strncmp>
}
    800038b2:	60a2                	ld	ra,8(sp)
    800038b4:	6402                	ld	s0,0(sp)
    800038b6:	0141                	addi	sp,sp,16
    800038b8:	8082                	ret

00000000800038ba <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, char *name, uint *poff)
{
    800038ba:	711d                	addi	sp,sp,-96
    800038bc:	ec86                	sd	ra,88(sp)
    800038be:	e8a2                	sd	s0,80(sp)
    800038c0:	e4a6                	sd	s1,72(sp)
    800038c2:	e0ca                	sd	s2,64(sp)
    800038c4:	fc4e                	sd	s3,56(sp)
    800038c6:	f852                	sd	s4,48(sp)
    800038c8:	f456                	sd	s5,40(sp)
    800038ca:	f05a                	sd	s6,32(sp)
    800038cc:	ec5e                	sd	s7,24(sp)
    800038ce:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if (dp->type != T_DIR)
    800038d0:	04451703          	lh	a4,68(a0)
    800038d4:	4785                	li	a5,1
    800038d6:	00f71f63          	bne	a4,a5,800038f4 <dirlookup+0x3a>
    800038da:	892a                	mv	s2,a0
    800038dc:	8aae                	mv	s5,a1
    800038de:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for (off = 0; off < dp->size; off += sizeof(de)) {
    800038e0:	457c                	lw	a5,76(a0)
    800038e2:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800038e4:	fa040a13          	addi	s4,s0,-96
    800038e8:	49c1                	li	s3,16
      panic("dirlookup read");
    if (de.inum == 0)
      continue;
    if (namecmp(name, de.name) == 0) {
    800038ea:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    800038ee:	4501                	li	a0,0
  for (off = 0; off < dp->size; off += sizeof(de)) {
    800038f0:	e39d                	bnez	a5,80003916 <dirlookup+0x5c>
    800038f2:	a8b9                	j	80003950 <dirlookup+0x96>
    panic("dirlookup not DIR");
    800038f4:	00004517          	auipc	a0,0x4
    800038f8:	bcc50513          	addi	a0,a0,-1076 # 800074c0 <etext+0x4c0>
    800038fc:	f39fc0ef          	jal	80000834 <panic>
      panic("dirlookup read");
    80003900:	00004517          	auipc	a0,0x4
    80003904:	bd850513          	addi	a0,a0,-1064 # 800074d8 <etext+0x4d8>
    80003908:	f2dfc0ef          	jal	80000834 <panic>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    8000390c:	24c1                	addiw	s1,s1,16
    8000390e:	04c92783          	lw	a5,76(s2)
    80003912:	02f4fe63          	bgeu	s1,a5,8000394e <dirlookup+0x94>
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003916:	874e                	mv	a4,s3
    80003918:	86a6                	mv	a3,s1
    8000391a:	8652                	mv	a2,s4
    8000391c:	4581                	li	a1,0
    8000391e:	854a                	mv	a0,s2
    80003920:	d8dff0ef          	jal	800036ac <readi>
    80003924:	fd351ee3          	bne	a0,s3,80003900 <dirlookup+0x46>
    if (de.inum == 0)
    80003928:	fa045783          	lhu	a5,-96(s0)
    8000392c:	d3e5                	beqz	a5,8000390c <dirlookup+0x52>
    if (namecmp(name, de.name) == 0) {
    8000392e:	85da                	mv	a1,s6
    80003930:	8556                	mv	a0,s5
    80003932:	f73ff0ef          	jal	800038a4 <namecmp>
    80003936:	f979                	bnez	a0,8000390c <dirlookup+0x52>
      if (poff)
    80003938:	000b8463          	beqz	s7,80003940 <dirlookup+0x86>
        *poff = off;
    8000393c:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80003940:	fa045583          	lhu	a1,-96(s0)
    80003944:	00092503          	lw	a0,0(s2)
    80003948:	f18ff0ef          	jal	80003060 <iget>
    8000394c:	a011                	j	80003950 <dirlookup+0x96>
  return 0;
    8000394e:	4501                	li	a0,0
}
    80003950:	60e6                	ld	ra,88(sp)
    80003952:	6446                	ld	s0,80(sp)
    80003954:	64a6                	ld	s1,72(sp)
    80003956:	6906                	ld	s2,64(sp)
    80003958:	79e2                	ld	s3,56(sp)
    8000395a:	7a42                	ld	s4,48(sp)
    8000395c:	7aa2                	ld	s5,40(sp)
    8000395e:	7b02                	ld	s6,32(sp)
    80003960:	6be2                	ld	s7,24(sp)
    80003962:	6125                	addi	sp,sp,96
    80003964:	8082                	ret

0000000080003966 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode *
namex(char *path, int nameiparent, char *name)
{
    80003966:	711d                	addi	sp,sp,-96
    80003968:	ec86                	sd	ra,88(sp)
    8000396a:	e8a2                	sd	s0,80(sp)
    8000396c:	e4a6                	sd	s1,72(sp)
    8000396e:	e0ca                	sd	s2,64(sp)
    80003970:	fc4e                	sd	s3,56(sp)
    80003972:	f852                	sd	s4,48(sp)
    80003974:	f456                	sd	s5,40(sp)
    80003976:	f05a                	sd	s6,32(sp)
    80003978:	ec5e                	sd	s7,24(sp)
    8000397a:	e862                	sd	s8,16(sp)
    8000397c:	e466                	sd	s9,8(sp)
    8000397e:	e06a                	sd	s10,0(sp)
    80003980:	1080                	addi	s0,sp,96
    80003982:	84aa                	mv	s1,a0
    80003984:	8b2e                	mv	s6,a1
    80003986:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if (*path == '/')
    80003988:	00054703          	lbu	a4,0(a0)
    8000398c:	02f00793          	li	a5,47
    80003990:	00f70f63          	beq	a4,a5,800039ae <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003994:	fb9fd0ef          	jal	8000194c <myproc>
    80003998:	15053503          	ld	a0,336(a0)
    8000399c:	901ff0ef          	jal	8000329c <idup>
    800039a0:	8a2a                	mv	s4,a0
  while (*path == '/')
    800039a2:	02f00993          	li	s3,47
  if (len >= DIRSIZ)
    800039a6:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    800039a8:	4cb9                	li	s9,14

  while ((path = skipelem(path, name)) != 0) {
    ilock(ip);
    if (ip->type != T_DIR) {
    800039aa:	4b85                	li	s7,1
    800039ac:	a07d                	j	80003a5a <namex+0xf4>
    ip = iget(ROOTDEV, ROOTINO);
    800039ae:	4585                	li	a1,1
    800039b0:	852e                	mv	a0,a1
    800039b2:	eaeff0ef          	jal	80003060 <iget>
    800039b6:	8a2a                	mv	s4,a0
    800039b8:	b7ed                	j	800039a2 <namex+0x3c>
      iunlockput(ip);
    800039ba:	8552                	mv	a0,s4
    800039bc:	b6bff0ef          	jal	80003526 <iunlockput>
      return 0;
    800039c0:	4a01                	li	s4,0
  if (nameiparent) {
    iput(ip);
    return 0;
  }
  return ip;
}
    800039c2:	8552                	mv	a0,s4
    800039c4:	60e6                	ld	ra,88(sp)
    800039c6:	6446                	ld	s0,80(sp)
    800039c8:	64a6                	ld	s1,72(sp)
    800039ca:	6906                	ld	s2,64(sp)
    800039cc:	79e2                	ld	s3,56(sp)
    800039ce:	7a42                	ld	s4,48(sp)
    800039d0:	7aa2                	ld	s5,40(sp)
    800039d2:	7b02                	ld	s6,32(sp)
    800039d4:	6be2                	ld	s7,24(sp)
    800039d6:	6c42                	ld	s8,16(sp)
    800039d8:	6ca2                	ld	s9,8(sp)
    800039da:	6d02                	ld	s10,0(sp)
    800039dc:	6125                	addi	sp,sp,96
    800039de:	8082                	ret
      iunlockput(ip);
    800039e0:	8552                	mv	a0,s4
    800039e2:	b45ff0ef          	jal	80003526 <iunlockput>
      return 0;
    800039e6:	4a01                	li	s4,0
    800039e8:	bfe9                	j	800039c2 <namex+0x5c>
      iunlock(ip);
    800039ea:	8552                	mv	a0,s4
    800039ec:	995ff0ef          	jal	80003380 <iunlock>
      return ip;
    800039f0:	bfc9                	j	800039c2 <namex+0x5c>
      iunlockput(ip);
    800039f2:	8552                	mv	a0,s4
    800039f4:	b33ff0ef          	jal	80003526 <iunlockput>
      return 0;
    800039f8:	8a4a                	mv	s4,s2
    800039fa:	b7e1                	j	800039c2 <namex+0x5c>
  while (*path != '/' && *path != 0)
    800039fc:	8926                	mv	s2,s1
  len = path - s;
    800039fe:	4d01                	li	s10,0
    80003a00:	4601                	li	a2,0
    memmove(name, s, len);
    80003a02:	2601                	sext.w	a2,a2
    80003a04:	85a6                	mv	a1,s1
    80003a06:	8556                	mv	a0,s5
    80003a08:	b40fd0ef          	jal	80000d48 <memmove>
    name[len] = 0;
    80003a0c:	9d56                	add	s10,s10,s5
    80003a0e:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffdb740>
  while (*path == '/')
    80003a12:	00094783          	lbu	a5,0(s2)
    80003a16:	09379b63          	bne	a5,s3,80003aac <namex+0x146>
    80003a1a:	84ca                	mv	s1,s2
    path++;
    80003a1c:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003a1e:	0004c783          	lbu	a5,0(s1)
    80003a22:	ff378de3          	beq	a5,s3,80003a1c <namex+0xb6>
    ilock(ip);
    80003a26:	8552                	mv	a0,s4
    80003a28:	8abff0ef          	jal	800032d2 <ilock>
    if (ip->type != T_DIR) {
    80003a2c:	044a1783          	lh	a5,68(s4)
    80003a30:	f97795e3          	bne	a5,s7,800039ba <namex+0x54>
    if (ip->nlink == 0) {
    80003a34:	04aa1783          	lh	a5,74(s4)
    80003a38:	d7c5                	beqz	a5,800039e0 <namex+0x7a>
    if (nameiparent && *path == '\0') {
    80003a3a:	000b0563          	beqz	s6,80003a44 <namex+0xde>
    80003a3e:	0004c783          	lbu	a5,0(s1)
    80003a42:	d7c5                	beqz	a5,800039ea <namex+0x84>
    if ((next = dirlookup(ip, name, 0)) == 0) {
    80003a44:	4601                	li	a2,0
    80003a46:	85d6                	mv	a1,s5
    80003a48:	8552                	mv	a0,s4
    80003a4a:	e71ff0ef          	jal	800038ba <dirlookup>
    80003a4e:	892a                	mv	s2,a0
    80003a50:	d14d                	beqz	a0,800039f2 <namex+0x8c>
    iunlockput(ip);
    80003a52:	8552                	mv	a0,s4
    80003a54:	ad3ff0ef          	jal	80003526 <iunlockput>
    ip = next;
    80003a58:	8a4a                	mv	s4,s2
  while (*path == '/')
    80003a5a:	0004c783          	lbu	a5,0(s1)
    80003a5e:	01379763          	bne	a5,s3,80003a6c <namex+0x106>
    path++;
    80003a62:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003a64:	0004c783          	lbu	a5,0(s1)
    80003a68:	ff378de3          	beq	a5,s3,80003a62 <namex+0xfc>
  if (*path == 0)
    80003a6c:	c7a1                	beqz	a5,80003ab4 <namex+0x14e>
  while (*path != '/' && *path != 0)
    80003a6e:	0004c783          	lbu	a5,0(s1)
    80003a72:	fd178713          	addi	a4,a5,-47
    80003a76:	d359                	beqz	a4,800039fc <namex+0x96>
    80003a78:	d3d1                	beqz	a5,800039fc <namex+0x96>
    80003a7a:	8926                	mv	s2,s1
    path++;
    80003a7c:	0905                	addi	s2,s2,1
  while (*path != '/' && *path != 0)
    80003a7e:	00094783          	lbu	a5,0(s2)
    80003a82:	fd178713          	addi	a4,a5,-47
    80003a86:	c311                	beqz	a4,80003a8a <namex+0x124>
    80003a88:	fbf5                	bnez	a5,80003a7c <namex+0x116>
  len = path - s;
    80003a8a:	40990633          	sub	a2,s2,s1
    80003a8e:	00060d1b          	sext.w	s10,a2
  if (len >= DIRSIZ)
    80003a92:	f7ac58e3          	bge	s8,s10,80003a02 <namex+0x9c>
    memmove(name, s, DIRSIZ);
    80003a96:	8666                	mv	a2,s9
    80003a98:	85a6                	mv	a1,s1
    80003a9a:	8556                	mv	a0,s5
    80003a9c:	aacfd0ef          	jal	80000d48 <memmove>
  while (*path == '/')
    80003aa0:	00094783          	lbu	a5,0(s2)
    80003aa4:	84ca                	mv	s1,s2
    80003aa6:	f7378be3          	beq	a5,s3,80003a1c <namex+0xb6>
    80003aaa:	bfb5                	j	80003a26 <namex+0xc0>
  while ((path = skipelem(path, name)) != 0) {
    80003aac:	00090463          	beqz	s2,80003ab4 <namex+0x14e>
    80003ab0:	84ca                	mv	s1,s2
    80003ab2:	bf95                	j	80003a26 <namex+0xc0>
  if (nameiparent) {
    80003ab4:	f00b07e3          	beqz	s6,800039c2 <namex+0x5c>
    iput(ip);
    80003ab8:	8552                	mv	a0,s4
    80003aba:	99bff0ef          	jal	80003454 <iput>
    return 0;
    80003abe:	4a01                	li	s4,0
    80003ac0:	b709                	j	800039c2 <namex+0x5c>

0000000080003ac2 <dirlink>:
{
    80003ac2:	715d                	addi	sp,sp,-80
    80003ac4:	e486                	sd	ra,72(sp)
    80003ac6:	e0a2                	sd	s0,64(sp)
    80003ac8:	f84a                	sd	s2,48(sp)
    80003aca:	ec56                	sd	s5,24(sp)
    80003acc:	e85a                	sd	s6,16(sp)
    80003ace:	0880                	addi	s0,sp,80
    80003ad0:	892a                	mv	s2,a0
    80003ad2:	8aae                	mv	s5,a1
    80003ad4:	8b32                	mv	s6,a2
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80003ad6:	4601                	li	a2,0
    80003ad8:	de3ff0ef          	jal	800038ba <dirlookup>
    80003adc:	ed1d                	bnez	a0,80003b1a <dirlink+0x58>
    80003ade:	fc26                	sd	s1,56(sp)
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003ae0:	04c92483          	lw	s1,76(s2)
    80003ae4:	c4b9                	beqz	s1,80003b32 <dirlink+0x70>
    80003ae6:	f44e                	sd	s3,40(sp)
    80003ae8:	f052                	sd	s4,32(sp)
    80003aea:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003aec:	fb040a13          	addi	s4,s0,-80
    80003af0:	49c1                	li	s3,16
    80003af2:	874e                	mv	a4,s3
    80003af4:	86a6                	mv	a3,s1
    80003af6:	8652                	mv	a2,s4
    80003af8:	4581                	li	a1,0
    80003afa:	854a                	mv	a0,s2
    80003afc:	bb1ff0ef          	jal	800036ac <readi>
    80003b00:	03351163          	bne	a0,s3,80003b22 <dirlink+0x60>
    if (de.inum == 0)
    80003b04:	fb045783          	lhu	a5,-80(s0)
    80003b08:	c39d                	beqz	a5,80003b2e <dirlink+0x6c>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003b0a:	24c1                	addiw	s1,s1,16
    80003b0c:	04c92783          	lw	a5,76(s2)
    80003b10:	fef4e1e3          	bltu	s1,a5,80003af2 <dirlink+0x30>
    80003b14:	79a2                	ld	s3,40(sp)
    80003b16:	7a02                	ld	s4,32(sp)
    80003b18:	a829                	j	80003b32 <dirlink+0x70>
    iput(ip);
    80003b1a:	93bff0ef          	jal	80003454 <iput>
    return -1;
    80003b1e:	557d                	li	a0,-1
    80003b20:	a83d                	j	80003b5e <dirlink+0x9c>
      panic("dirlink read");
    80003b22:	00004517          	auipc	a0,0x4
    80003b26:	9c650513          	addi	a0,a0,-1594 # 800074e8 <etext+0x4e8>
    80003b2a:	d0bfc0ef          	jal	80000834 <panic>
    80003b2e:	79a2                	ld	s3,40(sp)
    80003b30:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003b32:	4639                	li	a2,14
    80003b34:	85d6                	mv	a1,s5
    80003b36:	fb240513          	addi	a0,s0,-78
    80003b3a:	abcfd0ef          	jal	80000df6 <strncpy>
  de.inum = inum;
    80003b3e:	fb641823          	sh	s6,-80(s0)
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003b42:	4741                	li	a4,16
    80003b44:	86a6                	mv	a3,s1
    80003b46:	fb040613          	addi	a2,s0,-80
    80003b4a:	4581                	li	a1,0
    80003b4c:	854a                	mv	a0,s2
    80003b4e:	c51ff0ef          	jal	8000379e <writei>
    80003b52:	1541                	addi	a0,a0,-16
    80003b54:	00a03533          	snez	a0,a0
    80003b58:	40a0053b          	negw	a0,a0
    80003b5c:	74e2                	ld	s1,56(sp)
}
    80003b5e:	60a6                	ld	ra,72(sp)
    80003b60:	6406                	ld	s0,64(sp)
    80003b62:	7942                	ld	s2,48(sp)
    80003b64:	6ae2                	ld	s5,24(sp)
    80003b66:	6b42                	ld	s6,16(sp)
    80003b68:	6161                	addi	sp,sp,80
    80003b6a:	8082                	ret

0000000080003b6c <namei>:

struct inode *
namei(char *path)
{
    80003b6c:	1101                	addi	sp,sp,-32
    80003b6e:	ec06                	sd	ra,24(sp)
    80003b70:	e822                	sd	s0,16(sp)
    80003b72:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003b74:	fe040613          	addi	a2,s0,-32
    80003b78:	4581                	li	a1,0
    80003b7a:	dedff0ef          	jal	80003966 <namex>
}
    80003b7e:	60e2                	ld	ra,24(sp)
    80003b80:	6442                	ld	s0,16(sp)
    80003b82:	6105                	addi	sp,sp,32
    80003b84:	8082                	ret

0000000080003b86 <nameiparent>:

struct inode *
nameiparent(char *path, char *name)
{
    80003b86:	1141                	addi	sp,sp,-16
    80003b88:	e406                	sd	ra,8(sp)
    80003b8a:	e022                	sd	s0,0(sp)
    80003b8c:	0800                	addi	s0,sp,16
    80003b8e:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003b90:	4585                	li	a1,1
    80003b92:	dd5ff0ef          	jal	80003966 <namex>
}
    80003b96:	60a2                	ld	ra,8(sp)
    80003b98:	6402                	ld	s0,0(sp)
    80003b9a:	0141                	addi	sp,sp,16
    80003b9c:	8082                	ret

0000000080003b9e <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003b9e:	1101                	addi	sp,sp,-32
    80003ba0:	ec06                	sd	ra,24(sp)
    80003ba2:	e822                	sd	s0,16(sp)
    80003ba4:	e426                	sd	s1,8(sp)
    80003ba6:	e04a                	sd	s2,0(sp)
    80003ba8:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003baa:	0001f917          	auipc	s2,0x1f
    80003bae:	aae90913          	addi	s2,s2,-1362 # 80022658 <log>
    80003bb2:	01892583          	lw	a1,24(s2)
    80003bb6:	02492503          	lw	a0,36(s2)
    80003bba:	880ff0ef          	jal	80002c3a <bread>
    80003bbe:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *)(buf->data);
  int i;
  hb->n = log.lh.n;
    80003bc0:	02c92603          	lw	a2,44(s2)
    80003bc4:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003bc6:	00c05f63          	blez	a2,80003be4 <write_head+0x46>
    80003bca:	0001f717          	auipc	a4,0x1f
    80003bce:	abe70713          	addi	a4,a4,-1346 # 80022688 <log+0x30>
    80003bd2:	87aa                	mv	a5,a0
    80003bd4:	060a                	slli	a2,a2,0x2
    80003bd6:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003bd8:	4314                	lw	a3,0(a4)
    80003bda:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003bdc:	0711                	addi	a4,a4,4
    80003bde:	0791                	addi	a5,a5,4
    80003be0:	fec79ce3          	bne	a5,a2,80003bd8 <write_head+0x3a>
  }
  bwrite(buf);
    80003be4:	8526                	mv	a0,s1
    80003be6:	92aff0ef          	jal	80002d10 <bwrite>
  brelse(buf);
    80003bea:	8526                	mv	a0,s1
    80003bec:	956ff0ef          	jal	80002d42 <brelse>
}
    80003bf0:	60e2                	ld	ra,24(sp)
    80003bf2:	6442                	ld	s0,16(sp)
    80003bf4:	64a2                	ld	s1,8(sp)
    80003bf6:	6902                	ld	s2,0(sp)
    80003bf8:	6105                	addi	sp,sp,32
    80003bfa:	8082                	ret

0000000080003bfc <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003bfc:	0001f797          	auipc	a5,0x1f
    80003c00:	a887a783          	lw	a5,-1400(a5) # 80022684 <log+0x2c>
    80003c04:	0cf05163          	blez	a5,80003cc6 <install_trans+0xca>
{
    80003c08:	715d                	addi	sp,sp,-80
    80003c0a:	e486                	sd	ra,72(sp)
    80003c0c:	e0a2                	sd	s0,64(sp)
    80003c0e:	fc26                	sd	s1,56(sp)
    80003c10:	f84a                	sd	s2,48(sp)
    80003c12:	f44e                	sd	s3,40(sp)
    80003c14:	f052                	sd	s4,32(sp)
    80003c16:	ec56                	sd	s5,24(sp)
    80003c18:	e85a                	sd	s6,16(sp)
    80003c1a:	e45e                	sd	s7,8(sp)
    80003c1c:	e062                	sd	s8,0(sp)
    80003c1e:	0880                	addi	s0,sp,80
    80003c20:	8b2a                	mv	s6,a0
    80003c22:	0001fa97          	auipc	s5,0x1f
    80003c26:	a66a8a93          	addi	s5,s5,-1434 # 80022688 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c2a:	4981                	li	s3,0
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003c2c:	00004c17          	auipc	s8,0x4
    80003c30:	8ccc0c13          	addi	s8,s8,-1844 # 800074f8 <etext+0x4f8>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003c34:	0001fa17          	auipc	s4,0x1f
    80003c38:	a24a0a13          	addi	s4,s4,-1500 # 80022658 <log>
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003c3c:	40000b93          	li	s7,1024
    80003c40:	a025                	j	80003c68 <install_trans+0x6c>
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003c42:	000aa603          	lw	a2,0(s5)
    80003c46:	85ce                	mv	a1,s3
    80003c48:	8562                	mv	a0,s8
    80003c4a:	8c1fc0ef          	jal	8000050a <printk>
    80003c4e:	a839                	j	80003c6c <install_trans+0x70>
    brelse(lbuf);
    80003c50:	854a                	mv	a0,s2
    80003c52:	8f0ff0ef          	jal	80002d42 <brelse>
    brelse(dbuf);
    80003c56:	8526                	mv	a0,s1
    80003c58:	8eaff0ef          	jal	80002d42 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c5c:	2985                	addiw	s3,s3,1
    80003c5e:	0a91                	addi	s5,s5,4
    80003c60:	02ca2783          	lw	a5,44(s4)
    80003c64:	04f9d563          	bge	s3,a5,80003cae <install_trans+0xb2>
    if (recovering) {
    80003c68:	fc0b1de3          	bnez	s6,80003c42 <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003c6c:	018a2583          	lw	a1,24(s4)
    80003c70:	013585bb          	addw	a1,a1,s3
    80003c74:	2585                	addiw	a1,a1,1
    80003c76:	024a2503          	lw	a0,36(s4)
    80003c7a:	fc1fe0ef          	jal	80002c3a <bread>
    80003c7e:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80003c80:	000aa583          	lw	a1,0(s5)
    80003c84:	024a2503          	lw	a0,36(s4)
    80003c88:	fb3fe0ef          	jal	80002c3a <bread>
    80003c8c:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003c8e:	865e                	mv	a2,s7
    80003c90:	05890593          	addi	a1,s2,88
    80003c94:	05850513          	addi	a0,a0,88
    80003c98:	8b0fd0ef          	jal	80000d48 <memmove>
    bwrite(dbuf);                           // write dst to disk
    80003c9c:	8526                	mv	a0,s1
    80003c9e:	872ff0ef          	jal	80002d10 <bwrite>
    if (recovering == 0)
    80003ca2:	fa0b17e3          	bnez	s6,80003c50 <install_trans+0x54>
      bunpin(dbuf);
    80003ca6:	8526                	mv	a0,s1
    80003ca8:	952ff0ef          	jal	80002dfa <bunpin>
    80003cac:	b755                	j	80003c50 <install_trans+0x54>
}
    80003cae:	60a6                	ld	ra,72(sp)
    80003cb0:	6406                	ld	s0,64(sp)
    80003cb2:	74e2                	ld	s1,56(sp)
    80003cb4:	7942                	ld	s2,48(sp)
    80003cb6:	79a2                	ld	s3,40(sp)
    80003cb8:	7a02                	ld	s4,32(sp)
    80003cba:	6ae2                	ld	s5,24(sp)
    80003cbc:	6b42                	ld	s6,16(sp)
    80003cbe:	6ba2                	ld	s7,8(sp)
    80003cc0:	6c02                	ld	s8,0(sp)
    80003cc2:	6161                	addi	sp,sp,80
    80003cc4:	8082                	ret
    80003cc6:	8082                	ret

0000000080003cc8 <initlog>:
{
    80003cc8:	7179                	addi	sp,sp,-48
    80003cca:	f406                	sd	ra,40(sp)
    80003ccc:	f022                	sd	s0,32(sp)
    80003cce:	ec26                	sd	s1,24(sp)
    80003cd0:	e84a                	sd	s2,16(sp)
    80003cd2:	e44e                	sd	s3,8(sp)
    80003cd4:	1800                	addi	s0,sp,48
    80003cd6:	84aa                	mv	s1,a0
    80003cd8:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003cda:	0001f917          	auipc	s2,0x1f
    80003cde:	97e90913          	addi	s2,s2,-1666 # 80022658 <log>
    80003ce2:	00004597          	auipc	a1,0x4
    80003ce6:	83658593          	addi	a1,a1,-1994 # 80007518 <etext+0x518>
    80003cea:	854a                	mv	a0,s2
    80003cec:	ebdfc0ef          	jal	80000ba8 <initlock>
  log.start = sb->logstart;
    80003cf0:	0149a583          	lw	a1,20(s3)
    80003cf4:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    80003cf8:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    80003cfc:	8526                	mv	a0,s1
    80003cfe:	f3dfe0ef          	jal	80002c3a <bread>
  log.lh.n = lh->n;
    80003d02:	4d30                	lw	a2,88(a0)
    80003d04:	02c92623          	sw	a2,44(s2)
  for (i = 0; i < log.lh.n; i++) {
    80003d08:	00c05f63          	blez	a2,80003d26 <initlog+0x5e>
    80003d0c:	87aa                	mv	a5,a0
    80003d0e:	0001f717          	auipc	a4,0x1f
    80003d12:	97a70713          	addi	a4,a4,-1670 # 80022688 <log+0x30>
    80003d16:	060a                	slli	a2,a2,0x2
    80003d18:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003d1a:	4ff4                	lw	a3,92(a5)
    80003d1c:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003d1e:	0791                	addi	a5,a5,4
    80003d20:	0711                	addi	a4,a4,4
    80003d22:	fec79ce3          	bne	a5,a2,80003d1a <initlog+0x52>
  brelse(buf);
    80003d26:	81cff0ef          	jal	80002d42 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003d2a:	4505                	li	a0,1
    80003d2c:	ed1ff0ef          	jal	80003bfc <install_trans>
  log.lh.n = 0;
    80003d30:	0001f797          	auipc	a5,0x1f
    80003d34:	9407aa23          	sw	zero,-1708(a5) # 80022684 <log+0x2c>
  write_head(); // clear the log
    80003d38:	e67ff0ef          	jal	80003b9e <write_head>
}
    80003d3c:	70a2                	ld	ra,40(sp)
    80003d3e:	7402                	ld	s0,32(sp)
    80003d40:	64e2                	ld	s1,24(sp)
    80003d42:	6942                	ld	s2,16(sp)
    80003d44:	69a2                	ld	s3,8(sp)
    80003d46:	6145                	addi	sp,sp,48
    80003d48:	8082                	ret

0000000080003d4a <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003d4a:	1101                	addi	sp,sp,-32
    80003d4c:	ec06                	sd	ra,24(sp)
    80003d4e:	e822                	sd	s0,16(sp)
    80003d50:	e426                	sd	s1,8(sp)
    80003d52:	e04a                	sd	s2,0(sp)
    80003d54:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003d56:	0001f517          	auipc	a0,0x1f
    80003d5a:	90250513          	addi	a0,a0,-1790 # 80022658 <log>
    80003d5e:	ecbfc0ef          	jal	80000c28 <acquire>
  while (1) {
    if (log.committing) {
    80003d62:	0001f497          	auipc	s1,0x1f
    80003d66:	8f648493          	addi	s1,s1,-1802 # 80022658 <log>
      sleep_prepare(&log);
      release(&log.lock);
      sleep();
      acquire(&log.lock);
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003d6a:	4979                	li	s2,30
    80003d6c:	a821                	j	80003d84 <begin_op+0x3a>
      sleep_prepare(&log);
    80003d6e:	8526                	mv	a0,s1
    80003d70:	9e6fe0ef          	jal	80001f56 <sleep_prepare>
      release(&log.lock);
    80003d74:	8526                	mv	a0,s1
    80003d76:	f3bfc0ef          	jal	80000cb0 <release>
      sleep();
    80003d7a:	a18fe0ef          	jal	80001f92 <sleep>
      acquire(&log.lock);
    80003d7e:	8526                	mv	a0,s1
    80003d80:	ea9fc0ef          	jal	80000c28 <acquire>
    if (log.committing) {
    80003d84:	509c                	lw	a5,32(s1)
    80003d86:	f7e5                	bnez	a5,80003d6e <begin_op+0x24>
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003d88:	4cd8                	lw	a4,28(s1)
    80003d8a:	2705                	addiw	a4,a4,1
    80003d8c:	0027179b          	slliw	a5,a4,0x2
    80003d90:	9fb9                	addw	a5,a5,a4
    80003d92:	0017979b          	slliw	a5,a5,0x1
    80003d96:	54d4                	lw	a3,44(s1)
    80003d98:	9fb5                	addw	a5,a5,a3
    80003d9a:	00f95e63          	bge	s2,a5,80003db6 <begin_op+0x6c>
      // this op might exhaust log space; wait for commit.
      sleep_prepare(&log);
    80003d9e:	8526                	mv	a0,s1
    80003da0:	9b6fe0ef          	jal	80001f56 <sleep_prepare>
      release(&log.lock);
    80003da4:	8526                	mv	a0,s1
    80003da6:	f0bfc0ef          	jal	80000cb0 <release>
      sleep();
    80003daa:	9e8fe0ef          	jal	80001f92 <sleep>
      acquire(&log.lock);
    80003dae:	8526                	mv	a0,s1
    80003db0:	e79fc0ef          	jal	80000c28 <acquire>
    80003db4:	bfc1                	j	80003d84 <begin_op+0x3a>
    } else {
      log.outstanding += 1;
    80003db6:	0001f797          	auipc	a5,0x1f
    80003dba:	8ae7af23          	sw	a4,-1858(a5) # 80022674 <log+0x1c>
      release(&log.lock);
    80003dbe:	0001f517          	auipc	a0,0x1f
    80003dc2:	89a50513          	addi	a0,a0,-1894 # 80022658 <log>
    80003dc6:	eebfc0ef          	jal	80000cb0 <release>
      break;
    }
  }
}
    80003dca:	60e2                	ld	ra,24(sp)
    80003dcc:	6442                	ld	s0,16(sp)
    80003dce:	64a2                	ld	s1,8(sp)
    80003dd0:	6902                	ld	s2,0(sp)
    80003dd2:	6105                	addi	sp,sp,32
    80003dd4:	8082                	ret

0000000080003dd6 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003dd6:	7139                	addi	sp,sp,-64
    80003dd8:	fc06                	sd	ra,56(sp)
    80003dda:	f822                	sd	s0,48(sp)
    80003ddc:	f426                	sd	s1,40(sp)
    80003dde:	f04a                	sd	s2,32(sp)
    80003de0:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003de2:	0001f497          	auipc	s1,0x1f
    80003de6:	87648493          	addi	s1,s1,-1930 # 80022658 <log>
    80003dea:	8526                	mv	a0,s1
    80003dec:	e3dfc0ef          	jal	80000c28 <acquire>
  log.outstanding -= 1;
    80003df0:	4cdc                	lw	a5,28(s1)
    80003df2:	37fd                	addiw	a5,a5,-1
    80003df4:	893e                	mv	s2,a5
    80003df6:	ccdc                	sw	a5,28(s1)
  if (log.committing)
    80003df8:	509c                	lw	a5,32(s1)
    80003dfa:	e3b1                	bnez	a5,80003e3e <end_op+0x68>
    panic("log.committing");
  if (log.outstanding == 0) {
    80003dfc:	04091a63          	bnez	s2,80003e50 <end_op+0x7a>
    do_commit = 1;
    log.committing = 1;
    80003e00:	0001f497          	auipc	s1,0x1f
    80003e04:	85848493          	addi	s1,s1,-1960 # 80022658 <log>
    80003e08:	4785                	li	a5,1
    80003e0a:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003e0c:	8526                	mv	a0,s1
    80003e0e:	ea3fc0ef          	jal	80000cb0 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003e12:	54dc                	lw	a5,44(s1)
    80003e14:	06f04063          	bgtz	a5,80003e74 <end_op+0x9e>
    acquire(&log.lock);
    80003e18:	0001f497          	auipc	s1,0x1f
    80003e1c:	84048493          	addi	s1,s1,-1984 # 80022658 <log>
    80003e20:	8526                	mv	a0,s1
    80003e22:	e07fc0ef          	jal	80000c28 <acquire>
    log.committing = 0;
    80003e26:	0204a023          	sw	zero,32(s1)
    log.ncommit += 1;
    80003e2a:	549c                	lw	a5,40(s1)
    80003e2c:	2785                	addiw	a5,a5,1
    80003e2e:	d49c                	sw	a5,40(s1)
    wakeup(&log);
    80003e30:	8526                	mv	a0,s1
    80003e32:	990fe0ef          	jal	80001fc2 <wakeup>
    release(&log.lock);
    80003e36:	8526                	mv	a0,s1
    80003e38:	e79fc0ef          	jal	80000cb0 <release>
}
    80003e3c:	a035                	j	80003e68 <end_op+0x92>
    80003e3e:	ec4e                	sd	s3,24(sp)
    80003e40:	e852                	sd	s4,16(sp)
    80003e42:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003e44:	00003517          	auipc	a0,0x3
    80003e48:	6dc50513          	addi	a0,a0,1756 # 80007520 <etext+0x520>
    80003e4c:	9e9fc0ef          	jal	80000834 <panic>
    wakeup(&log);
    80003e50:	0001f517          	auipc	a0,0x1f
    80003e54:	80850513          	addi	a0,a0,-2040 # 80022658 <log>
    80003e58:	96afe0ef          	jal	80001fc2 <wakeup>
  release(&log.lock);
    80003e5c:	0001e517          	auipc	a0,0x1e
    80003e60:	7fc50513          	addi	a0,a0,2044 # 80022658 <log>
    80003e64:	e4dfc0ef          	jal	80000cb0 <release>
}
    80003e68:	70e2                	ld	ra,56(sp)
    80003e6a:	7442                	ld	s0,48(sp)
    80003e6c:	74a2                	ld	s1,40(sp)
    80003e6e:	7902                	ld	s2,32(sp)
    80003e70:	6121                	addi	sp,sp,64
    80003e72:	8082                	ret
    80003e74:	ec4e                	sd	s3,24(sp)
    80003e76:	e852                	sd	s4,16(sp)
    80003e78:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003e7a:	0001fa97          	auipc	s5,0x1f
    80003e7e:	80ea8a93          	addi	s5,s5,-2034 # 80022688 <log+0x30>
    struct buf *to = bread(log.dev, log.start + tail + 1); // log block
    80003e82:	0001ea17          	auipc	s4,0x1e
    80003e86:	7d6a0a13          	addi	s4,s4,2006 # 80022658 <log>
    80003e8a:	018a2583          	lw	a1,24(s4)
    80003e8e:	012585bb          	addw	a1,a1,s2
    80003e92:	2585                	addiw	a1,a1,1
    80003e94:	024a2503          	lw	a0,36(s4)
    80003e98:	da3fe0ef          	jal	80002c3a <bread>
    80003e9c:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003e9e:	000aa583          	lw	a1,0(s5)
    80003ea2:	024a2503          	lw	a0,36(s4)
    80003ea6:	d95fe0ef          	jal	80002c3a <bread>
    80003eaa:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003eac:	40000613          	li	a2,1024
    80003eb0:	05850593          	addi	a1,a0,88
    80003eb4:	05848513          	addi	a0,s1,88
    80003eb8:	e91fc0ef          	jal	80000d48 <memmove>
    bwrite(to); // write the log
    80003ebc:	8526                	mv	a0,s1
    80003ebe:	e53fe0ef          	jal	80002d10 <bwrite>
    brelse(from);
    80003ec2:	854e                	mv	a0,s3
    80003ec4:	e7ffe0ef          	jal	80002d42 <brelse>
    brelse(to);
    80003ec8:	8526                	mv	a0,s1
    80003eca:	e79fe0ef          	jal	80002d42 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003ece:	2905                	addiw	s2,s2,1
    80003ed0:	0a91                	addi	s5,s5,4
    80003ed2:	02ca2783          	lw	a5,44(s4)
    80003ed6:	faf94ae3          	blt	s2,a5,80003e8a <end_op+0xb4>
    write_log();      // Write modified blocks from cache to log
    write_head();     // Write header to disk -- the real commit
    80003eda:	cc5ff0ef          	jal	80003b9e <write_head>
    install_trans(0); // Now install writes to home locations
    80003ede:	4501                	li	a0,0
    80003ee0:	d1dff0ef          	jal	80003bfc <install_trans>
    log.lh.n = 0;
    80003ee4:	0001e797          	auipc	a5,0x1e
    80003ee8:	7a07a023          	sw	zero,1952(a5) # 80022684 <log+0x2c>
    write_head(); // Erase the transaction from the log
    80003eec:	cb3ff0ef          	jal	80003b9e <write_head>
    80003ef0:	69e2                	ld	s3,24(sp)
    80003ef2:	6a42                	ld	s4,16(sp)
    80003ef4:	6aa2                	ld	s5,8(sp)
    80003ef6:	b70d                	j	80003e18 <end_op+0x42>

0000000080003ef8 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003ef8:	1101                	addi	sp,sp,-32
    80003efa:	ec06                	sd	ra,24(sp)
    80003efc:	e822                	sd	s0,16(sp)
    80003efe:	e426                	sd	s1,8(sp)
    80003f00:	1000                	addi	s0,sp,32
    80003f02:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003f04:	0001e517          	auipc	a0,0x1e
    80003f08:	75450513          	addi	a0,a0,1876 # 80022658 <log>
    80003f0c:	d1dfc0ef          	jal	80000c28 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80003f10:	0001e617          	auipc	a2,0x1e
    80003f14:	77462603          	lw	a2,1908(a2) # 80022684 <log+0x2c>
    80003f18:	47f5                	li	a5,29
    80003f1a:	04c7cd63          	blt	a5,a2,80003f74 <log_write+0x7c>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003f1e:	0001e797          	auipc	a5,0x1e
    80003f22:	7567a783          	lw	a5,1878(a5) # 80022674 <log+0x1c>
    80003f26:	04f05d63          	blez	a5,80003f80 <log_write+0x88>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003f2a:	4781                	li	a5,0
    80003f2c:	06c05063          	blez	a2,80003f8c <log_write+0x94>
    if (log.lh.block[i] == b->blockno) // log absorption
    80003f30:	44cc                	lw	a1,12(s1)
    80003f32:	0001e717          	auipc	a4,0x1e
    80003f36:	75670713          	addi	a4,a4,1878 # 80022688 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003f3a:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno) // log absorption
    80003f3c:	4314                	lw	a3,0(a4)
    80003f3e:	04b68763          	beq	a3,a1,80003f8c <log_write+0x94>
  for (i = 0; i < log.lh.n; i++) {
    80003f42:	2785                	addiw	a5,a5,1
    80003f44:	0711                	addi	a4,a4,4
    80003f46:	fef61be3          	bne	a2,a5,80003f3c <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003f4a:	060a                	slli	a2,a2,0x2
    80003f4c:	02060613          	addi	a2,a2,32
    80003f50:	0001e797          	auipc	a5,0x1e
    80003f54:	70878793          	addi	a5,a5,1800 # 80022658 <log>
    80003f58:	97b2                	add	a5,a5,a2
    80003f5a:	44d8                	lw	a4,12(s1)
    80003f5c:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) { // Add new block to log?
    bpin(b);
    80003f5e:	8526                	mv	a0,s1
    80003f60:	e67fe0ef          	jal	80002dc6 <bpin>
    log.lh.n++;
    80003f64:	0001e717          	auipc	a4,0x1e
    80003f68:	6f470713          	addi	a4,a4,1780 # 80022658 <log>
    80003f6c:	575c                	lw	a5,44(a4)
    80003f6e:	2785                	addiw	a5,a5,1
    80003f70:	d75c                	sw	a5,44(a4)
    80003f72:	a815                	j	80003fa6 <log_write+0xae>
    panic("too big a transaction");
    80003f74:	00003517          	auipc	a0,0x3
    80003f78:	5bc50513          	addi	a0,a0,1468 # 80007530 <etext+0x530>
    80003f7c:	8b9fc0ef          	jal	80000834 <panic>
    panic("log_write outside of trans");
    80003f80:	00003517          	auipc	a0,0x3
    80003f84:	5c850513          	addi	a0,a0,1480 # 80007548 <etext+0x548>
    80003f88:	8adfc0ef          	jal	80000834 <panic>
  log.lh.block[i] = b->blockno;
    80003f8c:	00279693          	slli	a3,a5,0x2
    80003f90:	02068693          	addi	a3,a3,32
    80003f94:	0001e717          	auipc	a4,0x1e
    80003f98:	6c470713          	addi	a4,a4,1732 # 80022658 <log>
    80003f9c:	9736                	add	a4,a4,a3
    80003f9e:	44d4                	lw	a3,12(s1)
    80003fa0:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) { // Add new block to log?
    80003fa2:	faf60ee3          	beq	a2,a5,80003f5e <log_write+0x66>
  }
  release(&log.lock);
    80003fa6:	0001e517          	auipc	a0,0x1e
    80003faa:	6b250513          	addi	a0,a0,1714 # 80022658 <log>
    80003fae:	d03fc0ef          	jal	80000cb0 <release>
}
    80003fb2:	60e2                	ld	ra,24(sp)
    80003fb4:	6442                	ld	s0,16(sp)
    80003fb6:	64a2                	ld	s1,8(sp)
    80003fb8:	6105                	addi	sp,sp,32
    80003fba:	8082                	ret

0000000080003fbc <sys_sync>:

uint64
sys_sync(void)
{
    80003fbc:	1101                	addi	sp,sp,-32
    80003fbe:	ec06                	sd	ra,24(sp)
    80003fc0:	e822                	sd	s0,16(sp)
    80003fc2:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003fc4:	0001e517          	auipc	a0,0x1e
    80003fc8:	69450513          	addi	a0,a0,1684 # 80022658 <log>
    80003fcc:	c5dfc0ef          	jal	80000c28 <acquire>
  if (log.committing || log.outstanding > 0) {
    80003fd0:	0001e797          	auipc	a5,0x1e
    80003fd4:	6a87a783          	lw	a5,1704(a5) # 80022678 <log+0x20>
    80003fd8:	e799                	bnez	a5,80003fe6 <sys_sync+0x2a>
    80003fda:	0001e797          	auipc	a5,0x1e
    80003fde:	69a7a783          	lw	a5,1690(a5) # 80022674 <log+0x1c>
    80003fe2:	02f05c63          	blez	a5,8000401a <sys_sync+0x5e>
    80003fe6:	e426                	sd	s1,8(sp)
    80003fe8:	e04a                	sd	s2,0(sp)
    int n = log.ncommit + 1;
    80003fea:	0001e917          	auipc	s2,0x1e
    80003fee:	69692903          	lw	s2,1686(s2) # 80022680 <log+0x28>
    while (log.ncommit < n) {
      sleep_prepare(&log);
    80003ff2:	0001e497          	auipc	s1,0x1e
    80003ff6:	66648493          	addi	s1,s1,1638 # 80022658 <log>
    80003ffa:	8526                	mv	a0,s1
    80003ffc:	f5bfd0ef          	jal	80001f56 <sleep_prepare>
      release(&log.lock);
    80004000:	8526                	mv	a0,s1
    80004002:	caffc0ef          	jal	80000cb0 <release>
      sleep();
    80004006:	f8dfd0ef          	jal	80001f92 <sleep>
      acquire(&log.lock);
    8000400a:	8526                	mv	a0,s1
    8000400c:	c1dfc0ef          	jal	80000c28 <acquire>
    while (log.ncommit < n) {
    80004010:	549c                	lw	a5,40(s1)
    80004012:	fef954e3          	bge	s2,a5,80003ffa <sys_sync+0x3e>
    80004016:	64a2                	ld	s1,8(sp)
    80004018:	6902                	ld	s2,0(sp)
    }
  }
  release(&log.lock);
    8000401a:	0001e517          	auipc	a0,0x1e
    8000401e:	63e50513          	addi	a0,a0,1598 # 80022658 <log>
    80004022:	c8ffc0ef          	jal	80000cb0 <release>
  return 0;
}
    80004026:	4501                	li	a0,0
    80004028:	60e2                	ld	ra,24(sp)
    8000402a:	6442                	ld	s0,16(sp)
    8000402c:	6105                	addi	sp,sp,32
    8000402e:	8082                	ret

0000000080004030 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80004030:	1101                	addi	sp,sp,-32
    80004032:	ec06                	sd	ra,24(sp)
    80004034:	e822                	sd	s0,16(sp)
    80004036:	e426                	sd	s1,8(sp)
    80004038:	e04a                	sd	s2,0(sp)
    8000403a:	1000                	addi	s0,sp,32
    8000403c:	84aa                	mv	s1,a0
    8000403e:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80004040:	00003597          	auipc	a1,0x3
    80004044:	52858593          	addi	a1,a1,1320 # 80007568 <etext+0x568>
    80004048:	0521                	addi	a0,a0,8
    8000404a:	b5ffc0ef          	jal	80000ba8 <initlock>
  lk->name = name;
    8000404e:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80004052:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004056:	0204a423          	sw	zero,40(s1)
}
    8000405a:	60e2                	ld	ra,24(sp)
    8000405c:	6442                	ld	s0,16(sp)
    8000405e:	64a2                	ld	s1,8(sp)
    80004060:	6902                	ld	s2,0(sp)
    80004062:	6105                	addi	sp,sp,32
    80004064:	8082                	ret

0000000080004066 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80004066:	1101                	addi	sp,sp,-32
    80004068:	ec06                	sd	ra,24(sp)
    8000406a:	e822                	sd	s0,16(sp)
    8000406c:	e426                	sd	s1,8(sp)
    8000406e:	e04a                	sd	s2,0(sp)
    80004070:	1000                	addi	s0,sp,32
    80004072:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004074:	00850913          	addi	s2,a0,8
    80004078:	854a                	mv	a0,s2
    8000407a:	baffc0ef          	jal	80000c28 <acquire>
  while (lk->locked) {
    8000407e:	409c                	lw	a5,0(s1)
    80004080:	cf91                	beqz	a5,8000409c <acquiresleep+0x36>
    sleep_prepare(lk);
    80004082:	8526                	mv	a0,s1
    80004084:	ed3fd0ef          	jal	80001f56 <sleep_prepare>
    release(&lk->lk);
    80004088:	854a                	mv	a0,s2
    8000408a:	c27fc0ef          	jal	80000cb0 <release>
    sleep();
    8000408e:	f05fd0ef          	jal	80001f92 <sleep>
    acquire(&lk->lk);
    80004092:	854a                	mv	a0,s2
    80004094:	b95fc0ef          	jal	80000c28 <acquire>
  while (lk->locked) {
    80004098:	409c                	lw	a5,0(s1)
    8000409a:	f7e5                	bnez	a5,80004082 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    8000409c:	4785                	li	a5,1
    8000409e:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800040a0:	8adfd0ef          	jal	8000194c <myproc>
    800040a4:	591c                	lw	a5,48(a0)
    800040a6:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800040a8:	854a                	mv	a0,s2
    800040aa:	c07fc0ef          	jal	80000cb0 <release>
}
    800040ae:	60e2                	ld	ra,24(sp)
    800040b0:	6442                	ld	s0,16(sp)
    800040b2:	64a2                	ld	s1,8(sp)
    800040b4:	6902                	ld	s2,0(sp)
    800040b6:	6105                	addi	sp,sp,32
    800040b8:	8082                	ret

00000000800040ba <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800040ba:	1101                	addi	sp,sp,-32
    800040bc:	ec06                	sd	ra,24(sp)
    800040be:	e822                	sd	s0,16(sp)
    800040c0:	e426                	sd	s1,8(sp)
    800040c2:	e04a                	sd	s2,0(sp)
    800040c4:	1000                	addi	s0,sp,32
    800040c6:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800040c8:	00850913          	addi	s2,a0,8
    800040cc:	854a                	mv	a0,s2
    800040ce:	b5bfc0ef          	jal	80000c28 <acquire>
  lk->locked = 0;
    800040d2:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800040d6:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    800040da:	8526                	mv	a0,s1
    800040dc:	ee7fd0ef          	jal	80001fc2 <wakeup>
  release(&lk->lk);
    800040e0:	854a                	mv	a0,s2
    800040e2:	bcffc0ef          	jal	80000cb0 <release>
}
    800040e6:	60e2                	ld	ra,24(sp)
    800040e8:	6442                	ld	s0,16(sp)
    800040ea:	64a2                	ld	s1,8(sp)
    800040ec:	6902                	ld	s2,0(sp)
    800040ee:	6105                	addi	sp,sp,32
    800040f0:	8082                	ret

00000000800040f2 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800040f2:	7179                	addi	sp,sp,-48
    800040f4:	f406                	sd	ra,40(sp)
    800040f6:	f022                	sd	s0,32(sp)
    800040f8:	ec26                	sd	s1,24(sp)
    800040fa:	e84a                	sd	s2,16(sp)
    800040fc:	1800                	addi	s0,sp,48
    800040fe:	84aa                	mv	s1,a0
  int r;

  acquire(&lk->lk);
    80004100:	00850913          	addi	s2,a0,8
    80004104:	854a                	mv	a0,s2
    80004106:	b23fc0ef          	jal	80000c28 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    8000410a:	409c                	lw	a5,0(s1)
    8000410c:	ef81                	bnez	a5,80004124 <holdingsleep+0x32>
    8000410e:	4481                	li	s1,0
  release(&lk->lk);
    80004110:	854a                	mv	a0,s2
    80004112:	b9ffc0ef          	jal	80000cb0 <release>
  return r;
}
    80004116:	8526                	mv	a0,s1
    80004118:	70a2                	ld	ra,40(sp)
    8000411a:	7402                	ld	s0,32(sp)
    8000411c:	64e2                	ld	s1,24(sp)
    8000411e:	6942                	ld	s2,16(sp)
    80004120:	6145                	addi	sp,sp,48
    80004122:	8082                	ret
    80004124:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80004126:	0284a983          	lw	s3,40(s1)
    8000412a:	823fd0ef          	jal	8000194c <myproc>
    8000412e:	5904                	lw	s1,48(a0)
    80004130:	413484b3          	sub	s1,s1,s3
    80004134:	0014b493          	seqz	s1,s1
    80004138:	69a2                	ld	s3,8(sp)
    8000413a:	bfd9                	j	80004110 <holdingsleep+0x1e>

000000008000413c <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    8000413c:	1141                	addi	sp,sp,-16
    8000413e:	e406                	sd	ra,8(sp)
    80004140:	e022                	sd	s0,0(sp)
    80004142:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80004144:	00003597          	auipc	a1,0x3
    80004148:	43458593          	addi	a1,a1,1076 # 80007578 <etext+0x578>
    8000414c:	0001e517          	auipc	a0,0x1e
    80004150:	65450513          	addi	a0,a0,1620 # 800227a0 <ftable>
    80004154:	a55fc0ef          	jal	80000ba8 <initlock>
}
    80004158:	60a2                	ld	ra,8(sp)
    8000415a:	6402                	ld	s0,0(sp)
    8000415c:	0141                	addi	sp,sp,16
    8000415e:	8082                	ret

0000000080004160 <filealloc>:

// Allocate a file structure.
struct file *
filealloc(void)
{
    80004160:	1101                	addi	sp,sp,-32
    80004162:	ec06                	sd	ra,24(sp)
    80004164:	e822                	sd	s0,16(sp)
    80004166:	e426                	sd	s1,8(sp)
    80004168:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    8000416a:	0001e517          	auipc	a0,0x1e
    8000416e:	63650513          	addi	a0,a0,1590 # 800227a0 <ftable>
    80004172:	ab7fc0ef          	jal	80000c28 <acquire>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    80004176:	0001e497          	auipc	s1,0x1e
    8000417a:	64248493          	addi	s1,s1,1602 # 800227b8 <ftable+0x18>
    8000417e:	0001f717          	auipc	a4,0x1f
    80004182:	5da70713          	addi	a4,a4,1498 # 80023758 <disk>
    if (f->ref == 0) {
    80004186:	40dc                	lw	a5,4(s1)
    80004188:	cf89                	beqz	a5,800041a2 <filealloc+0x42>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    8000418a:	02848493          	addi	s1,s1,40
    8000418e:	fee49ce3          	bne	s1,a4,80004186 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80004192:	0001e517          	auipc	a0,0x1e
    80004196:	60e50513          	addi	a0,a0,1550 # 800227a0 <ftable>
    8000419a:	b17fc0ef          	jal	80000cb0 <release>
  return 0;
    8000419e:	4481                	li	s1,0
    800041a0:	a809                	j	800041b2 <filealloc+0x52>
      f->ref = 1;
    800041a2:	4785                	li	a5,1
    800041a4:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800041a6:	0001e517          	auipc	a0,0x1e
    800041aa:	5fa50513          	addi	a0,a0,1530 # 800227a0 <ftable>
    800041ae:	b03fc0ef          	jal	80000cb0 <release>
}
    800041b2:	8526                	mv	a0,s1
    800041b4:	60e2                	ld	ra,24(sp)
    800041b6:	6442                	ld	s0,16(sp)
    800041b8:	64a2                	ld	s1,8(sp)
    800041ba:	6105                	addi	sp,sp,32
    800041bc:	8082                	ret

00000000800041be <filedup>:

// Increment ref count for file f.
struct file *
filedup(struct file *f)
{
    800041be:	1101                	addi	sp,sp,-32
    800041c0:	ec06                	sd	ra,24(sp)
    800041c2:	e822                	sd	s0,16(sp)
    800041c4:	e426                	sd	s1,8(sp)
    800041c6:	1000                	addi	s0,sp,32
    800041c8:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800041ca:	0001e517          	auipc	a0,0x1e
    800041ce:	5d650513          	addi	a0,a0,1494 # 800227a0 <ftable>
    800041d2:	a57fc0ef          	jal	80000c28 <acquire>
  if (f->ref < 1)
    800041d6:	40dc                	lw	a5,4(s1)
    800041d8:	02f05063          	blez	a5,800041f8 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    800041dc:	2785                	addiw	a5,a5,1
    800041de:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    800041e0:	0001e517          	auipc	a0,0x1e
    800041e4:	5c050513          	addi	a0,a0,1472 # 800227a0 <ftable>
    800041e8:	ac9fc0ef          	jal	80000cb0 <release>
  return f;
}
    800041ec:	8526                	mv	a0,s1
    800041ee:	60e2                	ld	ra,24(sp)
    800041f0:	6442                	ld	s0,16(sp)
    800041f2:	64a2                	ld	s1,8(sp)
    800041f4:	6105                	addi	sp,sp,32
    800041f6:	8082                	ret
    panic("filedup");
    800041f8:	00003517          	auipc	a0,0x3
    800041fc:	38850513          	addi	a0,a0,904 # 80007580 <etext+0x580>
    80004200:	e34fc0ef          	jal	80000834 <panic>

0000000080004204 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004204:	7139                	addi	sp,sp,-64
    80004206:	fc06                	sd	ra,56(sp)
    80004208:	f822                	sd	s0,48(sp)
    8000420a:	f426                	sd	s1,40(sp)
    8000420c:	0080                	addi	s0,sp,64
    8000420e:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004210:	0001e517          	auipc	a0,0x1e
    80004214:	59050513          	addi	a0,a0,1424 # 800227a0 <ftable>
    80004218:	a11fc0ef          	jal	80000c28 <acquire>
  if (f->ref < 1)
    8000421c:	40dc                	lw	a5,4(s1)
    8000421e:	04f05a63          	blez	a5,80004272 <fileclose+0x6e>
    panic("fileclose");
  if (--f->ref > 0) {
    80004222:	37fd                	addiw	a5,a5,-1
    80004224:	c0dc                	sw	a5,4(s1)
    80004226:	06f04063          	bgtz	a5,80004286 <fileclose+0x82>
    8000422a:	f04a                	sd	s2,32(sp)
    8000422c:	ec4e                	sd	s3,24(sp)
    8000422e:	e852                	sd	s4,16(sp)
    80004230:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80004232:	0004a903          	lw	s2,0(s1)
    80004236:	0094c783          	lbu	a5,9(s1)
    8000423a:	89be                	mv	s3,a5
    8000423c:	689c                	ld	a5,16(s1)
    8000423e:	8a3e                	mv	s4,a5
    80004240:	6c9c                	ld	a5,24(s1)
    80004242:	8abe                	mv	s5,a5
  f->ref = 0;
    80004244:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004248:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    8000424c:	0001e517          	auipc	a0,0x1e
    80004250:	55450513          	addi	a0,a0,1364 # 800227a0 <ftable>
    80004254:	a5dfc0ef          	jal	80000cb0 <release>

  if (ff.type == FD_PIPE) {
    80004258:	4785                	li	a5,1
    8000425a:	04f90163          	beq	s2,a5,8000429c <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if (ff.type == FD_INODE || ff.type == FD_DEVICE) {
    8000425e:	ffe9079b          	addiw	a5,s2,-2
    80004262:	4705                	li	a4,1
    80004264:	04f77563          	bgeu	a4,a5,800042ae <fileclose+0xaa>
    80004268:	7902                	ld	s2,32(sp)
    8000426a:	69e2                	ld	s3,24(sp)
    8000426c:	6a42                	ld	s4,16(sp)
    8000426e:	6aa2                	ld	s5,8(sp)
    80004270:	a00d                	j	80004292 <fileclose+0x8e>
    80004272:	f04a                	sd	s2,32(sp)
    80004274:	ec4e                	sd	s3,24(sp)
    80004276:	e852                	sd	s4,16(sp)
    80004278:	e456                	sd	s5,8(sp)
    panic("fileclose");
    8000427a:	00003517          	auipc	a0,0x3
    8000427e:	30e50513          	addi	a0,a0,782 # 80007588 <etext+0x588>
    80004282:	db2fc0ef          	jal	80000834 <panic>
    release(&ftable.lock);
    80004286:	0001e517          	auipc	a0,0x1e
    8000428a:	51a50513          	addi	a0,a0,1306 # 800227a0 <ftable>
    8000428e:	a23fc0ef          	jal	80000cb0 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80004292:	70e2                	ld	ra,56(sp)
    80004294:	7442                	ld	s0,48(sp)
    80004296:	74a2                	ld	s1,40(sp)
    80004298:	6121                	addi	sp,sp,64
    8000429a:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    8000429c:	85ce                	mv	a1,s3
    8000429e:	8552                	mv	a0,s4
    800042a0:	36a000ef          	jal	8000460a <pipeclose>
    800042a4:	7902                	ld	s2,32(sp)
    800042a6:	69e2                	ld	s3,24(sp)
    800042a8:	6a42                	ld	s4,16(sp)
    800042aa:	6aa2                	ld	s5,8(sp)
    800042ac:	b7dd                	j	80004292 <fileclose+0x8e>
    begin_op();
    800042ae:	a9dff0ef          	jal	80003d4a <begin_op>
    iput(ff.ip);
    800042b2:	8556                	mv	a0,s5
    800042b4:	9a0ff0ef          	jal	80003454 <iput>
    end_op();
    800042b8:	b1fff0ef          	jal	80003dd6 <end_op>
    800042bc:	7902                	ld	s2,32(sp)
    800042be:	69e2                	ld	s3,24(sp)
    800042c0:	6a42                	ld	s4,16(sp)
    800042c2:	6aa2                	ld	s5,8(sp)
    800042c4:	b7f9                	j	80004292 <fileclose+0x8e>

00000000800042c6 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800042c6:	715d                	addi	sp,sp,-80
    800042c8:	e486                	sd	ra,72(sp)
    800042ca:	e0a2                	sd	s0,64(sp)
    800042cc:	fc26                	sd	s1,56(sp)
    800042ce:	f052                	sd	s4,32(sp)
    800042d0:	0880                	addi	s0,sp,80
    800042d2:	84aa                	mv	s1,a0
    800042d4:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    800042d6:	e76fd0ef          	jal	8000194c <myproc>
  struct stat st;

  if (f->type == FD_INODE || f->type == FD_DEVICE) {
    800042da:	409c                	lw	a5,0(s1)
    800042dc:	37f9                	addiw	a5,a5,-2
    800042de:	4705                	li	a4,1
    800042e0:	04f76963          	bltu	a4,a5,80004332 <filestat+0x6c>
    800042e4:	f84a                	sd	s2,48(sp)
    800042e6:	f44e                	sd	s3,40(sp)
    800042e8:	892a                	mv	s2,a0
    memset(&st, 0, sizeof(st));
    800042ea:	fb840993          	addi	s3,s0,-72
    800042ee:	4661                	li	a2,24
    800042f0:	4581                	li	a1,0
    800042f2:	854e                	mv	a0,s3
    800042f4:	9f5fc0ef          	jal	80000ce8 <memset>
    ilock(f->ip);
    800042f8:	6c88                	ld	a0,24(s1)
    800042fa:	fd9fe0ef          	jal	800032d2 <ilock>
    stati(f->ip, &st);
    800042fe:	85ce                	mv	a1,s3
    80004300:	6c88                	ld	a0,24(s1)
    80004302:	b7cff0ef          	jal	8000367e <stati>
    iunlock(f->ip);
    80004306:	6c88                	ld	a0,24(s1)
    80004308:	878ff0ef          	jal	80003380 <iunlock>
    if (copyout(p->pagetable, p->sz, addr, (char *)&st, sizeof(st)) < 0)
    8000430c:	4761                	li	a4,24
    8000430e:	86ce                	mv	a3,s3
    80004310:	8652                	mv	a2,s4
    80004312:	04893583          	ld	a1,72(s2)
    80004316:	05093503          	ld	a0,80(s2)
    8000431a:	a6cfd0ef          	jal	80001586 <copyout>
    8000431e:	41f5551b          	sraiw	a0,a0,0x1f
    80004322:	7942                	ld	s2,48(sp)
    80004324:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80004326:	60a6                	ld	ra,72(sp)
    80004328:	6406                	ld	s0,64(sp)
    8000432a:	74e2                	ld	s1,56(sp)
    8000432c:	7a02                	ld	s4,32(sp)
    8000432e:	6161                	addi	sp,sp,80
    80004330:	8082                	ret
  return -1;
    80004332:	557d                	li	a0,-1
    80004334:	bfcd                	j	80004326 <filestat+0x60>

0000000080004336 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004336:	7179                	addi	sp,sp,-48
    80004338:	f406                	sd	ra,40(sp)
    8000433a:	f022                	sd	s0,32(sp)
    8000433c:	e84a                	sd	s2,16(sp)
    8000433e:	1800                	addi	s0,sp,48
  int r = 0;

  if (f->readable == 0 || n < 0)
    80004340:	00854783          	lbu	a5,8(a0)
    80004344:	c3dd                	beqz	a5,800043ea <fileread+0xb4>
    80004346:	ec26                	sd	s1,24(sp)
    80004348:	e44e                	sd	s3,8(sp)
    8000434a:	84aa                	mv	s1,a0
    8000434c:	892e                	mv	s2,a1
    8000434e:	89b2                	mv	s3,a2
    80004350:	01f6579b          	srliw	a5,a2,0x1f
    80004354:	ebc9                	bnez	a5,800043e6 <fileread+0xb0>
    return -1;

  if (f->type == FD_PIPE) {
    80004356:	411c                	lw	a5,0(a0)
    80004358:	4705                	li	a4,1
    8000435a:	04e78363          	beq	a5,a4,800043a0 <fileread+0x6a>
    r = piperead(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    8000435e:	470d                	li	a4,3
    80004360:	04e78763          	beq	a5,a4,800043ae <fileread+0x78>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if (f->type == FD_INODE) {
    80004364:	4709                	li	a4,2
    80004366:	06e79a63          	bne	a5,a4,800043da <fileread+0xa4>
    ilock(f->ip);
    8000436a:	6d08                	ld	a0,24(a0)
    8000436c:	f67fe0ef          	jal	800032d2 <ilock>
    if ((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004370:	874e                	mv	a4,s3
    80004372:	5094                	lw	a3,32(s1)
    80004374:	864a                	mv	a2,s2
    80004376:	4585                	li	a1,1
    80004378:	6c88                	ld	a0,24(s1)
    8000437a:	b32ff0ef          	jal	800036ac <readi>
    8000437e:	892a                	mv	s2,a0
    80004380:	00a05563          	blez	a0,8000438a <fileread+0x54>
      f->off += r;
    80004384:	509c                	lw	a5,32(s1)
    80004386:	9fa9                	addw	a5,a5,a0
    80004388:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    8000438a:	6c88                	ld	a0,24(s1)
    8000438c:	ff5fe0ef          	jal	80003380 <iunlock>
    80004390:	64e2                	ld	s1,24(sp)
    80004392:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004394:	854a                	mv	a0,s2
    80004396:	70a2                	ld	ra,40(sp)
    80004398:	7402                	ld	s0,32(sp)
    8000439a:	6942                	ld	s2,16(sp)
    8000439c:	6145                	addi	sp,sp,48
    8000439e:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800043a0:	6908                	ld	a0,16(a0)
    800043a2:	3e2000ef          	jal	80004784 <piperead>
    800043a6:	892a                	mv	s2,a0
    800043a8:	64e2                	ld	s1,24(sp)
    800043aa:	69a2                	ld	s3,8(sp)
    800043ac:	b7e5                	j	80004394 <fileread+0x5e>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800043ae:	02451783          	lh	a5,36(a0)
    800043b2:	03079693          	slli	a3,a5,0x30
    800043b6:	92c1                	srli	a3,a3,0x30
    800043b8:	4725                	li	a4,9
    800043ba:	02d76b63          	bltu	a4,a3,800043f0 <fileread+0xba>
    800043be:	0792                	slli	a5,a5,0x4
    800043c0:	0001e717          	auipc	a4,0x1e
    800043c4:	34070713          	addi	a4,a4,832 # 80022700 <devsw>
    800043c8:	97ba                	add	a5,a5,a4
    800043ca:	639c                	ld	a5,0(a5)
    800043cc:	c79d                	beqz	a5,800043fa <fileread+0xc4>
    r = devsw[f->major].read(1, addr, n);
    800043ce:	4505                	li	a0,1
    800043d0:	9782                	jalr	a5
    800043d2:	892a                	mv	s2,a0
    800043d4:	64e2                	ld	s1,24(sp)
    800043d6:	69a2                	ld	s3,8(sp)
    800043d8:	bf75                	j	80004394 <fileread+0x5e>
    panic("fileread");
    800043da:	00003517          	auipc	a0,0x3
    800043de:	1be50513          	addi	a0,a0,446 # 80007598 <etext+0x598>
    800043e2:	c52fc0ef          	jal	80000834 <panic>
    800043e6:	64e2                	ld	s1,24(sp)
    800043e8:	69a2                	ld	s3,8(sp)
    return -1;
    800043ea:	57fd                	li	a5,-1
    800043ec:	893e                	mv	s2,a5
    800043ee:	b75d                	j	80004394 <fileread+0x5e>
      return -1;
    800043f0:	57fd                	li	a5,-1
    800043f2:	893e                	mv	s2,a5
    800043f4:	64e2                	ld	s1,24(sp)
    800043f6:	69a2                	ld	s3,8(sp)
    800043f8:	bf71                	j	80004394 <fileread+0x5e>
    800043fa:	57fd                	li	a5,-1
    800043fc:	893e                	mv	s2,a5
    800043fe:	64e2                	ld	s1,24(sp)
    80004400:	69a2                	ld	s3,8(sp)
    80004402:	bf49                	j	80004394 <fileread+0x5e>

0000000080004404 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if (f->writable == 0 || n < 0)
    80004404:	00954783          	lbu	a5,9(a0)
    80004408:	12078b63          	beqz	a5,8000453e <filewrite+0x13a>
{
    8000440c:	711d                	addi	sp,sp,-96
    8000440e:	ec86                	sd	ra,88(sp)
    80004410:	e8a2                	sd	s0,80(sp)
    80004412:	e0ca                	sd	s2,64(sp)
    80004414:	f456                	sd	s5,40(sp)
    80004416:	f05a                	sd	s6,32(sp)
    80004418:	1080                	addi	s0,sp,96
    8000441a:	892a                	mv	s2,a0
    8000441c:	8b2e                	mv	s6,a1
    8000441e:	8ab2                	mv	s5,a2
  if (f->writable == 0 || n < 0)
    80004420:	01f6579b          	srliw	a5,a2,0x1f
    80004424:	0e079d63          	bnez	a5,8000451e <filewrite+0x11a>
    return -1;

  if (f->type == FD_PIPE) {
    80004428:	411c                	lw	a5,0(a0)
    8000442a:	4705                	li	a4,1
    8000442c:	02e78a63          	beq	a5,a4,80004460 <filewrite+0x5c>
    ret = pipewrite(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    80004430:	470d                	li	a4,3
    80004432:	02e78b63          	beq	a5,a4,80004468 <filewrite+0x64>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if (f->type == FD_INODE) {
    80004436:	4709                	li	a4,2
    80004438:	0ce79763          	bne	a5,a4,80004506 <filewrite+0x102>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
    int i = 0;
    while (i < n) {
    8000443c:	0ec05763          	blez	a2,8000452a <filewrite+0x126>
    80004440:	e4a6                	sd	s1,72(sp)
    80004442:	fc4e                	sd	s3,56(sp)
    80004444:	f852                	sd	s4,48(sp)
    80004446:	ec5e                	sd	s7,24(sp)
    80004448:	e862                	sd	s8,16(sp)
    8000444a:	e466                	sd	s9,8(sp)
    int i = 0;
    8000444c:	4a01                	li	s4,0
      int n1 = n - i;
      if (n1 > max)
    8000444e:	6b85                	lui	s7,0x1
    80004450:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004454:	6785                	lui	a5,0x1
    80004456:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    8000445a:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000445c:	4c05                	li	s8,1
    8000445e:	a8ad                	j	800044d8 <filewrite+0xd4>
    ret = pipewrite(f->pipe, addr, n);
    80004460:	6908                	ld	a0,16(a0)
    80004462:	206000ef          	jal	80004668 <pipewrite>
    80004466:	a849                	j	800044f8 <filewrite+0xf4>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004468:	02451783          	lh	a5,36(a0)
    8000446c:	03079693          	slli	a3,a5,0x30
    80004470:	92c1                	srli	a3,a3,0x30
    80004472:	4725                	li	a4,9
    80004474:	0ad76763          	bltu	a4,a3,80004522 <filewrite+0x11e>
    80004478:	0792                	slli	a5,a5,0x4
    8000447a:	0001e717          	auipc	a4,0x1e
    8000447e:	28670713          	addi	a4,a4,646 # 80022700 <devsw>
    80004482:	97ba                	add	a5,a5,a4
    80004484:	679c                	ld	a5,8(a5)
    80004486:	c3c5                	beqz	a5,80004526 <filewrite+0x122>
    ret = devsw[f->major].write(1, addr, n);
    80004488:	4505                	li	a0,1
    8000448a:	9782                	jalr	a5
    8000448c:	a0b5                	j	800044f8 <filewrite+0xf4>
      if (n1 > max)
    8000448e:	2981                	sext.w	s3,s3
      begin_op();
    80004490:	8bbff0ef          	jal	80003d4a <begin_op>
      ilock(f->ip);
    80004494:	01893503          	ld	a0,24(s2)
    80004498:	e3bfe0ef          	jal	800032d2 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000449c:	874e                	mv	a4,s3
    8000449e:	02092683          	lw	a3,32(s2)
    800044a2:	016a0633          	add	a2,s4,s6
    800044a6:	85e2                	mv	a1,s8
    800044a8:	01893503          	ld	a0,24(s2)
    800044ac:	af2ff0ef          	jal	8000379e <writei>
    800044b0:	84aa                	mv	s1,a0
    800044b2:	00a05763          	blez	a0,800044c0 <filewrite+0xbc>
        f->off += r;
    800044b6:	02092783          	lw	a5,32(s2)
    800044ba:	9fa9                	addw	a5,a5,a0
    800044bc:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800044c0:	01893503          	ld	a0,24(s2)
    800044c4:	ebdfe0ef          	jal	80003380 <iunlock>
      end_op();
    800044c8:	90fff0ef          	jal	80003dd6 <end_op>

      if (r != n1) {
    800044cc:	00999d63          	bne	s3,s1,800044e6 <filewrite+0xe2>
        // error from writei
        break;
      }
      i += r;
    800044d0:	01448a3b          	addw	s4,s1,s4
    while (i < n) {
    800044d4:	015a5963          	bge	s4,s5,800044e6 <filewrite+0xe2>
      int n1 = n - i;
    800044d8:	414a87bb          	subw	a5,s5,s4
    800044dc:	89be                	mv	s3,a5
      if (n1 > max)
    800044de:	fafbd8e3          	bge	s7,a5,8000448e <filewrite+0x8a>
    800044e2:	89e6                	mv	s3,s9
    800044e4:	b76d                	j	8000448e <filewrite+0x8a>
    }
    ret = (i == n ? n : -1);
    800044e6:	054a9463          	bne	s5,s4,8000452e <filewrite+0x12a>
    800044ea:	8556                	mv	a0,s5
    800044ec:	64a6                	ld	s1,72(sp)
    800044ee:	79e2                	ld	s3,56(sp)
    800044f0:	7a42                	ld	s4,48(sp)
    800044f2:	6be2                	ld	s7,24(sp)
    800044f4:	6c42                	ld	s8,16(sp)
    800044f6:	6ca2                	ld	s9,8(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    800044f8:	60e6                	ld	ra,88(sp)
    800044fa:	6446                	ld	s0,80(sp)
    800044fc:	6906                	ld	s2,64(sp)
    800044fe:	7aa2                	ld	s5,40(sp)
    80004500:	7b02                	ld	s6,32(sp)
    80004502:	6125                	addi	sp,sp,96
    80004504:	8082                	ret
    80004506:	e4a6                	sd	s1,72(sp)
    80004508:	fc4e                	sd	s3,56(sp)
    8000450a:	f852                	sd	s4,48(sp)
    8000450c:	ec5e                	sd	s7,24(sp)
    8000450e:	e862                	sd	s8,16(sp)
    80004510:	e466                	sd	s9,8(sp)
    panic("filewrite");
    80004512:	00003517          	auipc	a0,0x3
    80004516:	09650513          	addi	a0,a0,150 # 800075a8 <etext+0x5a8>
    8000451a:	b1afc0ef          	jal	80000834 <panic>
    return -1;
    8000451e:	557d                	li	a0,-1
    80004520:	bfe1                	j	800044f8 <filewrite+0xf4>
      return -1;
    80004522:	557d                	li	a0,-1
    80004524:	bfd1                	j	800044f8 <filewrite+0xf4>
    80004526:	557d                	li	a0,-1
    80004528:	bfc1                	j	800044f8 <filewrite+0xf4>
    ret = (i == n ? n : -1);
    8000452a:	8532                	mv	a0,a2
    8000452c:	b7f1                	j	800044f8 <filewrite+0xf4>
    8000452e:	557d                	li	a0,-1
    80004530:	64a6                	ld	s1,72(sp)
    80004532:	79e2                	ld	s3,56(sp)
    80004534:	7a42                	ld	s4,48(sp)
    80004536:	6be2                	ld	s7,24(sp)
    80004538:	6c42                	ld	s8,16(sp)
    8000453a:	6ca2                	ld	s9,8(sp)
    8000453c:	bf75                	j	800044f8 <filewrite+0xf4>
    return -1;
    8000453e:	557d                	li	a0,-1
}
    80004540:	8082                	ret

0000000080004542 <pipealloc>:
  int writeopen; // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004542:	7179                	addi	sp,sp,-48
    80004544:	f406                	sd	ra,40(sp)
    80004546:	f022                	sd	s0,32(sp)
    80004548:	ec26                	sd	s1,24(sp)
    8000454a:	e052                	sd	s4,0(sp)
    8000454c:	1800                	addi	s0,sp,48
    8000454e:	84aa                	mv	s1,a0
    80004550:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004552:	0005b023          	sd	zero,0(a1)
    80004556:	00053023          	sd	zero,0(a0)
  if ((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    8000455a:	c07ff0ef          	jal	80004160 <filealloc>
    8000455e:	e088                	sd	a0,0(s1)
    80004560:	c549                	beqz	a0,800045ea <pipealloc+0xa8>
    80004562:	bffff0ef          	jal	80004160 <filealloc>
    80004566:	00aa3023          	sd	a0,0(s4)
    8000456a:	cd25                	beqz	a0,800045e2 <pipealloc+0xa0>
    8000456c:	e84a                	sd	s2,16(sp)
    goto bad;
  if ((pi = (struct pipe *)kalloc()) == 0)
    8000456e:	de0fc0ef          	jal	80000b4e <kalloc>
    80004572:	892a                	mv	s2,a0
    80004574:	c12d                	beqz	a0,800045d6 <pipealloc+0x94>
    80004576:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80004578:	4985                	li	s3,1
    8000457a:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    8000457e:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004582:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004586:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    8000458a:	00003597          	auipc	a1,0x3
    8000458e:	02e58593          	addi	a1,a1,46 # 800075b8 <etext+0x5b8>
    80004592:	e16fc0ef          	jal	80000ba8 <initlock>
  (*f0)->type = FD_PIPE;
    80004596:	609c                	ld	a5,0(s1)
    80004598:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    8000459c:	609c                	ld	a5,0(s1)
    8000459e:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800045a2:	609c                	ld	a5,0(s1)
    800045a4:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800045a8:	609c                	ld	a5,0(s1)
    800045aa:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800045ae:	000a3783          	ld	a5,0(s4)
    800045b2:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800045b6:	000a3783          	ld	a5,0(s4)
    800045ba:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    800045be:	000a3783          	ld	a5,0(s4)
    800045c2:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800045c6:	000a3783          	ld	a5,0(s4)
    800045ca:	0127b823          	sd	s2,16(a5)
  return 0;
    800045ce:	4501                	li	a0,0
    800045d0:	6942                	ld	s2,16(sp)
    800045d2:	69a2                	ld	s3,8(sp)
    800045d4:	a01d                	j	800045fa <pipealloc+0xb8>

bad:
  if (pi)
    kfree((char *)pi);
  if (*f0)
    800045d6:	6088                	ld	a0,0(s1)
    800045d8:	c119                	beqz	a0,800045de <pipealloc+0x9c>
    800045da:	6942                	ld	s2,16(sp)
    800045dc:	a029                	j	800045e6 <pipealloc+0xa4>
    800045de:	6942                	ld	s2,16(sp)
    800045e0:	a029                	j	800045ea <pipealloc+0xa8>
    800045e2:	6088                	ld	a0,0(s1)
    800045e4:	c10d                	beqz	a0,80004606 <pipealloc+0xc4>
    fileclose(*f0);
    800045e6:	c1fff0ef          	jal	80004204 <fileclose>
  if (*f1)
    800045ea:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800045ee:	557d                	li	a0,-1
  if (*f1)
    800045f0:	c789                	beqz	a5,800045fa <pipealloc+0xb8>
    fileclose(*f1);
    800045f2:	853e                	mv	a0,a5
    800045f4:	c11ff0ef          	jal	80004204 <fileclose>
  return -1;
    800045f8:	557d                	li	a0,-1
}
    800045fa:	70a2                	ld	ra,40(sp)
    800045fc:	7402                	ld	s0,32(sp)
    800045fe:	64e2                	ld	s1,24(sp)
    80004600:	6a02                	ld	s4,0(sp)
    80004602:	6145                	addi	sp,sp,48
    80004604:	8082                	ret
  return -1;
    80004606:	557d                	li	a0,-1
    80004608:	bfcd                	j	800045fa <pipealloc+0xb8>

000000008000460a <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    8000460a:	1101                	addi	sp,sp,-32
    8000460c:	ec06                	sd	ra,24(sp)
    8000460e:	e822                	sd	s0,16(sp)
    80004610:	e426                	sd	s1,8(sp)
    80004612:	e04a                	sd	s2,0(sp)
    80004614:	1000                	addi	s0,sp,32
    80004616:	84aa                	mv	s1,a0
    80004618:	892e                	mv	s2,a1
  acquire(&pi->lock);
    8000461a:	e0efc0ef          	jal	80000c28 <acquire>
  if (writable) {
    8000461e:	02090763          	beqz	s2,8000464c <pipeclose+0x42>
    pi->writeopen = 0;
    80004622:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004626:	21848513          	addi	a0,s1,536
    8000462a:	999fd0ef          	jal	80001fc2 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if (pi->readopen == 0 && pi->writeopen == 0) {
    8000462e:	2204a783          	lw	a5,544(s1)
    80004632:	e781                	bnez	a5,8000463a <pipeclose+0x30>
    80004634:	2244a783          	lw	a5,548(s1)
    80004638:	c38d                	beqz	a5,8000465a <pipeclose+0x50>
    release(&pi->lock);
    kfree((char *)pi);
  } else
    release(&pi->lock);
    8000463a:	8526                	mv	a0,s1
    8000463c:	e74fc0ef          	jal	80000cb0 <release>
}
    80004640:	60e2                	ld	ra,24(sp)
    80004642:	6442                	ld	s0,16(sp)
    80004644:	64a2                	ld	s1,8(sp)
    80004646:	6902                	ld	s2,0(sp)
    80004648:	6105                	addi	sp,sp,32
    8000464a:	8082                	ret
    pi->readopen = 0;
    8000464c:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004650:	21c48513          	addi	a0,s1,540
    80004654:	96ffd0ef          	jal	80001fc2 <wakeup>
    80004658:	bfd9                	j	8000462e <pipeclose+0x24>
    release(&pi->lock);
    8000465a:	8526                	mv	a0,s1
    8000465c:	e54fc0ef          	jal	80000cb0 <release>
    kfree((char *)pi);
    80004660:	8526                	mv	a0,s1
    80004662:	c04fc0ef          	jal	80000a66 <kfree>
    80004666:	bfe9                	j	80004640 <pipeclose+0x36>

0000000080004668 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004668:	7159                	addi	sp,sp,-112
    8000466a:	f486                	sd	ra,104(sp)
    8000466c:	f0a2                	sd	s0,96(sp)
    8000466e:	eca6                	sd	s1,88(sp)
    80004670:	e8ca                	sd	s2,80(sp)
    80004672:	e4ce                	sd	s3,72(sp)
    80004674:	e0d2                	sd	s4,64(sp)
    80004676:	fc56                	sd	s5,56(sp)
    80004678:	1880                	addi	s0,sp,112
    8000467a:	84aa                	mv	s1,a0
    8000467c:	8aae                	mv	s5,a1
    8000467e:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004680:	accfd0ef          	jal	8000194c <myproc>
    80004684:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004686:	8526                	mv	a0,s1
    80004688:	da0fc0ef          	jal	80000c28 <acquire>
  while (i < n) {
    8000468c:	0f405a63          	blez	s4,80004780 <pipewrite+0x118>
    80004690:	f85a                	sd	s6,48(sp)
    80004692:	f45e                	sd	s7,40(sp)
    80004694:	f062                	sd	s8,32(sp)
    80004696:	ec66                	sd	s9,24(sp)
    80004698:	e86a                	sd	s10,16(sp)
  int i = 0;
    8000469a:	4901                	li	s2,0
      release(&pi->lock);
      sleep();
      acquire(&pi->lock);
    } else {
      char ch;
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    8000469c:	f9f40c13          	addi	s8,s0,-97
    800046a0:	4b85                	li	s7,1
    800046a2:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800046a4:	21848d13          	addi	s10,s1,536
      sleep_prepare(&pi->nwrite);
    800046a8:	21c48c93          	addi	s9,s1,540
    800046ac:	a0a1                	j	800046f4 <pipewrite+0x8c>
      release(&pi->lock);
    800046ae:	8526                	mv	a0,s1
    800046b0:	e00fc0ef          	jal	80000cb0 <release>
      return -1;
    800046b4:	597d                	li	s2,-1
    800046b6:	7b42                	ld	s6,48(sp)
    800046b8:	7ba2                	ld	s7,40(sp)
    800046ba:	7c02                	ld	s8,32(sp)
    800046bc:	6ce2                	ld	s9,24(sp)
    800046be:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    800046c0:	854a                	mv	a0,s2
    800046c2:	70a6                	ld	ra,104(sp)
    800046c4:	7406                	ld	s0,96(sp)
    800046c6:	64e6                	ld	s1,88(sp)
    800046c8:	6946                	ld	s2,80(sp)
    800046ca:	69a6                	ld	s3,72(sp)
    800046cc:	6a06                	ld	s4,64(sp)
    800046ce:	7ae2                	ld	s5,56(sp)
    800046d0:	6165                	addi	sp,sp,112
    800046d2:	8082                	ret
      wakeup(&pi->nread);
    800046d4:	856a                	mv	a0,s10
    800046d6:	8edfd0ef          	jal	80001fc2 <wakeup>
      sleep_prepare(&pi->nwrite);
    800046da:	8566                	mv	a0,s9
    800046dc:	87bfd0ef          	jal	80001f56 <sleep_prepare>
      release(&pi->lock);
    800046e0:	8526                	mv	a0,s1
    800046e2:	dcefc0ef          	jal	80000cb0 <release>
      sleep();
    800046e6:	8adfd0ef          	jal	80001f92 <sleep>
      acquire(&pi->lock);
    800046ea:	8526                	mv	a0,s1
    800046ec:	d3cfc0ef          	jal	80000c28 <acquire>
  while (i < n) {
    800046f0:	07495b63          	bge	s2,s4,80004766 <pipewrite+0xfe>
    if (pi->readopen == 0 || killed(pr)) {
    800046f4:	2204a783          	lw	a5,544(s1)
    800046f8:	dbdd                	beqz	a5,800046ae <pipewrite+0x46>
    800046fa:	854e                	mv	a0,s3
    800046fc:	ab9fd0ef          	jal	800021b4 <killed>
    80004700:	f55d                	bnez	a0,800046ae <pipewrite+0x46>
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
    80004702:	2184a783          	lw	a5,536(s1)
    80004706:	21c4a703          	lw	a4,540(s1)
    8000470a:	2007879b          	addiw	a5,a5,512
    8000470e:	fcf703e3          	beq	a4,a5,800046d4 <pipewrite+0x6c>
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    80004712:	875e                	mv	a4,s7
    80004714:	015906b3          	add	a3,s2,s5
    80004718:	8662                	mv	a2,s8
    8000471a:	0489b583          	ld	a1,72(s3)
    8000471e:	0509b503          	ld	a0,80(s3)
    80004722:	f2bfc0ef          	jal	8000164c <copyin>
    80004726:	03650163          	beq	a0,s6,80004748 <pipewrite+0xe0>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    8000472a:	21c4a783          	lw	a5,540(s1)
    8000472e:	0017871b          	addiw	a4,a5,1
    80004732:	20e4ae23          	sw	a4,540(s1)
    80004736:	1ff7f793          	andi	a5,a5,511
    8000473a:	97a6                	add	a5,a5,s1
    8000473c:	f9f44703          	lbu	a4,-97(s0)
    80004740:	00e78c23          	sb	a4,24(a5)
      i++;
    80004744:	2905                	addiw	s2,s2,1
    80004746:	b76d                	j	800046f0 <pipewrite+0x88>
        if (i == 0)
    80004748:	00090863          	beqz	s2,80004758 <pipewrite+0xf0>
    8000474c:	7b42                	ld	s6,48(sp)
    8000474e:	7ba2                	ld	s7,40(sp)
    80004750:	7c02                	ld	s8,32(sp)
    80004752:	6ce2                	ld	s9,24(sp)
    80004754:	6d42                	ld	s10,16(sp)
    80004756:	a829                	j	80004770 <pipewrite+0x108>
          i = -1;
    80004758:	892a                	mv	s2,a0
        break;
    8000475a:	7b42                	ld	s6,48(sp)
    8000475c:	7ba2                	ld	s7,40(sp)
    8000475e:	7c02                	ld	s8,32(sp)
    80004760:	6ce2                	ld	s9,24(sp)
    80004762:	6d42                	ld	s10,16(sp)
    80004764:	a031                	j	80004770 <pipewrite+0x108>
    80004766:	7b42                	ld	s6,48(sp)
    80004768:	7ba2                	ld	s7,40(sp)
    8000476a:	7c02                	ld	s8,32(sp)
    8000476c:	6ce2                	ld	s9,24(sp)
    8000476e:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80004770:	21848513          	addi	a0,s1,536
    80004774:	84ffd0ef          	jal	80001fc2 <wakeup>
  release(&pi->lock);
    80004778:	8526                	mv	a0,s1
    8000477a:	d36fc0ef          	jal	80000cb0 <release>
  return i;
    8000477e:	b789                	j	800046c0 <pipewrite+0x58>
  int i = 0;
    80004780:	4901                	li	s2,0
    80004782:	b7fd                	j	80004770 <pipewrite+0x108>

0000000080004784 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004784:	711d                	addi	sp,sp,-96
    80004786:	ec86                	sd	ra,88(sp)
    80004788:	e8a2                	sd	s0,80(sp)
    8000478a:	e4a6                	sd	s1,72(sp)
    8000478c:	e0ca                	sd	s2,64(sp)
    8000478e:	fc4e                	sd	s3,56(sp)
    80004790:	f852                	sd	s4,48(sp)
    80004792:	f456                	sd	s5,40(sp)
    80004794:	1080                	addi	s0,sp,96
    80004796:	84aa                	mv	s1,a0
    80004798:	89ae                	mv	s3,a1
    8000479a:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    8000479c:	9b0fd0ef          	jal	8000194c <myproc>
    800047a0:	892a                	mv	s2,a0
  char ch;

  acquire(&pi->lock);
    800047a2:	8526                	mv	a0,s1
    800047a4:	c84fc0ef          	jal	80000c28 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800047a8:	2184a703          	lw	a4,536(s1)
    800047ac:	21c4a783          	lw	a5,540(s1)
    if (killed(pr)) {
      release(&pi->lock);
      return -1;
    }
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    800047b0:	21848a13          	addi	s4,s1,536
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800047b4:	02f71e63          	bne	a4,a5,800047f0 <piperead+0x6c>
    800047b8:	2244a783          	lw	a5,548(s1)
    800047bc:	c3b9                	beqz	a5,80004802 <piperead+0x7e>
    if (killed(pr)) {
    800047be:	854a                	mv	a0,s2
    800047c0:	9f5fd0ef          	jal	800021b4 <killed>
    800047c4:	e915                	bnez	a0,800047f8 <piperead+0x74>
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    800047c6:	8552                	mv	a0,s4
    800047c8:	f8efd0ef          	jal	80001f56 <sleep_prepare>
    release(&pi->lock);
    800047cc:	8526                	mv	a0,s1
    800047ce:	ce2fc0ef          	jal	80000cb0 <release>
    sleep();
    800047d2:	fc0fd0ef          	jal	80001f92 <sleep>
    acquire(&pi->lock);
    800047d6:	8526                	mv	a0,s1
    800047d8:	c50fc0ef          	jal	80000c28 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800047dc:	2184a703          	lw	a4,536(s1)
    800047e0:	21c4a783          	lw	a5,540(s1)
    800047e4:	fcf70ae3          	beq	a4,a5,800047b8 <piperead+0x34>
    800047e8:	f05a                	sd	s6,32(sp)
    800047ea:	ec5e                	sd	s7,24(sp)
    800047ec:	e862                	sd	s8,16(sp)
    800047ee:	a829                	j	80004808 <piperead+0x84>
    800047f0:	f05a                	sd	s6,32(sp)
    800047f2:	ec5e                	sd	s7,24(sp)
    800047f4:	e862                	sd	s8,16(sp)
    800047f6:	a809                	j	80004808 <piperead+0x84>
      release(&pi->lock);
    800047f8:	8526                	mv	a0,s1
    800047fa:	cb6fc0ef          	jal	80000cb0 <release>
      return -1;
    800047fe:	5a7d                	li	s4,-1
    80004800:	a0b5                	j	8000486c <piperead+0xe8>
    80004802:	f05a                	sd	s6,32(sp)
    80004804:	ec5e                	sd	s7,24(sp)
    80004806:	e862                	sd	s8,16(sp)
  }
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004808:	4a01                	li	s4,0
    if (pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    8000480a:	faf40c13          	addi	s8,s0,-81
    8000480e:	4b85                	li	s7,1
    80004810:	5b7d                	li	s6,-1
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004812:	05505363          	blez	s5,80004858 <piperead+0xd4>
    if (pi->nread == pi->nwrite)
    80004816:	2184a783          	lw	a5,536(s1)
    8000481a:	21c4a703          	lw	a4,540(s1)
    8000481e:	02f70d63          	beq	a4,a5,80004858 <piperead+0xd4>
    ch = pi->data[pi->nread % PIPESIZE];
    80004822:	1ff7f793          	andi	a5,a5,511
    80004826:	97a6                	add	a5,a5,s1
    80004828:	0187c783          	lbu	a5,24(a5)
    8000482c:	faf407a3          	sb	a5,-81(s0)
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    80004830:	875e                	mv	a4,s7
    80004832:	86e2                	mv	a3,s8
    80004834:	864e                	mv	a2,s3
    80004836:	04893583          	ld	a1,72(s2)
    8000483a:	05093503          	ld	a0,80(s2)
    8000483e:	d49fc0ef          	jal	80001586 <copyout>
    80004842:	03650f63          	beq	a0,s6,80004880 <piperead+0xfc>
      if (i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004846:	2184a783          	lw	a5,536(s1)
    8000484a:	2785                	addiw	a5,a5,1
    8000484c:	20f4ac23          	sw	a5,536(s1)
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004850:	2a05                	addiw	s4,s4,1
    80004852:	0985                	addi	s3,s3,1
    80004854:	fd4a91e3          	bne	s5,s4,80004816 <piperead+0x92>
  }
  wakeup(&pi->nwrite); //DOC: piperead-wakeup
    80004858:	21c48513          	addi	a0,s1,540
    8000485c:	f66fd0ef          	jal	80001fc2 <wakeup>
  release(&pi->lock);
    80004860:	8526                	mv	a0,s1
    80004862:	c4efc0ef          	jal	80000cb0 <release>
    80004866:	7b02                	ld	s6,32(sp)
    80004868:	6be2                	ld	s7,24(sp)
    8000486a:	6c42                	ld	s8,16(sp)
  return i;
}
    8000486c:	8552                	mv	a0,s4
    8000486e:	60e6                	ld	ra,88(sp)
    80004870:	6446                	ld	s0,80(sp)
    80004872:	64a6                	ld	s1,72(sp)
    80004874:	6906                	ld	s2,64(sp)
    80004876:	79e2                	ld	s3,56(sp)
    80004878:	7a42                	ld	s4,48(sp)
    8000487a:	7aa2                	ld	s5,40(sp)
    8000487c:	6125                	addi	sp,sp,96
    8000487e:	8082                	ret
      if (i == 0)
    80004880:	fc0a1ce3          	bnez	s4,80004858 <piperead+0xd4>
        i = -1;
    80004884:	8a2a                	mv	s4,a0
    80004886:	bfc9                	j	80004858 <piperead+0xd4>

0000000080004888 <flags2perm>:
static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int
flags2perm(int flags)
{
    80004888:	1141                	addi	sp,sp,-16
    8000488a:	e406                	sd	ra,8(sp)
    8000488c:	e022                	sd	s0,0(sp)
    8000488e:	0800                	addi	s0,sp,16
    80004890:	87aa                	mv	a5,a0
  int perm = 0;
  if (flags & 0x1)
    80004892:	0035151b          	slliw	a0,a0,0x3
    80004896:	8921                	andi	a0,a0,8
    perm = PTE_X;
  if (flags & 0x2)
    80004898:	8b89                	andi	a5,a5,2
    8000489a:	c399                	beqz	a5,800048a0 <flags2perm+0x18>
    perm |= PTE_W;
    8000489c:	00456513          	ori	a0,a0,4
  return perm;
}
    800048a0:	60a2                	ld	ra,8(sp)
    800048a2:	6402                	ld	s0,0(sp)
    800048a4:	0141                	addi	sp,sp,16
    800048a6:	8082                	ret

00000000800048a8 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    800048a8:	de010113          	addi	sp,sp,-544
    800048ac:	20113c23          	sd	ra,536(sp)
    800048b0:	20813823          	sd	s0,528(sp)
    800048b4:	20913423          	sd	s1,520(sp)
    800048b8:	21213023          	sd	s2,512(sp)
    800048bc:	1400                	addi	s0,sp,544
    800048be:	892a                	mv	s2,a0
    800048c0:	dea43823          	sd	a0,-528(s0)
    800048c4:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    800048c8:	884fd0ef          	jal	8000194c <myproc>
    800048cc:	84aa                	mv	s1,a0

  begin_op();
    800048ce:	c7cff0ef          	jal	80003d4a <begin_op>

  // Open the executable file.
  if ((ip = namei(path)) == 0) {
    800048d2:	854a                	mv	a0,s2
    800048d4:	a98ff0ef          	jal	80003b6c <namei>
    800048d8:	cd21                	beqz	a0,80004930 <kexec+0x88>
    800048da:	fbd2                	sd	s4,496(sp)
    800048dc:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    800048de:	9f5fe0ef          	jal	800032d2 <ilock>

  // Read the ELF header.
  if (readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    800048e2:	04000713          	li	a4,64
    800048e6:	4681                	li	a3,0
    800048e8:	e5040613          	addi	a2,s0,-432
    800048ec:	4581                	li	a1,0
    800048ee:	8552                	mv	a0,s4
    800048f0:	dbdfe0ef          	jal	800036ac <readi>
    800048f4:	04000793          	li	a5,64
    800048f8:	00f51a63          	bne	a0,a5,8000490c <kexec+0x64>
    goto bad;

  // Is this really an ELF file?
  if (elf.magic != ELF_MAGIC)
    800048fc:	e5042703          	lw	a4,-432(s0)
    80004900:	464c47b7          	lui	a5,0x464c4
    80004904:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004908:	02f70863          	beq	a4,a5,80004938 <kexec+0x90>

bad:
  if (pagetable)
    proc_freepagetable(pagetable, sz);
  if (ip) {
    iunlockput(ip);
    8000490c:	8552                	mv	a0,s4
    8000490e:	c19fe0ef          	jal	80003526 <iunlockput>
    end_op();
    80004912:	cc4ff0ef          	jal	80003dd6 <end_op>
  }
  return -1;
    80004916:	557d                	li	a0,-1
    80004918:	7a5e                	ld	s4,496(sp)
}
    8000491a:	21813083          	ld	ra,536(sp)
    8000491e:	21013403          	ld	s0,528(sp)
    80004922:	20813483          	ld	s1,520(sp)
    80004926:	20013903          	ld	s2,512(sp)
    8000492a:	22010113          	addi	sp,sp,544
    8000492e:	8082                	ret
    end_op();
    80004930:	ca6ff0ef          	jal	80003dd6 <end_op>
    return -1;
    80004934:	557d                	li	a0,-1
    80004936:	b7d5                	j	8000491a <kexec+0x72>
    80004938:	f3da                	sd	s6,480(sp)
  if ((pagetable = proc_pagetable(p)) == 0)
    8000493a:	8526                	mv	a0,s1
    8000493c:	916fd0ef          	jal	80001a52 <proc_pagetable>
    80004940:	8b2a                	mv	s6,a0
    80004942:	26050e63          	beqz	a0,80004bbe <kexec+0x316>
    80004946:	ffce                	sd	s3,504(sp)
    80004948:	f7d6                	sd	s5,488(sp)
    8000494a:	efde                	sd	s7,472(sp)
    8000494c:	ebe2                	sd	s8,464(sp)
    8000494e:	e7e6                	sd	s9,456(sp)
    80004950:	e3ea                	sd	s10,448(sp)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004952:	e8845783          	lhu	a5,-376(s0)
    80004956:	14078263          	beqz	a5,80004a9a <kexec+0x1f2>
    8000495a:	ff6e                	sd	s11,440(sp)
    8000495c:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004960:	4901                	li	s2,0
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004962:	4d01                	li	s10,0
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004964:	03800d93          	li	s11,56
    if (ph.vaddr % PGSIZE != 0)
    80004968:	6c85                	lui	s9,0x1
    8000496a:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    8000496e:	def43423          	sd	a5,-536(s0)

  for (i = 0; i < sz; i += PGSIZE) {
    pa = walkaddr(pagetable, va + i);
    if (pa == 0)
      panic("loadseg: address should exist");
    if (sz - i < PGSIZE)
    80004972:	6a85                	lui	s5,0x1
    80004974:	a085                	j	800049d4 <kexec+0x12c>
      panic("loadseg: address should exist");
    80004976:	00003517          	auipc	a0,0x3
    8000497a:	c4a50513          	addi	a0,a0,-950 # 800075c0 <etext+0x5c0>
    8000497e:	eb7fb0ef          	jal	80000834 <panic>
    if (sz - i < PGSIZE)
    80004982:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if (readi(ip, 0, (uint64)pa, offset + i, n) != n)
    80004984:	874a                	mv	a4,s2
    80004986:	009b86bb          	addw	a3,s7,s1
    8000498a:	4581                	li	a1,0
    8000498c:	8552                	mv	a0,s4
    8000498e:	d1ffe0ef          	jal	800036ac <readi>
    80004992:	22a91a63          	bne	s2,a0,80004bc6 <kexec+0x31e>
  for (i = 0; i < sz; i += PGSIZE) {
    80004996:	009a84bb          	addw	s1,s5,s1
    8000499a:	0334f263          	bgeu	s1,s3,800049be <kexec+0x116>
    pa = walkaddr(pagetable, va + i);
    8000499e:	02049593          	slli	a1,s1,0x20
    800049a2:	9181                	srli	a1,a1,0x20
    800049a4:	95e2                	add	a1,a1,s8
    800049a6:	855a                	mv	a0,s6
    800049a8:	e74fc0ef          	jal	8000101c <walkaddr>
    800049ac:	862a                	mv	a2,a0
    if (pa == 0)
    800049ae:	d561                	beqz	a0,80004976 <kexec+0xce>
    if (sz - i < PGSIZE)
    800049b0:	409987bb          	subw	a5,s3,s1
    800049b4:	893e                	mv	s2,a5
    800049b6:	fcfcf6e3          	bgeu	s9,a5,80004982 <kexec+0xda>
    800049ba:	8956                	mv	s2,s5
    800049bc:	b7d9                	j	80004982 <kexec+0xda>
    sz = sz1;
    800049be:	df843903          	ld	s2,-520(s0)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    800049c2:	2d05                	addiw	s10,s10,1
    800049c4:	e0843783          	ld	a5,-504(s0)
    800049c8:	0387869b          	addiw	a3,a5,56
    800049cc:	e8845783          	lhu	a5,-376(s0)
    800049d0:	06fd5d63          	bge	s10,a5,80004a4a <kexec+0x1a2>
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800049d4:	e0d43423          	sd	a3,-504(s0)
    800049d8:	876e                	mv	a4,s11
    800049da:	e1840613          	addi	a2,s0,-488
    800049de:	4581                	li	a1,0
    800049e0:	8552                	mv	a0,s4
    800049e2:	ccbfe0ef          	jal	800036ac <readi>
    800049e6:	1db51e63          	bne	a0,s11,80004bc2 <kexec+0x31a>
    if (ph.type != ELF_PROG_LOAD)
    800049ea:	e1842783          	lw	a5,-488(s0)
    800049ee:	4705                	li	a4,1
    800049f0:	fce799e3          	bne	a5,a4,800049c2 <kexec+0x11a>
    if (ph.memsz < ph.filesz)
    800049f4:	e4043483          	ld	s1,-448(s0)
    800049f8:	e3843783          	ld	a5,-456(s0)
    800049fc:	1ef4e363          	bltu	s1,a5,80004be2 <kexec+0x33a>
    if (ph.vaddr + ph.memsz < ph.vaddr)
    80004a00:	e2843783          	ld	a5,-472(s0)
    80004a04:	94be                	add	s1,s1,a5
    80004a06:	1ef4e163          	bltu	s1,a5,80004be8 <kexec+0x340>
    if (ph.vaddr % PGSIZE != 0)
    80004a0a:	de843703          	ld	a4,-536(s0)
    80004a0e:	8ff9                	and	a5,a5,a4
    80004a10:	1c079f63          	bnez	a5,80004bee <kexec+0x346>
    if ((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz,
    80004a14:	e1c42503          	lw	a0,-484(s0)
    80004a18:	e71ff0ef          	jal	80004888 <flags2perm>
    80004a1c:	86aa                	mv	a3,a0
    80004a1e:	8626                	mv	a2,s1
    80004a20:	85ca                	mv	a1,s2
    80004a22:	855a                	mv	a0,s6
    80004a24:	8cffc0ef          	jal	800012f2 <uvmalloc>
    80004a28:	dea43c23          	sd	a0,-520(s0)
    80004a2c:	1c050463          	beqz	a0,80004bf4 <kexec+0x34c>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004a30:	e3842983          	lw	s3,-456(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    80004a34:	00098863          	beqz	s3,80004a44 <kexec+0x19c>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004a38:	e2843c03          	ld	s8,-472(s0)
    80004a3c:	e2042b83          	lw	s7,-480(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    80004a40:	4481                	li	s1,0
    80004a42:	bfb1                	j	8000499e <kexec+0xf6>
    sz = sz1;
    80004a44:	df843903          	ld	s2,-520(s0)
    80004a48:	bfad                	j	800049c2 <kexec+0x11a>
    80004a4a:	7dfa                	ld	s11,440(sp)
  iunlockput(ip);
    80004a4c:	8552                	mv	a0,s4
    80004a4e:	ad9fe0ef          	jal	80003526 <iunlockput>
  end_op();
    80004a52:	b84ff0ef          	jal	80003dd6 <end_op>
  p = myproc();
    80004a56:	ef7fc0ef          	jal	8000194c <myproc>
    80004a5a:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    80004a5c:	04853a83          	ld	s5,72(a0)
  sz = PGROUNDUP(sz);
    80004a60:	6c05                	lui	s8,0x1
    80004a62:	1c7d                	addi	s8,s8,-1 # fff <_entry-0x7ffff001>
    80004a64:	9c4a                	add	s8,s8,s2
    80004a66:	77fd                	lui	a5,0xfffff
    80004a68:	00fc7c33          	and	s8,s8,a5
  if ((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK + 1) * PGSIZE, PTE_W)) ==
    80004a6c:	4691                	li	a3,4
    80004a6e:	6609                	lui	a2,0x2
    80004a70:	9662                	add	a2,a2,s8
    80004a72:	85e2                	mv	a1,s8
    80004a74:	855a                	mv	a0,s6
    80004a76:	87dfc0ef          	jal	800012f2 <uvmalloc>
    80004a7a:	892a                	mv	s2,a0
    80004a7c:	e10d                	bnez	a0,80004a9e <kexec+0x1f6>
    proc_freepagetable(pagetable, sz);
    80004a7e:	85e2                	mv	a1,s8
    80004a80:	855a                	mv	a0,s6
    80004a82:	854fd0ef          	jal	80001ad6 <proc_freepagetable>
  return -1;
    80004a86:	557d                	li	a0,-1
    80004a88:	79fe                	ld	s3,504(sp)
    80004a8a:	7a5e                	ld	s4,496(sp)
    80004a8c:	7abe                	ld	s5,488(sp)
    80004a8e:	7b1e                	ld	s6,480(sp)
    80004a90:	6bfe                	ld	s7,472(sp)
    80004a92:	6c5e                	ld	s8,464(sp)
    80004a94:	6cbe                	ld	s9,456(sp)
    80004a96:	6d1e                	ld	s10,448(sp)
    80004a98:	b549                	j	8000491a <kexec+0x72>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004a9a:	4901                	li	s2,0
    80004a9c:	bf45                	j	80004a4c <kexec+0x1a4>
  uvmclear(pagetable, sz - (USERSTACK + 1) * PGSIZE);
    80004a9e:	75f9                	lui	a1,0xffffe
    80004aa0:	95aa                	add	a1,a1,a0
    80004aa2:	855a                	mv	a0,s6
    80004aa4:	a21fc0ef          	jal	800014c4 <uvmclear>
  stackbase = sp - USERSTACK * PGSIZE;
    80004aa8:	80090a13          	addi	s4,s2,-2048
    80004aac:	800a0a13          	addi	s4,s4,-2048
  for (argc = 0; argv[argc]; argc++) {
    80004ab0:	e0043783          	ld	a5,-512(s0)
    80004ab4:	6388                	ld	a0,0(a5)
    80004ab6:	c545                	beqz	a0,80004b5e <kexec+0x2b6>
  sp = sz;
    80004ab8:	8c4a                	mv	s8,s2
  for (argc = 0; argv[argc]; argc++) {
    80004aba:	4481                	li	s1,0
    ustack[argc] = sp;
    80004abc:	e9040b93          	addi	s7,s0,-368
    sp -= strlen(argv[argc]) + 1;
    80004ac0:	bb2fc0ef          	jal	80000e72 <strlen>
    80004ac4:	0015079b          	addiw	a5,a0,1
    80004ac8:	40fc07b3          	sub	a5,s8,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004acc:	ff07fc13          	andi	s8,a5,-16
    if (sp < stackbase)
    80004ad0:	134c6563          	bltu	s8,s4,80004bfa <kexec+0x352>
    if (copyout(pagetable, sz, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004ad4:	e0043d03          	ld	s10,-512(s0)
    80004ad8:	000d3c83          	ld	s9,0(s10)
    80004adc:	8566                	mv	a0,s9
    80004ade:	b94fc0ef          	jal	80000e72 <strlen>
    80004ae2:	0015071b          	addiw	a4,a0,1
    80004ae6:	86e6                	mv	a3,s9
    80004ae8:	8662                	mv	a2,s8
    80004aea:	85ca                	mv	a1,s2
    80004aec:	855a                	mv	a0,s6
    80004aee:	a99fc0ef          	jal	80001586 <copyout>
    80004af2:	10054663          	bltz	a0,80004bfe <kexec+0x356>
    ustack[argc] = sp;
    80004af6:	00349793          	slli	a5,s1,0x3
    80004afa:	97de                	add	a5,a5,s7
    80004afc:	0187b023          	sd	s8,0(a5) # fffffffffffff000 <end+0xffffffff7ffdb740>
  for (argc = 0; argv[argc]; argc++) {
    80004b00:	0485                	addi	s1,s1,1
    80004b02:	008d0793          	addi	a5,s10,8
    80004b06:	e0f43023          	sd	a5,-512(s0)
    80004b0a:	008d3503          	ld	a0,8(s10)
    80004b0e:	f94d                	bnez	a0,80004ac0 <kexec+0x218>
  ustack[argc] = 0;
    80004b10:	00349793          	slli	a5,s1,0x3
    80004b14:	f9078793          	addi	a5,a5,-112
    80004b18:	97a2                	add	a5,a5,s0
    80004b1a:	f007b023          	sd	zero,-256(a5)
  sp -= (argc + 1) * sizeof(uint64);
    80004b1e:	00349713          	slli	a4,s1,0x3
    80004b22:	0721                	addi	a4,a4,8
    80004b24:	40ec0bb3          	sub	s7,s8,a4
  sp -= sp % 16;
    80004b28:	ff0bfb93          	andi	s7,s7,-16
  sz = sz1;
    80004b2c:	8c4a                	mv	s8,s2
  if (sp < stackbase)
    80004b2e:	f54be8e3          	bltu	s7,s4,80004a7e <kexec+0x1d6>
  if (copyout(pagetable, sz, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) <
    80004b32:	e9040693          	addi	a3,s0,-368
    80004b36:	865e                	mv	a2,s7
    80004b38:	85ca                	mv	a1,s2
    80004b3a:	855a                	mv	a0,s6
    80004b3c:	a4bfc0ef          	jal	80001586 <copyout>
    80004b40:	f2054fe3          	bltz	a0,80004a7e <kexec+0x1d6>
  p->trapframe->a1 = sp;
    80004b44:	0589b783          	ld	a5,88(s3)
    80004b48:	0777bc23          	sd	s7,120(a5)
  for (last = s = path; *s; s++)
    80004b4c:	df043783          	ld	a5,-528(s0)
    80004b50:	0007c703          	lbu	a4,0(a5)
    80004b54:	c30d                	beqz	a4,80004b76 <kexec+0x2ce>
    80004b56:	0785                	addi	a5,a5,1
    if (*s == '/')
    80004b58:	02f00693          	li	a3,47
    80004b5c:	a801                	j	80004b6c <kexec+0x2c4>
  sp = sz;
    80004b5e:	8c4a                	mv	s8,s2
  for (argc = 0; argv[argc]; argc++) {
    80004b60:	4481                	li	s1,0
    80004b62:	b77d                	j	80004b10 <kexec+0x268>
  for (last = s = path; *s; s++)
    80004b64:	0785                	addi	a5,a5,1
    80004b66:	fff7c703          	lbu	a4,-1(a5)
    80004b6a:	c711                	beqz	a4,80004b76 <kexec+0x2ce>
    if (*s == '/')
    80004b6c:	fed71ce3          	bne	a4,a3,80004b64 <kexec+0x2bc>
      last = s + 1;
    80004b70:	def43823          	sd	a5,-528(s0)
    80004b74:	bfc5                	j	80004b64 <kexec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80004b76:	4641                	li	a2,16
    80004b78:	df043583          	ld	a1,-528(s0)
    80004b7c:	15898513          	addi	a0,s3,344
    80004b80:	abcfc0ef          	jal	80000e3c <safestrcpy>
  oldpagetable = p->pagetable;
    80004b84:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    80004b88:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    80004b8c:	0529b423          	sd	s2,72(s3)
  p->trapframe->epc = elf.entry; // initial program counter = ulib.c:start()
    80004b90:	0589b783          	ld	a5,88(s3)
    80004b94:	e6843703          	ld	a4,-408(s0)
    80004b98:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp;         // initial stack pointer
    80004b9a:	0589b783          	ld	a5,88(s3)
    80004b9e:	0377b823          	sd	s7,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004ba2:	85d6                	mv	a1,s5
    80004ba4:	f33fc0ef          	jal	80001ad6 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004ba8:	0004851b          	sext.w	a0,s1
    80004bac:	79fe                	ld	s3,504(sp)
    80004bae:	7a5e                	ld	s4,496(sp)
    80004bb0:	7abe                	ld	s5,488(sp)
    80004bb2:	7b1e                	ld	s6,480(sp)
    80004bb4:	6bfe                	ld	s7,472(sp)
    80004bb6:	6c5e                	ld	s8,464(sp)
    80004bb8:	6cbe                	ld	s9,456(sp)
    80004bba:	6d1e                	ld	s10,448(sp)
    80004bbc:	bbb9                	j	8000491a <kexec+0x72>
    80004bbe:	7b1e                	ld	s6,480(sp)
    80004bc0:	b3b1                	j	8000490c <kexec+0x64>
    80004bc2:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80004bc6:	df843583          	ld	a1,-520(s0)
    80004bca:	855a                	mv	a0,s6
    80004bcc:	f0bfc0ef          	jal	80001ad6 <proc_freepagetable>
  if (ip) {
    80004bd0:	79fe                	ld	s3,504(sp)
    80004bd2:	7abe                	ld	s5,488(sp)
    80004bd4:	7b1e                	ld	s6,480(sp)
    80004bd6:	6bfe                	ld	s7,472(sp)
    80004bd8:	6c5e                	ld	s8,464(sp)
    80004bda:	6cbe                	ld	s9,456(sp)
    80004bdc:	6d1e                	ld	s10,448(sp)
    80004bde:	7dfa                	ld	s11,440(sp)
    80004be0:	b335                	j	8000490c <kexec+0x64>
    80004be2:	df243c23          	sd	s2,-520(s0)
    80004be6:	b7c5                	j	80004bc6 <kexec+0x31e>
    80004be8:	df243c23          	sd	s2,-520(s0)
    80004bec:	bfe9                	j	80004bc6 <kexec+0x31e>
    80004bee:	df243c23          	sd	s2,-520(s0)
    80004bf2:	bfd1                	j	80004bc6 <kexec+0x31e>
    80004bf4:	df243c23          	sd	s2,-520(s0)
    80004bf8:	b7f9                	j	80004bc6 <kexec+0x31e>
  sz = sz1;
    80004bfa:	8c4a                	mv	s8,s2
    80004bfc:	b549                	j	80004a7e <kexec+0x1d6>
    80004bfe:	8c4a                	mv	s8,s2
    80004c00:	bdbd                	j	80004a7e <kexec+0x1d6>

0000000080004c02 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004c02:	7179                	addi	sp,sp,-48
    80004c04:	f406                	sd	ra,40(sp)
    80004c06:	f022                	sd	s0,32(sp)
    80004c08:	ec26                	sd	s1,24(sp)
    80004c0a:	e84a                	sd	s2,16(sp)
    80004c0c:	1800                	addi	s0,sp,48
    80004c0e:	892e                	mv	s2,a1
    80004c10:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004c12:	fdc40593          	addi	a1,s0,-36
    80004c16:	c7ffd0ef          	jal	80002894 <argint>
  if (fd < 0 || fd >= NOFILE || (f = myproc()->ofile[fd]) == 0)
    80004c1a:	fdc42703          	lw	a4,-36(s0)
    80004c1e:	47bd                	li	a5,15
    80004c20:	02e7ea63          	bltu	a5,a4,80004c54 <argfd+0x52>
    80004c24:	d29fc0ef          	jal	8000194c <myproc>
    80004c28:	fdc42703          	lw	a4,-36(s0)
    80004c2c:	00371793          	slli	a5,a4,0x3
    80004c30:	0d078793          	addi	a5,a5,208
    80004c34:	953e                	add	a0,a0,a5
    80004c36:	611c                	ld	a5,0(a0)
    80004c38:	c385                	beqz	a5,80004c58 <argfd+0x56>
    return -1;
  if (pfd)
    80004c3a:	00090463          	beqz	s2,80004c42 <argfd+0x40>
    *pfd = fd;
    80004c3e:	00e92023          	sw	a4,0(s2)
  if (pf)
    *pf = f;
  return 0;
    80004c42:	4501                	li	a0,0
  if (pf)
    80004c44:	c091                	beqz	s1,80004c48 <argfd+0x46>
    *pf = f;
    80004c46:	e09c                	sd	a5,0(s1)
}
    80004c48:	70a2                	ld	ra,40(sp)
    80004c4a:	7402                	ld	s0,32(sp)
    80004c4c:	64e2                	ld	s1,24(sp)
    80004c4e:	6942                	ld	s2,16(sp)
    80004c50:	6145                	addi	sp,sp,48
    80004c52:	8082                	ret
    return -1;
    80004c54:	557d                	li	a0,-1
    80004c56:	bfcd                	j	80004c48 <argfd+0x46>
    80004c58:	557d                	li	a0,-1
    80004c5a:	b7fd                	j	80004c48 <argfd+0x46>

0000000080004c5c <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004c5c:	1101                	addi	sp,sp,-32
    80004c5e:	ec06                	sd	ra,24(sp)
    80004c60:	e822                	sd	s0,16(sp)
    80004c62:	e426                	sd	s1,8(sp)
    80004c64:	1000                	addi	s0,sp,32
    80004c66:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004c68:	ce5fc0ef          	jal	8000194c <myproc>
    80004c6c:	862a                	mv	a2,a0

  for (fd = 0; fd < NOFILE; fd++) {
    80004c6e:	0d050793          	addi	a5,a0,208
    80004c72:	4501                	li	a0,0
    80004c74:	46c1                	li	a3,16
    if (p->ofile[fd] == 0) {
    80004c76:	6398                	ld	a4,0(a5)
    80004c78:	cb19                	beqz	a4,80004c8e <fdalloc+0x32>
  for (fd = 0; fd < NOFILE; fd++) {
    80004c7a:	2505                	addiw	a0,a0,1
    80004c7c:	07a1                	addi	a5,a5,8
    80004c7e:	fed51ce3          	bne	a0,a3,80004c76 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004c82:	557d                	li	a0,-1
}
    80004c84:	60e2                	ld	ra,24(sp)
    80004c86:	6442                	ld	s0,16(sp)
    80004c88:	64a2                	ld	s1,8(sp)
    80004c8a:	6105                	addi	sp,sp,32
    80004c8c:	8082                	ret
      p->ofile[fd] = f;
    80004c8e:	00351793          	slli	a5,a0,0x3
    80004c92:	0d078793          	addi	a5,a5,208
    80004c96:	963e                	add	a2,a2,a5
    80004c98:	e204                	sd	s1,0(a2)
      return fd;
    80004c9a:	b7ed                	j	80004c84 <fdalloc+0x28>

0000000080004c9c <create>:
  return -1;
}

static struct inode *
create(char *path, short type, short major, short minor)
{
    80004c9c:	715d                	addi	sp,sp,-80
    80004c9e:	e486                	sd	ra,72(sp)
    80004ca0:	e0a2                	sd	s0,64(sp)
    80004ca2:	fc26                	sd	s1,56(sp)
    80004ca4:	f84a                	sd	s2,48(sp)
    80004ca6:	f052                	sd	s4,32(sp)
    80004ca8:	ec56                	sd	s5,24(sp)
    80004caa:	e85a                	sd	s6,16(sp)
    80004cac:	0880                	addi	s0,sp,80
    80004cae:	8a2e                	mv	s4,a1
    80004cb0:	8ab2                	mv	s5,a2
    80004cb2:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if ((dp = nameiparent(path, name)) == 0)
    80004cb4:	fb040593          	addi	a1,s0,-80
    80004cb8:	ecffe0ef          	jal	80003b86 <nameiparent>
    80004cbc:	84aa                	mv	s1,a0
    80004cbe:	12050f63          	beqz	a0,80004dfc <create+0x160>
    return 0;

  ilock(dp);
    80004cc2:	e10fe0ef          	jal	800032d2 <ilock>

  if (dp->nlink == 0) {
    80004cc6:	04a49783          	lh	a5,74(s1)
    80004cca:	cbb9                	beqz	a5,80004d20 <create+0x84>
    iunlockput(dp);
    return 0;
  }

  // a new directory's ".." would push dp->nlink past its maximum
  if (type == T_DIR && dp->nlink >= NLINK_MAX) {
    80004ccc:	7761                	lui	a4,0xffff8
    80004cce:	0705                	addi	a4,a4,1 # ffffffffffff8001 <end+0xffffffff7ffd4741>
    80004cd0:	97ba                	add	a5,a5,a4
    80004cd2:	e781                	bnez	a5,80004cda <create+0x3e>
    80004cd4:	fffa0793          	addi	a5,s4,-1
    80004cd8:	cba9                	beqz	a5,80004d2a <create+0x8e>
    iunlockput(dp);
    return 0;
  }

  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004cda:	4601                	li	a2,0
    80004cdc:	fb040593          	addi	a1,s0,-80
    80004ce0:	8526                	mv	a0,s1
    80004ce2:	bd9fe0ef          	jal	800038ba <dirlookup>
    80004ce6:	892a                	mv	s2,a0
    80004ce8:	c939                	beqz	a0,80004d3e <create+0xa2>
    iunlockput(dp);
    80004cea:	8526                	mv	a0,s1
    80004cec:	83bfe0ef          	jal	80003526 <iunlockput>
    ilock(ip);
    80004cf0:	854a                	mv	a0,s2
    80004cf2:	de0fe0ef          	jal	800032d2 <ilock>
    if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004cf6:	4789                	li	a5,2
    80004cf8:	02fa1e63          	bne	s4,a5,80004d34 <create+0x98>
    80004cfc:	04495783          	lhu	a5,68(s2)
    80004d00:	37f9                	addiw	a5,a5,-2
    80004d02:	17c2                	slli	a5,a5,0x30
    80004d04:	93c1                	srli	a5,a5,0x30
    80004d06:	4705                	li	a4,1
    80004d08:	02f76663          	bltu	a4,a5,80004d34 <create+0x98>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004d0c:	854a                	mv	a0,s2
    80004d0e:	60a6                	ld	ra,72(sp)
    80004d10:	6406                	ld	s0,64(sp)
    80004d12:	74e2                	ld	s1,56(sp)
    80004d14:	7942                	ld	s2,48(sp)
    80004d16:	7a02                	ld	s4,32(sp)
    80004d18:	6ae2                	ld	s5,24(sp)
    80004d1a:	6b42                	ld	s6,16(sp)
    80004d1c:	6161                	addi	sp,sp,80
    80004d1e:	8082                	ret
    iunlockput(dp);
    80004d20:	8526                	mv	a0,s1
    80004d22:	805fe0ef          	jal	80003526 <iunlockput>
    return 0;
    80004d26:	4901                	li	s2,0
    80004d28:	b7d5                	j	80004d0c <create+0x70>
    iunlockput(dp);
    80004d2a:	8526                	mv	a0,s1
    80004d2c:	ffafe0ef          	jal	80003526 <iunlockput>
    return 0;
    80004d30:	4901                	li	s2,0
    80004d32:	bfe9                	j	80004d0c <create+0x70>
    iunlockput(ip);
    80004d34:	854a                	mv	a0,s2
    80004d36:	ff0fe0ef          	jal	80003526 <iunlockput>
    return 0;
    80004d3a:	4901                	li	s2,0
    80004d3c:	bfc1                	j	80004d0c <create+0x70>
    80004d3e:	f44e                	sd	s3,40(sp)
  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004d40:	85d2                	mv	a1,s4
    80004d42:	4088                	lw	a0,0(s1)
    80004d44:	c1efe0ef          	jal	80003162 <ialloc>
    80004d48:	89aa                	mv	s3,a0
    80004d4a:	cd1d                	beqz	a0,80004d88 <create+0xec>
  ilock(ip);
    80004d4c:	d86fe0ef          	jal	800032d2 <ilock>
  ip->major = major;
    80004d50:	05599323          	sh	s5,70(s3)
  ip->minor = minor;
    80004d54:	05699423          	sh	s6,72(s3)
  ip->nlink = 1;
    80004d58:	4705                	li	a4,1
    80004d5a:	04e99523          	sh	a4,74(s3)
  iupdate(ip);
    80004d5e:	854e                	mv	a0,s3
    80004d60:	cbefe0ef          	jal	8000321e <iupdate>
  if (type == T_DIR) { // Create . and .. entries.
    80004d64:	4705                	li	a4,1
    80004d66:	02ea0763          	beq	s4,a4,80004d94 <create+0xf8>
  if (dirlink(dp, name, ip->inum) < 0)
    80004d6a:	0049a603          	lw	a2,4(s3)
    80004d6e:	fb040593          	addi	a1,s0,-80
    80004d72:	8526                	mv	a0,s1
    80004d74:	d4ffe0ef          	jal	80003ac2 <dirlink>
    80004d78:	06054563          	bltz	a0,80004de2 <create+0x146>
  iunlockput(dp);
    80004d7c:	8526                	mv	a0,s1
    80004d7e:	fa8fe0ef          	jal	80003526 <iunlockput>
  return ip;
    80004d82:	894e                	mv	s2,s3
    80004d84:	79a2                	ld	s3,40(sp)
    80004d86:	b759                	j	80004d0c <create+0x70>
    iunlockput(dp);
    80004d88:	8526                	mv	a0,s1
    80004d8a:	f9cfe0ef          	jal	80003526 <iunlockput>
    return 0;
    80004d8e:	894e                	mv	s2,s3
    80004d90:	79a2                	ld	s3,40(sp)
    80004d92:	bfad                	j	80004d0c <create+0x70>
    if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004d94:	0049a603          	lw	a2,4(s3)
    80004d98:	00003597          	auipc	a1,0x3
    80004d9c:	84858593          	addi	a1,a1,-1976 # 800075e0 <etext+0x5e0>
    80004da0:	854e                	mv	a0,s3
    80004da2:	d21fe0ef          	jal	80003ac2 <dirlink>
    80004da6:	02054e63          	bltz	a0,80004de2 <create+0x146>
    80004daa:	40d0                	lw	a2,4(s1)
    80004dac:	00003597          	auipc	a1,0x3
    80004db0:	83c58593          	addi	a1,a1,-1988 # 800075e8 <etext+0x5e8>
    80004db4:	854e                	mv	a0,s3
    80004db6:	d0dfe0ef          	jal	80003ac2 <dirlink>
    80004dba:	02054463          	bltz	a0,80004de2 <create+0x146>
  if (dirlink(dp, name, ip->inum) < 0)
    80004dbe:	0049a603          	lw	a2,4(s3)
    80004dc2:	fb040593          	addi	a1,s0,-80
    80004dc6:	8526                	mv	a0,s1
    80004dc8:	cfbfe0ef          	jal	80003ac2 <dirlink>
    80004dcc:	00054b63          	bltz	a0,80004de2 <create+0x146>
    dp->nlink++; // for ".."
    80004dd0:	04a4d783          	lhu	a5,74(s1)
    80004dd4:	2785                	addiw	a5,a5,1
    80004dd6:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004dda:	8526                	mv	a0,s1
    80004ddc:	c42fe0ef          	jal	8000321e <iupdate>
    80004de0:	bf71                	j	80004d7c <create+0xe0>
  ip->nlink = 0;
    80004de2:	04099523          	sh	zero,74(s3)
  iupdate(ip);
    80004de6:	854e                	mv	a0,s3
    80004de8:	c36fe0ef          	jal	8000321e <iupdate>
  iunlockput(ip);
    80004dec:	854e                	mv	a0,s3
    80004dee:	f38fe0ef          	jal	80003526 <iunlockput>
  iunlockput(dp);
    80004df2:	8526                	mv	a0,s1
    80004df4:	f32fe0ef          	jal	80003526 <iunlockput>
  return 0;
    80004df8:	79a2                	ld	s3,40(sp)
    80004dfa:	bf09                	j	80004d0c <create+0x70>
    return 0;
    80004dfc:	892a                	mv	s2,a0
    80004dfe:	b739                	j	80004d0c <create+0x70>

0000000080004e00 <sys_dup>:
{
    80004e00:	7179                	addi	sp,sp,-48
    80004e02:	f406                	sd	ra,40(sp)
    80004e04:	f022                	sd	s0,32(sp)
    80004e06:	1800                	addi	s0,sp,48
  if (argfd(0, 0, &f) < 0)
    80004e08:	fd840613          	addi	a2,s0,-40
    80004e0c:	4581                	li	a1,0
    80004e0e:	4501                	li	a0,0
    80004e10:	df3ff0ef          	jal	80004c02 <argfd>
    return -1;
    80004e14:	57fd                	li	a5,-1
  if (argfd(0, 0, &f) < 0)
    80004e16:	02054363          	bltz	a0,80004e3c <sys_dup+0x3c>
    80004e1a:	ec26                	sd	s1,24(sp)
    80004e1c:	e84a                	sd	s2,16(sp)
  if ((fd = fdalloc(f)) < 0)
    80004e1e:	fd843483          	ld	s1,-40(s0)
    80004e22:	8526                	mv	a0,s1
    80004e24:	e39ff0ef          	jal	80004c5c <fdalloc>
    80004e28:	892a                	mv	s2,a0
    return -1;
    80004e2a:	57fd                	li	a5,-1
  if ((fd = fdalloc(f)) < 0)
    80004e2c:	00054d63          	bltz	a0,80004e46 <sys_dup+0x46>
  filedup(f);
    80004e30:	8526                	mv	a0,s1
    80004e32:	b8cff0ef          	jal	800041be <filedup>
  return fd;
    80004e36:	87ca                	mv	a5,s2
    80004e38:	64e2                	ld	s1,24(sp)
    80004e3a:	6942                	ld	s2,16(sp)
}
    80004e3c:	853e                	mv	a0,a5
    80004e3e:	70a2                	ld	ra,40(sp)
    80004e40:	7402                	ld	s0,32(sp)
    80004e42:	6145                	addi	sp,sp,48
    80004e44:	8082                	ret
    80004e46:	64e2                	ld	s1,24(sp)
    80004e48:	6942                	ld	s2,16(sp)
    80004e4a:	bfcd                	j	80004e3c <sys_dup+0x3c>

0000000080004e4c <sys_read>:
{
    80004e4c:	7179                	addi	sp,sp,-48
    80004e4e:	f406                	sd	ra,40(sp)
    80004e50:	f022                	sd	s0,32(sp)
    80004e52:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004e54:	fd840593          	addi	a1,s0,-40
    80004e58:	4505                	li	a0,1
    80004e5a:	a57fd0ef          	jal	800028b0 <argaddr>
  argint(2, &n);
    80004e5e:	fe440593          	addi	a1,s0,-28
    80004e62:	4509                	li	a0,2
    80004e64:	a31fd0ef          	jal	80002894 <argint>
  if (argfd(0, 0, &f) < 0)
    80004e68:	fe840613          	addi	a2,s0,-24
    80004e6c:	4581                	li	a1,0
    80004e6e:	4501                	li	a0,0
    80004e70:	d93ff0ef          	jal	80004c02 <argfd>
    80004e74:	87aa                	mv	a5,a0
    return -1;
    80004e76:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004e78:	0007ca63          	bltz	a5,80004e8c <sys_read+0x40>
  return fileread(f, p, n);
    80004e7c:	fe442603          	lw	a2,-28(s0)
    80004e80:	fd843583          	ld	a1,-40(s0)
    80004e84:	fe843503          	ld	a0,-24(s0)
    80004e88:	caeff0ef          	jal	80004336 <fileread>
}
    80004e8c:	70a2                	ld	ra,40(sp)
    80004e8e:	7402                	ld	s0,32(sp)
    80004e90:	6145                	addi	sp,sp,48
    80004e92:	8082                	ret

0000000080004e94 <sys_write>:
{
    80004e94:	7179                	addi	sp,sp,-48
    80004e96:	f406                	sd	ra,40(sp)
    80004e98:	f022                	sd	s0,32(sp)
    80004e9a:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004e9c:	fd840593          	addi	a1,s0,-40
    80004ea0:	4505                	li	a0,1
    80004ea2:	a0ffd0ef          	jal	800028b0 <argaddr>
  argint(2, &n);
    80004ea6:	fe440593          	addi	a1,s0,-28
    80004eaa:	4509                	li	a0,2
    80004eac:	9e9fd0ef          	jal	80002894 <argint>
  if (argfd(0, 0, &f) < 0)
    80004eb0:	fe840613          	addi	a2,s0,-24
    80004eb4:	4581                	li	a1,0
    80004eb6:	4501                	li	a0,0
    80004eb8:	d4bff0ef          	jal	80004c02 <argfd>
    80004ebc:	87aa                	mv	a5,a0
    return -1;
    80004ebe:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004ec0:	0007ca63          	bltz	a5,80004ed4 <sys_write+0x40>
  return filewrite(f, p, n);
    80004ec4:	fe442603          	lw	a2,-28(s0)
    80004ec8:	fd843583          	ld	a1,-40(s0)
    80004ecc:	fe843503          	ld	a0,-24(s0)
    80004ed0:	d34ff0ef          	jal	80004404 <filewrite>
}
    80004ed4:	70a2                	ld	ra,40(sp)
    80004ed6:	7402                	ld	s0,32(sp)
    80004ed8:	6145                	addi	sp,sp,48
    80004eda:	8082                	ret

0000000080004edc <sys_close>:
{
    80004edc:	1101                	addi	sp,sp,-32
    80004ede:	ec06                	sd	ra,24(sp)
    80004ee0:	e822                	sd	s0,16(sp)
    80004ee2:	1000                	addi	s0,sp,32
  if (argfd(0, &fd, &f) < 0)
    80004ee4:	fe040613          	addi	a2,s0,-32
    80004ee8:	fec40593          	addi	a1,s0,-20
    80004eec:	4501                	li	a0,0
    80004eee:	d15ff0ef          	jal	80004c02 <argfd>
    return -1;
    80004ef2:	57fd                	li	a5,-1
  if (argfd(0, &fd, &f) < 0)
    80004ef4:	02054163          	bltz	a0,80004f16 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80004ef8:	a55fc0ef          	jal	8000194c <myproc>
    80004efc:	fec42783          	lw	a5,-20(s0)
    80004f00:	078e                	slli	a5,a5,0x3
    80004f02:	0d078793          	addi	a5,a5,208
    80004f06:	953e                	add	a0,a0,a5
    80004f08:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004f0c:	fe043503          	ld	a0,-32(s0)
    80004f10:	af4ff0ef          	jal	80004204 <fileclose>
  return 0;
    80004f14:	4781                	li	a5,0
}
    80004f16:	853e                	mv	a0,a5
    80004f18:	60e2                	ld	ra,24(sp)
    80004f1a:	6442                	ld	s0,16(sp)
    80004f1c:	6105                	addi	sp,sp,32
    80004f1e:	8082                	ret

0000000080004f20 <sys_fstat>:
{
    80004f20:	1101                	addi	sp,sp,-32
    80004f22:	ec06                	sd	ra,24(sp)
    80004f24:	e822                	sd	s0,16(sp)
    80004f26:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004f28:	fe040593          	addi	a1,s0,-32
    80004f2c:	4505                	li	a0,1
    80004f2e:	983fd0ef          	jal	800028b0 <argaddr>
  if (argfd(0, 0, &f) < 0)
    80004f32:	fe840613          	addi	a2,s0,-24
    80004f36:	4581                	li	a1,0
    80004f38:	4501                	li	a0,0
    80004f3a:	cc9ff0ef          	jal	80004c02 <argfd>
    80004f3e:	87aa                	mv	a5,a0
    return -1;
    80004f40:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004f42:	0007c863          	bltz	a5,80004f52 <sys_fstat+0x32>
  return filestat(f, st);
    80004f46:	fe043583          	ld	a1,-32(s0)
    80004f4a:	fe843503          	ld	a0,-24(s0)
    80004f4e:	b78ff0ef          	jal	800042c6 <filestat>
}
    80004f52:	60e2                	ld	ra,24(sp)
    80004f54:	6442                	ld	s0,16(sp)
    80004f56:	6105                	addi	sp,sp,32
    80004f58:	8082                	ret

0000000080004f5a <sys_link>:
{
    80004f5a:	7169                	addi	sp,sp,-304
    80004f5c:	f606                	sd	ra,296(sp)
    80004f5e:	f222                	sd	s0,288(sp)
    80004f60:	1a00                	addi	s0,sp,304
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f62:	08000613          	li	a2,128
    80004f66:	ed040593          	addi	a1,s0,-304
    80004f6a:	4501                	li	a0,0
    80004f6c:	961fd0ef          	jal	800028cc <argstr>
    return -1;
    80004f70:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f72:	10054163          	bltz	a0,80005074 <sys_link+0x11a>
    80004f76:	08000613          	li	a2,128
    80004f7a:	f5040593          	addi	a1,s0,-176
    80004f7e:	4505                	li	a0,1
    80004f80:	94dfd0ef          	jal	800028cc <argstr>
    return -1;
    80004f84:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004f86:	0e054763          	bltz	a0,80005074 <sys_link+0x11a>
    80004f8a:	ee26                	sd	s1,280(sp)
  begin_op();
    80004f8c:	dbffe0ef          	jal	80003d4a <begin_op>
  if ((ip = namei(old)) == 0) {
    80004f90:	ed040513          	addi	a0,s0,-304
    80004f94:	bd9fe0ef          	jal	80003b6c <namei>
    80004f98:	84aa                	mv	s1,a0
    80004f9a:	cd35                	beqz	a0,80005016 <sys_link+0xbc>
  ilock(ip);
    80004f9c:	b36fe0ef          	jal	800032d2 <ilock>
  if (ip->type == T_DIR) {
    80004fa0:	04449703          	lh	a4,68(s1)
    80004fa4:	4785                	li	a5,1
    80004fa6:	06f70d63          	beq	a4,a5,80005020 <sys_link+0xc6>
  if (ip->nlink >= NLINK_MAX) {
    80004faa:	04a49783          	lh	a5,74(s1)
    80004fae:	6721                	lui	a4,0x8
    80004fb0:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    80004fb2:	06e78f63          	beq	a5,a4,80005030 <sys_link+0xd6>
    80004fb6:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004fb8:	2785                	addiw	a5,a5,1
    80004fba:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004fbe:	8526                	mv	a0,s1
    80004fc0:	a5efe0ef          	jal	8000321e <iupdate>
  iunlock(ip);
    80004fc4:	8526                	mv	a0,s1
    80004fc6:	bbafe0ef          	jal	80003380 <iunlock>
  if ((dp = nameiparent(new, name)) == 0)
    80004fca:	fd040593          	addi	a1,s0,-48
    80004fce:	f5040513          	addi	a0,s0,-176
    80004fd2:	bb5fe0ef          	jal	80003b86 <nameiparent>
    80004fd6:	892a                	mv	s2,a0
    80004fd8:	c93d                	beqz	a0,8000504e <sys_link+0xf4>
  ilock(dp);
    80004fda:	af8fe0ef          	jal	800032d2 <ilock>
  if (dp->nlink == 0) {
    80004fde:	04a91783          	lh	a5,74(s2)
    80004fe2:	cfb9                	beqz	a5,80005040 <sys_link+0xe6>
  if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80004fe4:	854a                	mv	a0,s2
    80004fe6:	00092703          	lw	a4,0(s2)
    80004fea:	409c                	lw	a5,0(s1)
    80004fec:	04f71e63          	bne	a4,a5,80005048 <sys_link+0xee>
    80004ff0:	40d0                	lw	a2,4(s1)
    80004ff2:	fd040593          	addi	a1,s0,-48
    80004ff6:	acdfe0ef          	jal	80003ac2 <dirlink>
    80004ffa:	04054763          	bltz	a0,80005048 <sys_link+0xee>
  iunlockput(dp);
    80004ffe:	854a                	mv	a0,s2
    80005000:	d26fe0ef          	jal	80003526 <iunlockput>
  iput(ip);
    80005004:	8526                	mv	a0,s1
    80005006:	c4efe0ef          	jal	80003454 <iput>
  end_op();
    8000500a:	dcdfe0ef          	jal	80003dd6 <end_op>
  return 0;
    8000500e:	4781                	li	a5,0
    80005010:	64f2                	ld	s1,280(sp)
    80005012:	6952                	ld	s2,272(sp)
    80005014:	a085                	j	80005074 <sys_link+0x11a>
    end_op();
    80005016:	dc1fe0ef          	jal	80003dd6 <end_op>
    return -1;
    8000501a:	57fd                	li	a5,-1
    8000501c:	64f2                	ld	s1,280(sp)
    8000501e:	a899                	j	80005074 <sys_link+0x11a>
    iunlockput(ip);
    80005020:	8526                	mv	a0,s1
    80005022:	d04fe0ef          	jal	80003526 <iunlockput>
    end_op();
    80005026:	db1fe0ef          	jal	80003dd6 <end_op>
    return -1;
    8000502a:	57fd                	li	a5,-1
    8000502c:	64f2                	ld	s1,280(sp)
    8000502e:	a099                	j	80005074 <sys_link+0x11a>
    iunlockput(ip);
    80005030:	8526                	mv	a0,s1
    80005032:	cf4fe0ef          	jal	80003526 <iunlockput>
    end_op();
    80005036:	da1fe0ef          	jal	80003dd6 <end_op>
    return -1;
    8000503a:	57fd                	li	a5,-1
    8000503c:	64f2                	ld	s1,280(sp)
    8000503e:	a81d                	j	80005074 <sys_link+0x11a>
    iunlockput(dp);
    80005040:	854a                	mv	a0,s2
    80005042:	ce4fe0ef          	jal	80003526 <iunlockput>
    goto bad;
    80005046:	a021                	j	8000504e <sys_link+0xf4>
    iunlockput(dp);
    80005048:	854a                	mv	a0,s2
    8000504a:	cdcfe0ef          	jal	80003526 <iunlockput>
  ilock(ip);
    8000504e:	8526                	mv	a0,s1
    80005050:	a82fe0ef          	jal	800032d2 <ilock>
  ip->nlink--;
    80005054:	04a4d783          	lhu	a5,74(s1)
    80005058:	37fd                	addiw	a5,a5,-1
    8000505a:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    8000505e:	8526                	mv	a0,s1
    80005060:	9befe0ef          	jal	8000321e <iupdate>
  iunlockput(ip);
    80005064:	8526                	mv	a0,s1
    80005066:	cc0fe0ef          	jal	80003526 <iunlockput>
  end_op();
    8000506a:	d6dfe0ef          	jal	80003dd6 <end_op>
  return -1;
    8000506e:	57fd                	li	a5,-1
    80005070:	64f2                	ld	s1,280(sp)
    80005072:	6952                	ld	s2,272(sp)
}
    80005074:	853e                	mv	a0,a5
    80005076:	70b2                	ld	ra,296(sp)
    80005078:	7412                	ld	s0,288(sp)
    8000507a:	6155                	addi	sp,sp,304
    8000507c:	8082                	ret

000000008000507e <sys_unlink>:
{
    8000507e:	7151                	addi	sp,sp,-240
    80005080:	f586                	sd	ra,232(sp)
    80005082:	f1a2                	sd	s0,224(sp)
    80005084:	1980                	addi	s0,sp,240
  if (argstr(0, path, MAXPATH) < 0)
    80005086:	08000613          	li	a2,128
    8000508a:	f3040593          	addi	a1,s0,-208
    8000508e:	4501                	li	a0,0
    80005090:	83dfd0ef          	jal	800028cc <argstr>
    80005094:	14054d63          	bltz	a0,800051ee <sys_unlink+0x170>
    80005098:	eda6                	sd	s1,216(sp)
  begin_op();
    8000509a:	cb1fe0ef          	jal	80003d4a <begin_op>
  if ((dp = nameiparent(path, name)) == 0) {
    8000509e:	fb040593          	addi	a1,s0,-80
    800050a2:	f3040513          	addi	a0,s0,-208
    800050a6:	ae1fe0ef          	jal	80003b86 <nameiparent>
    800050aa:	84aa                	mv	s1,a0
    800050ac:	c955                	beqz	a0,80005160 <sys_unlink+0xe2>
  ilock(dp);
    800050ae:	a24fe0ef          	jal	800032d2 <ilock>
  if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    800050b2:	00002597          	auipc	a1,0x2
    800050b6:	52e58593          	addi	a1,a1,1326 # 800075e0 <etext+0x5e0>
    800050ba:	fb040513          	addi	a0,s0,-80
    800050be:	fe6fe0ef          	jal	800038a4 <namecmp>
    800050c2:	10050b63          	beqz	a0,800051d8 <sys_unlink+0x15a>
    800050c6:	00002597          	auipc	a1,0x2
    800050ca:	52258593          	addi	a1,a1,1314 # 800075e8 <etext+0x5e8>
    800050ce:	fb040513          	addi	a0,s0,-80
    800050d2:	fd2fe0ef          	jal	800038a4 <namecmp>
    800050d6:	10050163          	beqz	a0,800051d8 <sys_unlink+0x15a>
    800050da:	e9ca                	sd	s2,208(sp)
  if ((ip = dirlookup(dp, name, &off)) == 0)
    800050dc:	f2c40613          	addi	a2,s0,-212
    800050e0:	fb040593          	addi	a1,s0,-80
    800050e4:	8526                	mv	a0,s1
    800050e6:	fd4fe0ef          	jal	800038ba <dirlookup>
    800050ea:	892a                	mv	s2,a0
    800050ec:	0e050563          	beqz	a0,800051d6 <sys_unlink+0x158>
    800050f0:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    800050f2:	9e0fe0ef          	jal	800032d2 <ilock>
  if (ip->nlink < 1)
    800050f6:	04a91783          	lh	a5,74(s2)
    800050fa:	06f05863          	blez	a5,8000516a <sys_unlink+0xec>
  if (ip->type == T_DIR && !isdirempty(ip)) {
    800050fe:	04491703          	lh	a4,68(s2)
    80005102:	4785                	li	a5,1
    80005104:	06f70963          	beq	a4,a5,80005176 <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    80005108:	fc040993          	addi	s3,s0,-64
    8000510c:	4641                	li	a2,16
    8000510e:	4581                	li	a1,0
    80005110:	854e                	mv	a0,s3
    80005112:	bd7fb0ef          	jal	80000ce8 <memset>
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005116:	4741                	li	a4,16
    80005118:	f2c42683          	lw	a3,-212(s0)
    8000511c:	864e                	mv	a2,s3
    8000511e:	4581                	li	a1,0
    80005120:	8526                	mv	a0,s1
    80005122:	e7cfe0ef          	jal	8000379e <writei>
    80005126:	47c1                	li	a5,16
    80005128:	08f51863          	bne	a0,a5,800051b8 <sys_unlink+0x13a>
  if (ip->type == T_DIR) {
    8000512c:	04491703          	lh	a4,68(s2)
    80005130:	4785                	li	a5,1
    80005132:	08f70963          	beq	a4,a5,800051c4 <sys_unlink+0x146>
  iunlockput(dp);
    80005136:	8526                	mv	a0,s1
    80005138:	beefe0ef          	jal	80003526 <iunlockput>
  ip->nlink--;
    8000513c:	04a95783          	lhu	a5,74(s2)
    80005140:	37fd                	addiw	a5,a5,-1
    80005142:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80005146:	854a                	mv	a0,s2
    80005148:	8d6fe0ef          	jal	8000321e <iupdate>
  iunlockput(ip);
    8000514c:	854a                	mv	a0,s2
    8000514e:	bd8fe0ef          	jal	80003526 <iunlockput>
  end_op();
    80005152:	c85fe0ef          	jal	80003dd6 <end_op>
  return 0;
    80005156:	4501                	li	a0,0
    80005158:	64ee                	ld	s1,216(sp)
    8000515a:	694e                	ld	s2,208(sp)
    8000515c:	69ae                	ld	s3,200(sp)
    8000515e:	a061                	j	800051e6 <sys_unlink+0x168>
    end_op();
    80005160:	c77fe0ef          	jal	80003dd6 <end_op>
    return -1;
    80005164:	557d                	li	a0,-1
    80005166:	64ee                	ld	s1,216(sp)
    80005168:	a8bd                	j	800051e6 <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    8000516a:	00002517          	auipc	a0,0x2
    8000516e:	48650513          	addi	a0,a0,1158 # 800075f0 <etext+0x5f0>
    80005172:	ec2fb0ef          	jal	80000834 <panic>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80005176:	04c92703          	lw	a4,76(s2)
    8000517a:	02000793          	li	a5,32
    8000517e:	f8e7f5e3          	bgeu	a5,a4,80005108 <sys_unlink+0x8a>
    80005182:	89be                	mv	s3,a5
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005184:	4741                	li	a4,16
    80005186:	86ce                	mv	a3,s3
    80005188:	f1840613          	addi	a2,s0,-232
    8000518c:	4581                	li	a1,0
    8000518e:	854a                	mv	a0,s2
    80005190:	d1cfe0ef          	jal	800036ac <readi>
    80005194:	47c1                	li	a5,16
    80005196:	00f51b63          	bne	a0,a5,800051ac <sys_unlink+0x12e>
    if (de.inum != 0)
    8000519a:	f1845783          	lhu	a5,-232(s0)
    8000519e:	ebb1                	bnez	a5,800051f2 <sys_unlink+0x174>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    800051a0:	29c1                	addiw	s3,s3,16
    800051a2:	04c92783          	lw	a5,76(s2)
    800051a6:	fcf9efe3          	bltu	s3,a5,80005184 <sys_unlink+0x106>
    800051aa:	bfb9                	j	80005108 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    800051ac:	00002517          	auipc	a0,0x2
    800051b0:	45c50513          	addi	a0,a0,1116 # 80007608 <etext+0x608>
    800051b4:	e80fb0ef          	jal	80000834 <panic>
    panic("unlink: writei");
    800051b8:	00002517          	auipc	a0,0x2
    800051bc:	46850513          	addi	a0,a0,1128 # 80007620 <etext+0x620>
    800051c0:	e74fb0ef          	jal	80000834 <panic>
    dp->nlink--;
    800051c4:	04a4d783          	lhu	a5,74(s1)
    800051c8:	37fd                	addiw	a5,a5,-1
    800051ca:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800051ce:	8526                	mv	a0,s1
    800051d0:	84efe0ef          	jal	8000321e <iupdate>
    800051d4:	b78d                	j	80005136 <sys_unlink+0xb8>
    800051d6:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800051d8:	8526                	mv	a0,s1
    800051da:	b4cfe0ef          	jal	80003526 <iunlockput>
  end_op();
    800051de:	bf9fe0ef          	jal	80003dd6 <end_op>
  return -1;
    800051e2:	557d                	li	a0,-1
    800051e4:	64ee                	ld	s1,216(sp)
}
    800051e6:	70ae                	ld	ra,232(sp)
    800051e8:	740e                	ld	s0,224(sp)
    800051ea:	616d                	addi	sp,sp,240
    800051ec:	8082                	ret
    return -1;
    800051ee:	557d                	li	a0,-1
    800051f0:	bfdd                	j	800051e6 <sys_unlink+0x168>
    iunlockput(ip);
    800051f2:	854a                	mv	a0,s2
    800051f4:	b32fe0ef          	jal	80003526 <iunlockput>
    goto bad;
    800051f8:	694e                	ld	s2,208(sp)
    800051fa:	69ae                	ld	s3,200(sp)
    800051fc:	bff1                	j	800051d8 <sys_unlink+0x15a>

00000000800051fe <sys_open>:

uint64
sys_open(void)
{
    800051fe:	7131                	addi	sp,sp,-192
    80005200:	fd06                	sd	ra,184(sp)
    80005202:	f922                	sd	s0,176(sp)
    80005204:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80005206:	f4c40593          	addi	a1,s0,-180
    8000520a:	4505                	li	a0,1
    8000520c:	e88fd0ef          	jal	80002894 <argint>
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005210:	08000613          	li	a2,128
    80005214:	f5040593          	addi	a1,s0,-176
    80005218:	4501                	li	a0,0
    8000521a:	eb2fd0ef          	jal	800028cc <argstr>
    8000521e:	87aa                	mv	a5,a0
    return -1;
    80005220:	557d                	li	a0,-1
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005222:	0a07c363          	bltz	a5,800052c8 <sys_open+0xca>
    80005226:	f526                	sd	s1,168(sp)

  begin_op();
    80005228:	b23fe0ef          	jal	80003d4a <begin_op>

  if (omode & O_CREATE) {
    8000522c:	f4c42783          	lw	a5,-180(s0)
    80005230:	2007f793          	andi	a5,a5,512
    80005234:	c3dd                	beqz	a5,800052da <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    80005236:	4681                	li	a3,0
    80005238:	4601                	li	a2,0
    8000523a:	4589                	li	a1,2
    8000523c:	f5040513          	addi	a0,s0,-176
    80005240:	a5dff0ef          	jal	80004c9c <create>
    80005244:	84aa                	mv	s1,a0
    if (ip == 0) {
    80005246:	c549                	beqz	a0,800052d0 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if (ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)) {
    80005248:	04449703          	lh	a4,68(s1)
    8000524c:	478d                	li	a5,3
    8000524e:	00f71763          	bne	a4,a5,8000525c <sys_open+0x5e>
    80005252:	0464d703          	lhu	a4,70(s1)
    80005256:	47a5                	li	a5,9
    80005258:	0ae7ee63          	bltu	a5,a4,80005314 <sys_open+0x116>
    8000525c:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if ((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0) {
    8000525e:	f03fe0ef          	jal	80004160 <filealloc>
    80005262:	892a                	mv	s2,a0
    80005264:	c561                	beqz	a0,8000532c <sys_open+0x12e>
    80005266:	ed4e                	sd	s3,152(sp)
    80005268:	9f5ff0ef          	jal	80004c5c <fdalloc>
    8000526c:	89aa                	mv	s3,a0
    8000526e:	0a054b63          	bltz	a0,80005324 <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if (ip->type == T_DEVICE) {
    80005272:	04449703          	lh	a4,68(s1)
    80005276:	478d                	li	a5,3
    80005278:	0cf70363          	beq	a4,a5,8000533e <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    8000527c:	4789                	li	a5,2
    8000527e:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80005282:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80005286:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    8000528a:	f4c42783          	lw	a5,-180(s0)
    8000528e:	0017f713          	andi	a4,a5,1
    80005292:	00174713          	xori	a4,a4,1
    80005296:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000529a:	0037f713          	andi	a4,a5,3
    8000529e:	00e03733          	snez	a4,a4
    800052a2:	00e904a3          	sb	a4,9(s2)

  if ((omode & O_TRUNC) && ip->type == T_FILE) {
    800052a6:	4007f793          	andi	a5,a5,1024
    800052aa:	c791                	beqz	a5,800052b6 <sys_open+0xb8>
    800052ac:	04449703          	lh	a4,68(s1)
    800052b0:	4789                	li	a5,2
    800052b2:	08f70d63          	beq	a4,a5,8000534c <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    800052b6:	8526                	mv	a0,s1
    800052b8:	8c8fe0ef          	jal	80003380 <iunlock>
  end_op();
    800052bc:	b1bfe0ef          	jal	80003dd6 <end_op>

  return fd;
    800052c0:	854e                	mv	a0,s3
    800052c2:	74aa                	ld	s1,168(sp)
    800052c4:	790a                	ld	s2,160(sp)
    800052c6:	69ea                	ld	s3,152(sp)
}
    800052c8:	70ea                	ld	ra,184(sp)
    800052ca:	744a                	ld	s0,176(sp)
    800052cc:	6129                	addi	sp,sp,192
    800052ce:	8082                	ret
      end_op();
    800052d0:	b07fe0ef          	jal	80003dd6 <end_op>
      return -1;
    800052d4:	557d                	li	a0,-1
    800052d6:	74aa                	ld	s1,168(sp)
    800052d8:	bfc5                	j	800052c8 <sys_open+0xca>
    if ((ip = namei(path)) == 0) {
    800052da:	f5040513          	addi	a0,s0,-176
    800052de:	88ffe0ef          	jal	80003b6c <namei>
    800052e2:	84aa                	mv	s1,a0
    800052e4:	c11d                	beqz	a0,8000530a <sys_open+0x10c>
    ilock(ip);
    800052e6:	fedfd0ef          	jal	800032d2 <ilock>
    if (ip->type == T_DIR && omode != O_RDONLY) {
    800052ea:	04449703          	lh	a4,68(s1)
    800052ee:	4785                	li	a5,1
    800052f0:	f4f71ce3          	bne	a4,a5,80005248 <sys_open+0x4a>
    800052f4:	f4c42783          	lw	a5,-180(s0)
    800052f8:	d3b5                	beqz	a5,8000525c <sys_open+0x5e>
      iunlockput(ip);
    800052fa:	8526                	mv	a0,s1
    800052fc:	a2afe0ef          	jal	80003526 <iunlockput>
      end_op();
    80005300:	ad7fe0ef          	jal	80003dd6 <end_op>
      return -1;
    80005304:	557d                	li	a0,-1
    80005306:	74aa                	ld	s1,168(sp)
    80005308:	b7c1                	j	800052c8 <sys_open+0xca>
      end_op();
    8000530a:	acdfe0ef          	jal	80003dd6 <end_op>
      return -1;
    8000530e:	557d                	li	a0,-1
    80005310:	74aa                	ld	s1,168(sp)
    80005312:	bf5d                	j	800052c8 <sys_open+0xca>
    iunlockput(ip);
    80005314:	8526                	mv	a0,s1
    80005316:	a10fe0ef          	jal	80003526 <iunlockput>
    end_op();
    8000531a:	abdfe0ef          	jal	80003dd6 <end_op>
    return -1;
    8000531e:	557d                	li	a0,-1
    80005320:	74aa                	ld	s1,168(sp)
    80005322:	b75d                	j	800052c8 <sys_open+0xca>
      fileclose(f);
    80005324:	854a                	mv	a0,s2
    80005326:	edffe0ef          	jal	80004204 <fileclose>
    8000532a:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    8000532c:	8526                	mv	a0,s1
    8000532e:	9f8fe0ef          	jal	80003526 <iunlockput>
    end_op();
    80005332:	aa5fe0ef          	jal	80003dd6 <end_op>
    return -1;
    80005336:	557d                	li	a0,-1
    80005338:	74aa                	ld	s1,168(sp)
    8000533a:	790a                	ld	s2,160(sp)
    8000533c:	b771                	j	800052c8 <sys_open+0xca>
    f->type = FD_DEVICE;
    8000533e:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    80005342:	04649783          	lh	a5,70(s1)
    80005346:	02f91223          	sh	a5,36(s2)
    8000534a:	bf35                	j	80005286 <sys_open+0x88>
    itrunc(ip);
    8000534c:	8526                	mv	a0,s1
    8000534e:	872fe0ef          	jal	800033c0 <itrunc>
    80005352:	b795                	j	800052b6 <sys_open+0xb8>

0000000080005354 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005354:	7175                	addi	sp,sp,-144
    80005356:	e506                	sd	ra,136(sp)
    80005358:	e122                	sd	s0,128(sp)
    8000535a:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000535c:	9effe0ef          	jal	80003d4a <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0) {
    80005360:	08000613          	li	a2,128
    80005364:	f7040593          	addi	a1,s0,-144
    80005368:	4501                	li	a0,0
    8000536a:	d62fd0ef          	jal	800028cc <argstr>
    8000536e:	02054363          	bltz	a0,80005394 <sys_mkdir+0x40>
    80005372:	4681                	li	a3,0
    80005374:	4601                	li	a2,0
    80005376:	4585                	li	a1,1
    80005378:	f7040513          	addi	a0,s0,-144
    8000537c:	921ff0ef          	jal	80004c9c <create>
    80005380:	c911                	beqz	a0,80005394 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005382:	9a4fe0ef          	jal	80003526 <iunlockput>
  end_op();
    80005386:	a51fe0ef          	jal	80003dd6 <end_op>
  return 0;
    8000538a:	4501                	li	a0,0
}
    8000538c:	60aa                	ld	ra,136(sp)
    8000538e:	640a                	ld	s0,128(sp)
    80005390:	6149                	addi	sp,sp,144
    80005392:	8082                	ret
    end_op();
    80005394:	a43fe0ef          	jal	80003dd6 <end_op>
    return -1;
    80005398:	557d                	li	a0,-1
    8000539a:	bfcd                	j	8000538c <sys_mkdir+0x38>

000000008000539c <sys_mknod>:

uint64
sys_mknod(void)
{
    8000539c:	7135                	addi	sp,sp,-160
    8000539e:	ed06                	sd	ra,152(sp)
    800053a0:	e922                	sd	s0,144(sp)
    800053a2:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    800053a4:	9a7fe0ef          	jal	80003d4a <begin_op>
  argint(1, &major);
    800053a8:	f6c40593          	addi	a1,s0,-148
    800053ac:	4505                	li	a0,1
    800053ae:	ce6fd0ef          	jal	80002894 <argint>
  argint(2, &minor);
    800053b2:	f6840593          	addi	a1,s0,-152
    800053b6:	4509                	li	a0,2
    800053b8:	cdcfd0ef          	jal	80002894 <argint>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    800053bc:	08000613          	li	a2,128
    800053c0:	f7040593          	addi	a1,s0,-144
    800053c4:	4501                	li	a0,0
    800053c6:	d06fd0ef          	jal	800028cc <argstr>
    800053ca:	02054563          	bltz	a0,800053f4 <sys_mknod+0x58>
      (ip = create(path, T_DEVICE, major, minor)) == 0) {
    800053ce:	f6841683          	lh	a3,-152(s0)
    800053d2:	f6c41603          	lh	a2,-148(s0)
    800053d6:	458d                	li	a1,3
    800053d8:	f7040513          	addi	a0,s0,-144
    800053dc:	8c1ff0ef          	jal	80004c9c <create>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    800053e0:	c911                	beqz	a0,800053f4 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800053e2:	944fe0ef          	jal	80003526 <iunlockput>
  end_op();
    800053e6:	9f1fe0ef          	jal	80003dd6 <end_op>
  return 0;
    800053ea:	4501                	li	a0,0
}
    800053ec:	60ea                	ld	ra,152(sp)
    800053ee:	644a                	ld	s0,144(sp)
    800053f0:	610d                	addi	sp,sp,160
    800053f2:	8082                	ret
    end_op();
    800053f4:	9e3fe0ef          	jal	80003dd6 <end_op>
    return -1;
    800053f8:	557d                	li	a0,-1
    800053fa:	bfcd                	j	800053ec <sys_mknod+0x50>

00000000800053fc <sys_chdir>:

uint64
sys_chdir(void)
{
    800053fc:	7135                	addi	sp,sp,-160
    800053fe:	ed06                	sd	ra,152(sp)
    80005400:	e922                	sd	s0,144(sp)
    80005402:	e14a                	sd	s2,128(sp)
    80005404:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005406:	d46fc0ef          	jal	8000194c <myproc>
    8000540a:	892a                	mv	s2,a0

  begin_op();
    8000540c:	93ffe0ef          	jal	80003d4a <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0) {
    80005410:	08000613          	li	a2,128
    80005414:	f6040593          	addi	a1,s0,-160
    80005418:	4501                	li	a0,0
    8000541a:	cb2fd0ef          	jal	800028cc <argstr>
    8000541e:	04054363          	bltz	a0,80005464 <sys_chdir+0x68>
    80005422:	e526                	sd	s1,136(sp)
    80005424:	f6040513          	addi	a0,s0,-160
    80005428:	f44fe0ef          	jal	80003b6c <namei>
    8000542c:	84aa                	mv	s1,a0
    8000542e:	c915                	beqz	a0,80005462 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005430:	ea3fd0ef          	jal	800032d2 <ilock>
  if (ip->type != T_DIR) {
    80005434:	04449703          	lh	a4,68(s1)
    80005438:	4785                	li	a5,1
    8000543a:	02f71963          	bne	a4,a5,8000546c <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    8000543e:	8526                	mv	a0,s1
    80005440:	f41fd0ef          	jal	80003380 <iunlock>
  iput(p->cwd);
    80005444:	15093503          	ld	a0,336(s2)
    80005448:	80cfe0ef          	jal	80003454 <iput>
  end_op();
    8000544c:	98bfe0ef          	jal	80003dd6 <end_op>
  p->cwd = ip;
    80005450:	14993823          	sd	s1,336(s2)
  return 0;
    80005454:	4501                	li	a0,0
    80005456:	64aa                	ld	s1,136(sp)
}
    80005458:	60ea                	ld	ra,152(sp)
    8000545a:	644a                	ld	s0,144(sp)
    8000545c:	690a                	ld	s2,128(sp)
    8000545e:	610d                	addi	sp,sp,160
    80005460:	8082                	ret
    80005462:	64aa                	ld	s1,136(sp)
    end_op();
    80005464:	973fe0ef          	jal	80003dd6 <end_op>
    return -1;
    80005468:	557d                	li	a0,-1
    8000546a:	b7fd                	j	80005458 <sys_chdir+0x5c>
    iunlockput(ip);
    8000546c:	8526                	mv	a0,s1
    8000546e:	8b8fe0ef          	jal	80003526 <iunlockput>
    end_op();
    80005472:	965fe0ef          	jal	80003dd6 <end_op>
    return -1;
    80005476:	557d                	li	a0,-1
    80005478:	64aa                	ld	s1,136(sp)
    8000547a:	bff9                	j	80005458 <sys_chdir+0x5c>

000000008000547c <sys_exec>:

uint64
sys_exec(void)
{
    8000547c:	7105                	addi	sp,sp,-480
    8000547e:	ef86                	sd	ra,472(sp)
    80005480:	eba2                	sd	s0,464(sp)
    80005482:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005484:	e2840593          	addi	a1,s0,-472
    80005488:	4505                	li	a0,1
    8000548a:	c26fd0ef          	jal	800028b0 <argaddr>
  if (argstr(0, path, MAXPATH) < 0) {
    8000548e:	08000613          	li	a2,128
    80005492:	f3040593          	addi	a1,s0,-208
    80005496:	4501                	li	a0,0
    80005498:	c34fd0ef          	jal	800028cc <argstr>
    8000549c:	87aa                	mv	a5,a0
    return -1;
    8000549e:	557d                	li	a0,-1
  if (argstr(0, path, MAXPATH) < 0) {
    800054a0:	0e07c063          	bltz	a5,80005580 <sys_exec+0x104>
    800054a4:	e7a6                	sd	s1,456(sp)
    800054a6:	e3ca                	sd	s2,448(sp)
    800054a8:	ff4e                	sd	s3,440(sp)
    800054aa:	fb52                	sd	s4,432(sp)
    800054ac:	f756                	sd	s5,424(sp)
    800054ae:	f35a                	sd	s6,416(sp)
    800054b0:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    800054b2:	e3040a13          	addi	s4,s0,-464
    800054b6:	10000613          	li	a2,256
    800054ba:	4581                	li	a1,0
    800054bc:	8552                	mv	a0,s4
    800054be:	82bfb0ef          	jal	80000ce8 <memset>
  for (i = 0;; i++) {
    if (i >= NELEM(argv)) {
    800054c2:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    800054c4:	89d2                	mv	s3,s4
    800054c6:	4901                	li	s2,0
      goto bad;
    }
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    800054c8:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if (argv[i] == 0)
      goto bad;
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    800054cc:	6b05                	lui	s6,0x1
    if (i >= NELEM(argv)) {
    800054ce:	02000b93          	li	s7,32
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    800054d2:	00391513          	slli	a0,s2,0x3
    800054d6:	85d6                	mv	a1,s5
    800054d8:	e2843783          	ld	a5,-472(s0)
    800054dc:	953e                	add	a0,a0,a5
    800054de:	b2afd0ef          	jal	80002808 <fetchaddr>
    800054e2:	02054663          	bltz	a0,8000550e <sys_exec+0x92>
    if (uarg == 0) {
    800054e6:	e2043783          	ld	a5,-480(s0)
    800054ea:	c7a1                	beqz	a5,80005532 <sys_exec+0xb6>
    argv[i] = kalloc();
    800054ec:	e62fb0ef          	jal	80000b4e <kalloc>
    800054f0:	85aa                	mv	a1,a0
    800054f2:	00a9b023          	sd	a0,0(s3)
    if (argv[i] == 0)
    800054f6:	cd01                	beqz	a0,8000550e <sys_exec+0x92>
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    800054f8:	865a                	mv	a2,s6
    800054fa:	e2043503          	ld	a0,-480(s0)
    800054fe:	b54fd0ef          	jal	80002852 <fetchstr>
    80005502:	00054663          	bltz	a0,8000550e <sys_exec+0x92>
    if (i >= NELEM(argv)) {
    80005506:	0905                	addi	s2,s2,1
    80005508:	09a1                	addi	s3,s3,8
    8000550a:	fd7914e3          	bne	s2,s7,800054d2 <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

bad:
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000550e:	100a0a13          	addi	s4,s4,256
    80005512:	6088                	ld	a0,0(s1)
    80005514:	cd31                	beqz	a0,80005570 <sys_exec+0xf4>
    kfree(argv[i]);
    80005516:	d50fb0ef          	jal	80000a66 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000551a:	04a1                	addi	s1,s1,8
    8000551c:	ff449be3          	bne	s1,s4,80005512 <sys_exec+0x96>
  return -1;
    80005520:	557d                	li	a0,-1
    80005522:	64be                	ld	s1,456(sp)
    80005524:	691e                	ld	s2,448(sp)
    80005526:	79fa                	ld	s3,440(sp)
    80005528:	7a5a                	ld	s4,432(sp)
    8000552a:	7aba                	ld	s5,424(sp)
    8000552c:	7b1a                	ld	s6,416(sp)
    8000552e:	6bfa                	ld	s7,408(sp)
    80005530:	a881                	j	80005580 <sys_exec+0x104>
      argv[i] = 0;
    80005532:	0009079b          	sext.w	a5,s2
    80005536:	e3040593          	addi	a1,s0,-464
    8000553a:	078e                	slli	a5,a5,0x3
    8000553c:	97ae                	add	a5,a5,a1
    8000553e:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    80005542:	f3040513          	addi	a0,s0,-208
    80005546:	b62ff0ef          	jal	800048a8 <kexec>
    8000554a:	892a                	mv	s2,a0
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000554c:	100a0a13          	addi	s4,s4,256
    80005550:	6088                	ld	a0,0(s1)
    80005552:	c511                	beqz	a0,8000555e <sys_exec+0xe2>
    kfree(argv[i]);
    80005554:	d12fb0ef          	jal	80000a66 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005558:	04a1                	addi	s1,s1,8
    8000555a:	ff449be3          	bne	s1,s4,80005550 <sys_exec+0xd4>
  return ret;
    8000555e:	854a                	mv	a0,s2
    80005560:	64be                	ld	s1,456(sp)
    80005562:	691e                	ld	s2,448(sp)
    80005564:	79fa                	ld	s3,440(sp)
    80005566:	7a5a                	ld	s4,432(sp)
    80005568:	7aba                	ld	s5,424(sp)
    8000556a:	7b1a                	ld	s6,416(sp)
    8000556c:	6bfa                	ld	s7,408(sp)
    8000556e:	a809                	j	80005580 <sys_exec+0x104>
  return -1;
    80005570:	557d                	li	a0,-1
    80005572:	64be                	ld	s1,456(sp)
    80005574:	691e                	ld	s2,448(sp)
    80005576:	79fa                	ld	s3,440(sp)
    80005578:	7a5a                	ld	s4,432(sp)
    8000557a:	7aba                	ld	s5,424(sp)
    8000557c:	7b1a                	ld	s6,416(sp)
    8000557e:	6bfa                	ld	s7,408(sp)
}
    80005580:	60fe                	ld	ra,472(sp)
    80005582:	645e                	ld	s0,464(sp)
    80005584:	613d                	addi	sp,sp,480
    80005586:	8082                	ret

0000000080005588 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005588:	7139                	addi	sp,sp,-64
    8000558a:	fc06                	sd	ra,56(sp)
    8000558c:	f822                	sd	s0,48(sp)
    8000558e:	f426                	sd	s1,40(sp)
    80005590:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005592:	bbafc0ef          	jal	8000194c <myproc>
    80005596:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005598:	fd840593          	addi	a1,s0,-40
    8000559c:	4501                	li	a0,0
    8000559e:	b12fd0ef          	jal	800028b0 <argaddr>
  if (pipealloc(&rf, &wf) < 0)
    800055a2:	fc840593          	addi	a1,s0,-56
    800055a6:	fd040513          	addi	a0,s0,-48
    800055aa:	f99fe0ef          	jal	80004542 <pipealloc>
    return -1;
    800055ae:	57fd                	li	a5,-1
  if (pipealloc(&rf, &wf) < 0)
    800055b0:	0a054963          	bltz	a0,80005662 <sys_pipe+0xda>
  fd0 = -1;
    800055b4:	fcf42223          	sw	a5,-60(s0)
  if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    800055b8:	fd043503          	ld	a0,-48(s0)
    800055bc:	ea0ff0ef          	jal	80004c5c <fdalloc>
    800055c0:	fca42223          	sw	a0,-60(s0)
    800055c4:	08054663          	bltz	a0,80005650 <sys_pipe+0xc8>
    800055c8:	fc843503          	ld	a0,-56(s0)
    800055cc:	e90ff0ef          	jal	80004c5c <fdalloc>
    800055d0:	fca42023          	sw	a0,-64(s0)
    800055d4:	06054463          	bltz	a0,8000563c <sys_pipe+0xb4>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    800055d8:	4711                	li	a4,4
    800055da:	fc440693          	addi	a3,s0,-60
    800055de:	fd843603          	ld	a2,-40(s0)
    800055e2:	64ac                	ld	a1,72(s1)
    800055e4:	68a8                	ld	a0,80(s1)
    800055e6:	fa1fb0ef          	jal	80001586 <copyout>
    800055ea:	00054f63          	bltz	a0,80005608 <sys_pipe+0x80>
      copyout(p->pagetable, p->sz, fdarray + sizeof(fd0), (char *)&fd1,
    800055ee:	4711                	li	a4,4
    800055f0:	fc040693          	addi	a3,s0,-64
    800055f4:	fd843603          	ld	a2,-40(s0)
    800055f8:	963a                	add	a2,a2,a4
    800055fa:	64ac                	ld	a1,72(s1)
    800055fc:	68a8                	ld	a0,80(s1)
    800055fe:	f89fb0ef          	jal	80001586 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005602:	4781                	li	a5,0
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80005604:	04055f63          	bgez	a0,80005662 <sys_pipe+0xda>
    p->ofile[fd0] = 0;
    80005608:	fc442783          	lw	a5,-60(s0)
    8000560c:	078e                	slli	a5,a5,0x3
    8000560e:	0d078793          	addi	a5,a5,208
    80005612:	97a6                	add	a5,a5,s1
    80005614:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005618:	fc042783          	lw	a5,-64(s0)
    8000561c:	078e                	slli	a5,a5,0x3
    8000561e:	0d078793          	addi	a5,a5,208
    80005622:	94be                	add	s1,s1,a5
    80005624:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005628:	fd043503          	ld	a0,-48(s0)
    8000562c:	bd9fe0ef          	jal	80004204 <fileclose>
    fileclose(wf);
    80005630:	fc843503          	ld	a0,-56(s0)
    80005634:	bd1fe0ef          	jal	80004204 <fileclose>
    return -1;
    80005638:	57fd                	li	a5,-1
    8000563a:	a025                	j	80005662 <sys_pipe+0xda>
    if (fd0 >= 0)
    8000563c:	fc442783          	lw	a5,-60(s0)
    80005640:	0007c863          	bltz	a5,80005650 <sys_pipe+0xc8>
      p->ofile[fd0] = 0;
    80005644:	078e                	slli	a5,a5,0x3
    80005646:	0d078793          	addi	a5,a5,208
    8000564a:	97a6                	add	a5,a5,s1
    8000564c:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005650:	fd043503          	ld	a0,-48(s0)
    80005654:	bb1fe0ef          	jal	80004204 <fileclose>
    fileclose(wf);
    80005658:	fc843503          	ld	a0,-56(s0)
    8000565c:	ba9fe0ef          	jal	80004204 <fileclose>
    return -1;
    80005660:	57fd                	li	a5,-1
}
    80005662:	853e                	mv	a0,a5
    80005664:	70e2                	ld	ra,56(sp)
    80005666:	7442                	ld	s0,48(sp)
    80005668:	74a2                	ld	s1,40(sp)
    8000566a:	6121                	addi	sp,sp,64
    8000566c:	8082                	ret
	...

0000000080005670 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005670:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005672:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005674:	e80e                	sd	gp,16(sp)
        # sd tp, 24(sp)
        sd t0, 32(sp)
    80005676:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    80005678:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000567a:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000567c:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    8000567e:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005680:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005682:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005684:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005686:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    80005688:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000568a:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000568c:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    8000568e:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005690:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005692:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005694:	882fd0ef          	jal	80002716 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    80005698:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000569a:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000569c:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    8000569e:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    800056a0:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    800056a2:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    800056a4:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    800056a6:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    800056a8:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    800056aa:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    800056ac:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    800056ae:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    800056b0:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    800056b2:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    800056b4:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    800056b6:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    800056b8:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    800056ba:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    800056bc:	10200073          	sret
    800056c0:	0001                	nop
    800056c2:	00000013          	nop
    800056c6:	00000013          	nop
    800056ca:	00000013          	nop

00000000800056ce <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800056ce:	1141                	addi	sp,sp,-16
    800056d0:	e406                	sd	ra,8(sp)
    800056d2:	e022                	sd	s0,0(sp)
    800056d4:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(volatile uint32 *)(PLIC + UART0_IRQ * 4) = 1;
    800056d6:	0c000737          	lui	a4,0xc000
    800056da:	4785                	li	a5,1
    800056dc:	d71c                	sw	a5,40(a4)
  *(volatile uint32 *)(PLIC + VIRTIO0_IRQ * 4) = 1;
    800056de:	c35c                	sw	a5,4(a4)
}
    800056e0:	60a2                	ld	ra,8(sp)
    800056e2:	6402                	ld	s0,0(sp)
    800056e4:	0141                	addi	sp,sp,16
    800056e6:	8082                	ret

00000000800056e8 <plicinithart>:

void
plicinithart(void)
{
    800056e8:	1141                	addi	sp,sp,-16
    800056ea:	e406                	sd	ra,8(sp)
    800056ec:	e022                	sd	s0,0(sp)
    800056ee:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800056f0:	a28fc0ef          	jal	80001918 <cpuid>

  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(volatile uint32 *)PLIC_SENABLE(hart) =
    800056f4:	0085179b          	slliw	a5,a0,0x8
    800056f8:	0c002737          	lui	a4,0xc002
    800056fc:	08070713          	addi	a4,a4,128 # c002080 <_entry-0x73ffdf80>
    80005700:	97ba                	add	a5,a5,a4
    80005702:	40200713          	li	a4,1026
    80005706:	c398                	sw	a4,0(a5)
    (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);

  // set this hart's S-mode priority threshold to 0.
  *(volatile uint32 *)PLIC_SPRIORITY(hart) = 0;
    80005708:	00d5151b          	slliw	a0,a0,0xd
    8000570c:	0c2017b7          	lui	a5,0xc201
    80005710:	953e                	add	a0,a0,a5
    80005712:	00052023          	sw	zero,0(a0)
}
    80005716:	60a2                	ld	ra,8(sp)
    80005718:	6402                	ld	s0,0(sp)
    8000571a:	0141                	addi	sp,sp,16
    8000571c:	8082                	ret

000000008000571e <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000571e:	1141                	addi	sp,sp,-16
    80005720:	e406                	sd	ra,8(sp)
    80005722:	e022                	sd	s0,0(sp)
    80005724:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005726:	9f2fc0ef          	jal	80001918 <cpuid>
  int irq = *(volatile uint32 *)PLIC_SCLAIM(hart);
    8000572a:	00d5151b          	slliw	a0,a0,0xd
    8000572e:	0c2017b7          	lui	a5,0xc201
    80005732:	0791                	addi	a5,a5,4 # c201004 <_entry-0x73dfeffc>
    80005734:	953e                	add	a0,a0,a5
    80005736:	4108                	lw	a0,0(a0)
  return irq;
}
    80005738:	60a2                	ld	ra,8(sp)
    8000573a:	6402                	ld	s0,0(sp)
    8000573c:	0141                	addi	sp,sp,16
    8000573e:	8082                	ret

0000000080005740 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005740:	1101                	addi	sp,sp,-32
    80005742:	ec06                	sd	ra,24(sp)
    80005744:	e822                	sd	s0,16(sp)
    80005746:	e426                	sd	s1,8(sp)
    80005748:	1000                	addi	s0,sp,32
    8000574a:	84aa                	mv	s1,a0
  int hart = cpuid();
    8000574c:	9ccfc0ef          	jal	80001918 <cpuid>
  *(volatile uint32 *)PLIC_SCLAIM(hart) = irq;
    80005750:	00d5179b          	slliw	a5,a0,0xd
    80005754:	0c201737          	lui	a4,0xc201
    80005758:	0711                	addi	a4,a4,4 # c201004 <_entry-0x73dfeffc>
    8000575a:	97ba                	add	a5,a5,a4
    8000575c:	c384                	sw	s1,0(a5)
}
    8000575e:	60e2                	ld	ra,24(sp)
    80005760:	6442                	ld	s0,16(sp)
    80005762:	64a2                	ld	s1,8(sp)
    80005764:	6105                	addi	sp,sp,32
    80005766:	8082                	ret

0000000080005768 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005768:	1141                	addi	sp,sp,-16
    8000576a:	e406                	sd	ra,8(sp)
    8000576c:	e022                	sd	s0,0(sp)
    8000576e:	0800                	addi	s0,sp,16
  if (i >= NUM)
    80005770:	479d                	li	a5,7
    80005772:	04a7ca63          	blt	a5,a0,800057c6 <free_desc+0x5e>
    panic("free_desc 1");
  if (disk.free[i])
    80005776:	0001e797          	auipc	a5,0x1e
    8000577a:	fe278793          	addi	a5,a5,-30 # 80023758 <disk>
    8000577e:	97aa                	add	a5,a5,a0
    80005780:	0187c783          	lbu	a5,24(a5)
    80005784:	e7b9                	bnez	a5,800057d2 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005786:	00451693          	slli	a3,a0,0x4
    8000578a:	0001e797          	auipc	a5,0x1e
    8000578e:	fce78793          	addi	a5,a5,-50 # 80023758 <disk>
    80005792:	6398                	ld	a4,0(a5)
    80005794:	9736                	add	a4,a4,a3
    80005796:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    8000579a:	6398                	ld	a4,0(a5)
    8000579c:	9736                	add	a4,a4,a3
    8000579e:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    800057a2:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800057a6:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    800057aa:	97aa                	add	a5,a5,a0
    800057ac:	4705                	li	a4,1
    800057ae:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    800057b2:	0001e517          	auipc	a0,0x1e
    800057b6:	fbe50513          	addi	a0,a0,-66 # 80023770 <disk+0x18>
    800057ba:	809fc0ef          	jal	80001fc2 <wakeup>
}
    800057be:	60a2                	ld	ra,8(sp)
    800057c0:	6402                	ld	s0,0(sp)
    800057c2:	0141                	addi	sp,sp,16
    800057c4:	8082                	ret
    panic("free_desc 1");
    800057c6:	00002517          	auipc	a0,0x2
    800057ca:	e6a50513          	addi	a0,a0,-406 # 80007630 <etext+0x630>
    800057ce:	866fb0ef          	jal	80000834 <panic>
    panic("free_desc 2");
    800057d2:	00002517          	auipc	a0,0x2
    800057d6:	e6e50513          	addi	a0,a0,-402 # 80007640 <etext+0x640>
    800057da:	85afb0ef          	jal	80000834 <panic>

00000000800057de <virtio_disk_init>:
{
    800057de:	1101                	addi	sp,sp,-32
    800057e0:	ec06                	sd	ra,24(sp)
    800057e2:	e822                	sd	s0,16(sp)
    800057e4:	e426                	sd	s1,8(sp)
    800057e6:	e04a                	sd	s2,0(sp)
    800057e8:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800057ea:	00002597          	auipc	a1,0x2
    800057ee:	e6658593          	addi	a1,a1,-410 # 80007650 <etext+0x650>
    800057f2:	0001e517          	auipc	a0,0x1e
    800057f6:	08e50513          	addi	a0,a0,142 # 80023880 <disk+0x128>
    800057fa:	baefb0ef          	jal	80000ba8 <initlock>
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800057fe:	100017b7          	lui	a5,0x10001
    80005802:	4398                	lw	a4,0(a5)
    80005804:	2701                	sext.w	a4,a4
    80005806:	747277b7          	lui	a5,0x74727
    8000580a:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    8000580e:	14f71863          	bne	a4,a5,8000595e <virtio_disk_init+0x180>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005812:	100017b7          	lui	a5,0x10001
    80005816:	43dc                	lw	a5,4(a5)
    80005818:	2781                	sext.w	a5,a5
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    8000581a:	4709                	li	a4,2
    8000581c:	14e79163          	bne	a5,a4,8000595e <virtio_disk_init+0x180>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005820:	100017b7          	lui	a5,0x10001
    80005824:	479c                	lw	a5,8(a5)
    80005826:	2781                	sext.w	a5,a5
    80005828:	12e79b63          	bne	a5,a4,8000595e <virtio_disk_init+0x180>
      *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551) {
    8000582c:	100017b7          	lui	a5,0x10001
    80005830:	47d8                	lw	a4,12(a5)
    80005832:	2701                	sext.w	a4,a4
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005834:	554d47b7          	lui	a5,0x554d4
    80005838:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    8000583c:	12f71163          	bne	a4,a5,8000595e <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005840:	100017b7          	lui	a5,0x10001
    80005844:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005848:	4705                	li	a4,1
    8000584a:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000584c:	470d                	li	a4,3
    8000584e:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005850:	10001737          	lui	a4,0x10001
    80005854:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005856:	c7ffe6b7          	lui	a3,0xc7ffe
    8000585a:	55f68693          	addi	a3,a3,1375 # ffffffffc7ffe55f <end+0xffffffff47fdac9f>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    8000585e:	8f75                	and	a4,a4,a3
    80005860:	100016b7          	lui	a3,0x10001
    80005864:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005866:	472d                	li	a4,11
    80005868:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    8000586a:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    8000586e:	439c                	lw	a5,0(a5)
    80005870:	0007891b          	sext.w	s2,a5
  if (!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005874:	8ba1                	andi	a5,a5,8
    80005876:	0e078a63          	beqz	a5,8000596a <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    8000587a:	100017b7          	lui	a5,0x10001
    8000587e:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if (*R(VIRTIO_MMIO_QUEUE_READY))
    80005882:	43fc                	lw	a5,68(a5)
    80005884:	2781                	sext.w	a5,a5
    80005886:	0e079863          	bnez	a5,80005976 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    8000588a:	100017b7          	lui	a5,0x10001
    8000588e:	5bdc                	lw	a5,52(a5)
    80005890:	2781                	sext.w	a5,a5
  if (max == 0)
    80005892:	0e078863          	beqz	a5,80005982 <virtio_disk_init+0x1a4>
  if (max < NUM)
    80005896:	471d                	li	a4,7
    80005898:	0ef77b63          	bgeu	a4,a5,8000598e <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    8000589c:	ab2fb0ef          	jal	80000b4e <kalloc>
    800058a0:	0001e497          	auipc	s1,0x1e
    800058a4:	eb848493          	addi	s1,s1,-328 # 80023758 <disk>
    800058a8:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800058aa:	aa4fb0ef          	jal	80000b4e <kalloc>
    800058ae:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800058b0:	a9efb0ef          	jal	80000b4e <kalloc>
    800058b4:	87aa                	mv	a5,a0
    800058b6:	e888                	sd	a0,16(s1)
  if (!disk.desc || !disk.avail || !disk.used)
    800058b8:	6088                	ld	a0,0(s1)
    800058ba:	0e050063          	beqz	a0,8000599a <virtio_disk_init+0x1bc>
    800058be:	0001e717          	auipc	a4,0x1e
    800058c2:	ea273703          	ld	a4,-350(a4) # 80023760 <disk+0x8>
    800058c6:	cb71                	beqz	a4,8000599a <virtio_disk_init+0x1bc>
    800058c8:	cbe9                	beqz	a5,8000599a <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    800058ca:	6605                	lui	a2,0x1
    800058cc:	4581                	li	a1,0
    800058ce:	c1afb0ef          	jal	80000ce8 <memset>
  memset(disk.avail, 0, PGSIZE);
    800058d2:	0001e497          	auipc	s1,0x1e
    800058d6:	e8648493          	addi	s1,s1,-378 # 80023758 <disk>
    800058da:	6605                	lui	a2,0x1
    800058dc:	4581                	li	a1,0
    800058de:	6488                	ld	a0,8(s1)
    800058e0:	c08fb0ef          	jal	80000ce8 <memset>
  memset(disk.used, 0, PGSIZE);
    800058e4:	6605                	lui	a2,0x1
    800058e6:	4581                	li	a1,0
    800058e8:	6888                	ld	a0,16(s1)
    800058ea:	bfefb0ef          	jal	80000ce8 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800058ee:	100017b7          	lui	a5,0x10001
    800058f2:	4721                	li	a4,8
    800058f4:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800058f6:	4098                	lw	a4,0(s1)
    800058f8:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800058fc:	40d8                	lw	a4,4(s1)
    800058fe:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005902:	649c                	ld	a5,8(s1)
    80005904:	0007869b          	sext.w	a3,a5
    80005908:	10001737          	lui	a4,0x10001
    8000590c:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005910:	9781                	srai	a5,a5,0x20
    80005912:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005916:	689c                	ld	a5,16(s1)
    80005918:	0007869b          	sext.w	a3,a5
    8000591c:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005920:	9781                	srai	a5,a5,0x20
    80005922:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005926:	4785                	li	a5,1
    80005928:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    8000592a:	00f48c23          	sb	a5,24(s1)
    8000592e:	00f48ca3          	sb	a5,25(s1)
    80005932:	00f48d23          	sb	a5,26(s1)
    80005936:	00f48da3          	sb	a5,27(s1)
    8000593a:	00f48e23          	sb	a5,28(s1)
    8000593e:	00f48ea3          	sb	a5,29(s1)
    80005942:	00f48f23          	sb	a5,30(s1)
    80005946:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    8000594a:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    8000594e:	07272823          	sw	s2,112(a4)
}
    80005952:	60e2                	ld	ra,24(sp)
    80005954:	6442                	ld	s0,16(sp)
    80005956:	64a2                	ld	s1,8(sp)
    80005958:	6902                	ld	s2,0(sp)
    8000595a:	6105                	addi	sp,sp,32
    8000595c:	8082                	ret
    panic("could not find virtio disk");
    8000595e:	00002517          	auipc	a0,0x2
    80005962:	d0250513          	addi	a0,a0,-766 # 80007660 <etext+0x660>
    80005966:	ecffa0ef          	jal	80000834 <panic>
    panic("virtio disk FEATURES_OK unset");
    8000596a:	00002517          	auipc	a0,0x2
    8000596e:	d1650513          	addi	a0,a0,-746 # 80007680 <etext+0x680>
    80005972:	ec3fa0ef          	jal	80000834 <panic>
    panic("virtio disk should not be ready");
    80005976:	00002517          	auipc	a0,0x2
    8000597a:	d2a50513          	addi	a0,a0,-726 # 800076a0 <etext+0x6a0>
    8000597e:	eb7fa0ef          	jal	80000834 <panic>
    panic("virtio disk has no queue 0");
    80005982:	00002517          	auipc	a0,0x2
    80005986:	d3e50513          	addi	a0,a0,-706 # 800076c0 <etext+0x6c0>
    8000598a:	eabfa0ef          	jal	80000834 <panic>
    panic("virtio disk max queue too short");
    8000598e:	00002517          	auipc	a0,0x2
    80005992:	d5250513          	addi	a0,a0,-686 # 800076e0 <etext+0x6e0>
    80005996:	e9ffa0ef          	jal	80000834 <panic>
    panic("virtio disk kalloc");
    8000599a:	00002517          	auipc	a0,0x2
    8000599e:	d6650513          	addi	a0,a0,-666 # 80007700 <etext+0x700>
    800059a2:	e93fa0ef          	jal	80000834 <panic>

00000000800059a6 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800059a6:	711d                	addi	sp,sp,-96
    800059a8:	ec86                	sd	ra,88(sp)
    800059aa:	e8a2                	sd	s0,80(sp)
    800059ac:	e4a6                	sd	s1,72(sp)
    800059ae:	e0ca                	sd	s2,64(sp)
    800059b0:	fc4e                	sd	s3,56(sp)
    800059b2:	f852                	sd	s4,48(sp)
    800059b4:	f456                	sd	s5,40(sp)
    800059b6:	f05a                	sd	s6,32(sp)
    800059b8:	ec5e                	sd	s7,24(sp)
    800059ba:	e862                	sd	s8,16(sp)
    800059bc:	1080                	addi	s0,sp,96
    800059be:	89aa                	mv	s3,a0
    800059c0:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    800059c2:	00c52b83          	lw	s7,12(a0)
    800059c6:	001b9b9b          	slliw	s7,s7,0x1
    800059ca:	1b82                	slli	s7,s7,0x20
    800059cc:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    800059d0:	0001e517          	auipc	a0,0x1e
    800059d4:	eb050513          	addi	a0,a0,-336 # 80023880 <disk+0x128>
    800059d8:	a50fb0ef          	jal	80000c28 <acquire>
  for (int i = 0; i < NUM; i++) {
    800059dc:	44a1                	li	s1,8
      disk.free[i] = 0;
    800059de:	0001ea97          	auipc	s5,0x1e
    800059e2:	d7aa8a93          	addi	s5,s5,-646 # 80023758 <disk>
  for (int i = 0; i < 3; i++) {
    800059e6:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    800059e8:	5c7d                	li	s8,-1
    800059ea:	a8a5                	j	80005a62 <virtio_disk_rw+0xbc>
      disk.free[i] = 0;
    800059ec:	00fa8733          	add	a4,s5,a5
    800059f0:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    800059f4:	c19c                	sw	a5,0(a1)
    if (idx[i] < 0) {
    800059f6:	0207c563          	bltz	a5,80005a20 <virtio_disk_rw+0x7a>
  for (int i = 0; i < 3; i++) {
    800059fa:	2905                	addiw	s2,s2,1
    800059fc:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    800059fe:	07490663          	beq	s2,s4,80005a6a <virtio_disk_rw+0xc4>
    idx[i] = alloc_desc();
    80005a02:	85b2                	mv	a1,a2
  for (int i = 0; i < NUM; i++) {
    80005a04:	0001e717          	auipc	a4,0x1e
    80005a08:	d5470713          	addi	a4,a4,-684 # 80023758 <disk>
    80005a0c:	4781                	li	a5,0
    if (disk.free[i]) {
    80005a0e:	01874683          	lbu	a3,24(a4)
    80005a12:	fee9                	bnez	a3,800059ec <virtio_disk_rw+0x46>
  for (int i = 0; i < NUM; i++) {
    80005a14:	2785                	addiw	a5,a5,1
    80005a16:	0705                	addi	a4,a4,1
    80005a18:	fe979be3          	bne	a5,s1,80005a0e <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80005a1c:	0185a023          	sw	s8,0(a1)
      for (int j = 0; j < i; j++)
    80005a20:	01205d63          	blez	s2,80005a3a <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80005a24:	fa042503          	lw	a0,-96(s0)
    80005a28:	d41ff0ef          	jal	80005768 <free_desc>
      for (int j = 0; j < i; j++)
    80005a2c:	4785                	li	a5,1
    80005a2e:	0127d663          	bge	a5,s2,80005a3a <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80005a32:	fa442503          	lw	a0,-92(s0)
    80005a36:	d33ff0ef          	jal	80005768 <free_desc>
  int idx[3];
  while (1) {
    if (alloc3_desc(idx) == 0) {
      break;
    }
    sleep_prepare(&disk.free[0]);
    80005a3a:	0001e517          	auipc	a0,0x1e
    80005a3e:	d3650513          	addi	a0,a0,-714 # 80023770 <disk+0x18>
    80005a42:	d14fc0ef          	jal	80001f56 <sleep_prepare>
    release(&disk.vdisk_lock);
    80005a46:	0001e517          	auipc	a0,0x1e
    80005a4a:	e3a50513          	addi	a0,a0,-454 # 80023880 <disk+0x128>
    80005a4e:	a62fb0ef          	jal	80000cb0 <release>
    sleep();
    80005a52:	d40fc0ef          	jal	80001f92 <sleep>
    acquire(&disk.vdisk_lock);
    80005a56:	0001e517          	auipc	a0,0x1e
    80005a5a:	e2a50513          	addi	a0,a0,-470 # 80023880 <disk+0x128>
    80005a5e:	9cafb0ef          	jal	80000c28 <acquire>
  for (int i = 0; i < 3; i++) {
    80005a62:	fa040613          	addi	a2,s0,-96
    80005a66:	4901                	li	s2,0
    80005a68:	bf69                	j	80005a02 <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a6a:	fa042503          	lw	a0,-96(s0)
    80005a6e:	00451693          	slli	a3,a0,0x4

  if (write)
    80005a72:	0001e797          	auipc	a5,0x1e
    80005a76:	ce678793          	addi	a5,a5,-794 # 80023758 <disk>
    80005a7a:	00451713          	slli	a4,a0,0x4
    80005a7e:	0a070713          	addi	a4,a4,160
    80005a82:	973e                	add	a4,a4,a5
    80005a84:	01603633          	snez	a2,s6
    80005a88:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005a8a:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005a8e:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64)buf0;
    80005a92:	6398                	ld	a4,0(a5)
    80005a94:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005a96:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005a9a:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64)buf0;
    80005a9c:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005a9e:	6390                	ld	a2,0(a5)
    80005aa0:	00d60833          	add	a6,a2,a3
    80005aa4:	4741                	li	a4,16
    80005aa6:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005aaa:	4585                	li	a1,1
    80005aac:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80005ab0:	fa442703          	lw	a4,-92(s0)
    80005ab4:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64)b->data;
    80005ab8:	0712                	slli	a4,a4,0x4
    80005aba:	963a                	add	a2,a2,a4
    80005abc:	05898813          	addi	a6,s3,88
    80005ac0:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005ac4:	0007b883          	ld	a7,0(a5)
    80005ac8:	9746                	add	a4,a4,a7
    80005aca:	40000613          	li	a2,1024
    80005ace:	c710                	sw	a2,8(a4)
  if (write)
    80005ad0:	001b3613          	seqz	a2,s6
    80005ad4:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005ad8:	8e4d                	or	a2,a2,a1
    80005ada:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005ade:	fa842603          	lw	a2,-88(s0)
    80005ae2:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005ae6:	00451813          	slli	a6,a0,0x4
    80005aea:	02080813          	addi	a6,a6,32
    80005aee:	983e                	add	a6,a6,a5
    80005af0:	577d                	li	a4,-1
    80005af2:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64)&disk.info[idx[0]].status;
    80005af6:	0612                	slli	a2,a2,0x4
    80005af8:	98b2                	add	a7,a7,a2
    80005afa:	03068713          	addi	a4,a3,48
    80005afe:	973e                	add	a4,a4,a5
    80005b00:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005b04:	6398                	ld	a4,0(a5)
    80005b06:	9732                	add	a4,a4,a2
    80005b08:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005b0a:	4689                	li	a3,2
    80005b0c:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005b10:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005b14:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80005b18:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005b1c:	6794                	ld	a3,8(a5)
    80005b1e:	0026d703          	lhu	a4,2(a3)
    80005b22:	8b1d                	andi	a4,a4,7
    80005b24:	0706                	slli	a4,a4,0x1
    80005b26:	96ba                	add	a3,a3,a4
    80005b28:	00a69223          	sh	a0,4(a3)

// fence for memory-mapped IO
static inline void
io_fence()
{
  asm volatile("fence iorw, iorw" ::: "memory");
    80005b2c:	0ff0000f          	fence

  io_fence();

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005b30:	6798                	ld	a4,8(a5)
    80005b32:	00275783          	lhu	a5,2(a4)
    80005b36:	2785                	addiw	a5,a5,1
    80005b38:	00f71123          	sh	a5,2(a4)
    80005b3c:	0ff0000f          	fence

  io_fence();

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005b40:	100017b7          	lui	a5,0x10001
    80005b44:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while (b->disk == 1) {
    80005b48:	0049a783          	lw	a5,4(s3)
    sleep_prepare(b);
    release(&disk.vdisk_lock);
    80005b4c:	0001e497          	auipc	s1,0x1e
    80005b50:	d3448493          	addi	s1,s1,-716 # 80023880 <disk+0x128>
  while (b->disk == 1) {
    80005b54:	892e                	mv	s2,a1
    80005b56:	02b79163          	bne	a5,a1,80005b78 <virtio_disk_rw+0x1d2>
    sleep_prepare(b);
    80005b5a:	854e                	mv	a0,s3
    80005b5c:	bfafc0ef          	jal	80001f56 <sleep_prepare>
    release(&disk.vdisk_lock);
    80005b60:	8526                	mv	a0,s1
    80005b62:	94efb0ef          	jal	80000cb0 <release>
    sleep();
    80005b66:	c2cfc0ef          	jal	80001f92 <sleep>
    acquire(&disk.vdisk_lock);
    80005b6a:	8526                	mv	a0,s1
    80005b6c:	8bcfb0ef          	jal	80000c28 <acquire>
  while (b->disk == 1) {
    80005b70:	0049a783          	lw	a5,4(s3)
    80005b74:	ff2783e3          	beq	a5,s2,80005b5a <virtio_disk_rw+0x1b4>
  }

  disk.info[idx[0]].b = 0;
    80005b78:	fa042903          	lw	s2,-96(s0)
    80005b7c:	00491713          	slli	a4,s2,0x4
    80005b80:	02070713          	addi	a4,a4,32
    80005b84:	0001e797          	auipc	a5,0x1e
    80005b88:	bd478793          	addi	a5,a5,-1068 # 80023758 <disk>
    80005b8c:	97ba                	add	a5,a5,a4
    80005b8e:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005b92:	0001e997          	auipc	s3,0x1e
    80005b96:	bc698993          	addi	s3,s3,-1082 # 80023758 <disk>
    80005b9a:	00491713          	slli	a4,s2,0x4
    80005b9e:	0009b783          	ld	a5,0(s3)
    80005ba2:	97ba                	add	a5,a5,a4
    80005ba4:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005ba8:	854a                	mv	a0,s2
    80005baa:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005bae:	bbbff0ef          	jal	80005768 <free_desc>
    if (flag & VRING_DESC_F_NEXT)
    80005bb2:	8885                	andi	s1,s1,1
    80005bb4:	f0fd                	bnez	s1,80005b9a <virtio_disk_rw+0x1f4>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005bb6:	0001e517          	auipc	a0,0x1e
    80005bba:	cca50513          	addi	a0,a0,-822 # 80023880 <disk+0x128>
    80005bbe:	8f2fb0ef          	jal	80000cb0 <release>
}
    80005bc2:	60e6                	ld	ra,88(sp)
    80005bc4:	6446                	ld	s0,80(sp)
    80005bc6:	64a6                	ld	s1,72(sp)
    80005bc8:	6906                	ld	s2,64(sp)
    80005bca:	79e2                	ld	s3,56(sp)
    80005bcc:	7a42                	ld	s4,48(sp)
    80005bce:	7aa2                	ld	s5,40(sp)
    80005bd0:	7b02                	ld	s6,32(sp)
    80005bd2:	6be2                	ld	s7,24(sp)
    80005bd4:	6c42                	ld	s8,16(sp)
    80005bd6:	6125                	addi	sp,sp,96
    80005bd8:	8082                	ret

0000000080005bda <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005bda:	1101                	addi	sp,sp,-32
    80005bdc:	ec06                	sd	ra,24(sp)
    80005bde:	e822                	sd	s0,16(sp)
    80005be0:	e426                	sd	s1,8(sp)
    80005be2:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005be4:	0001e497          	auipc	s1,0x1e
    80005be8:	b7448493          	addi	s1,s1,-1164 # 80023758 <disk>
    80005bec:	0001e517          	auipc	a0,0x1e
    80005bf0:	c9450513          	addi	a0,a0,-876 # 80023880 <disk+0x128>
    80005bf4:	834fb0ef          	jal	80000c28 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005bf8:	100017b7          	lui	a5,0x10001
    80005bfc:	53bc                	lw	a5,96(a5)
    80005bfe:	8b8d                	andi	a5,a5,3
    80005c00:	10001737          	lui	a4,0x10001
    80005c04:	d37c                	sw	a5,100(a4)
    80005c06:	0ff0000f          	fence
  io_fence();

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while (disk.used_idx != disk.used->idx) {
    80005c0a:	689c                	ld	a5,16(s1)
    80005c0c:	0204d703          	lhu	a4,32(s1)
    80005c10:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005c14:	04f70863          	beq	a4,a5,80005c64 <virtio_disk_intr+0x8a>
    80005c18:	0ff0000f          	fence
    io_fence();
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005c1c:	6898                	ld	a4,16(s1)
    80005c1e:	0204d783          	lhu	a5,32(s1)
    80005c22:	8b9d                	andi	a5,a5,7
    80005c24:	078e                	slli	a5,a5,0x3
    80005c26:	97ba                	add	a5,a5,a4
    80005c28:	43dc                	lw	a5,4(a5)

    if (disk.info[id].status != 0)
    80005c2a:	00479713          	slli	a4,a5,0x4
    80005c2e:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80005c32:	9726                	add	a4,a4,s1
    80005c34:	01074703          	lbu	a4,16(a4)
    80005c38:	e329                	bnez	a4,80005c7a <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005c3a:	0792                	slli	a5,a5,0x4
    80005c3c:	02078793          	addi	a5,a5,32
    80005c40:	97a6                	add	a5,a5,s1
    80005c42:	6788                	ld	a0,8(a5)
    b->disk = 0; // disk is done with buf
    80005c44:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005c48:	b7afc0ef          	jal	80001fc2 <wakeup>

    disk.used_idx += 1;
    80005c4c:	0204d783          	lhu	a5,32(s1)
    80005c50:	2785                	addiw	a5,a5,1
    80005c52:	17c2                	slli	a5,a5,0x30
    80005c54:	93c1                	srli	a5,a5,0x30
    80005c56:	02f49023          	sh	a5,32(s1)
  while (disk.used_idx != disk.used->idx) {
    80005c5a:	6898                	ld	a4,16(s1)
    80005c5c:	00275703          	lhu	a4,2(a4)
    80005c60:	faf71ce3          	bne	a4,a5,80005c18 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005c64:	0001e517          	auipc	a0,0x1e
    80005c68:	c1c50513          	addi	a0,a0,-996 # 80023880 <disk+0x128>
    80005c6c:	844fb0ef          	jal	80000cb0 <release>
}
    80005c70:	60e2                	ld	ra,24(sp)
    80005c72:	6442                	ld	s0,16(sp)
    80005c74:	64a2                	ld	s1,8(sp)
    80005c76:	6105                	addi	sp,sp,32
    80005c78:	8082                	ret
      panic("virtio_disk_intr status");
    80005c7a:	00002517          	auipc	a0,0x2
    80005c7e:	a9e50513          	addi	a0,a0,-1378 # 80007718 <etext+0x718>
    80005c82:	bb3fa0ef          	jal	80000834 <panic>

0000000080005c86 <initqlock>:
#include "qlock.h"
#include "proc.h"

void
initqlock(struct qlock *q, char *name)
{
    80005c86:	1101                	addi	sp,sp,-32
    80005c88:	ec06                	sd	ra,24(sp)
    80005c8a:	e822                	sd	s0,16(sp)
    80005c8c:	e426                	sd	s1,8(sp)
    80005c8e:	1000                	addi	s0,sp,32
    80005c90:	84aa                	mv	s1,a0
	initlock(&q->lk, name);
    80005c92:	f17fa0ef          	jal	80000ba8 <initlock>
	q->locked = 0;
    80005c96:	0004ac23          	sw	zero,24(s1)
	q->next_ticket = 0;
    80005c9a:	0004ae23          	sw	zero,28(s1)
	q->serving_ticket = 0;
    80005c9e:	0204a023          	sw	zero,32(s1)
}
    80005ca2:	60e2                	ld	ra,24(sp)
    80005ca4:	6442                	ld	s0,16(sp)
    80005ca6:	64a2                	ld	s1,8(sp)
    80005ca8:	6105                	addi	sp,sp,32
    80005caa:	8082                	ret

0000000080005cac <acquireq>:

void
acquireq(struct qlock *q)
{ 
    80005cac:	7179                	addi	sp,sp,-48
    80005cae:	f406                	sd	ra,40(sp)
    80005cb0:	f022                	sd	s0,32(sp)
    80005cb2:	ec26                	sd	s1,24(sp)
    80005cb4:	e84a                	sd	s2,16(sp)
    80005cb6:	1800                	addi	s0,sp,48
    80005cb8:	84aa                	mv	s1,a0
	uint ticket;

	acquire(&q->lk);
    80005cba:	f6ffa0ef          	jal	80000c28 <acquire>
	

	ticket = q->next_ticket;
    80005cbe:	01c4a903          	lw	s2,28(s1)
	q->next_ticket++;
    80005cc2:	0019079b          	addiw	a5,s2,1
    80005cc6:	ccdc                	sw	a5,28(s1)

	while(ticket != q->serving_ticket)
    80005cc8:	509c                	lw	a5,32(s1)
    80005cca:	03278463          	beq	a5,s2,80005cf2 <acquireq+0x46>
    80005cce:	e44e                	sd	s3,8(sp)
	{
	sleep_prepare(&q->serving_ticket);
    80005cd0:	02048993          	addi	s3,s1,32
    80005cd4:	854e                	mv	a0,s3
    80005cd6:	a80fc0ef          	jal	80001f56 <sleep_prepare>
	release(&q->lk);
    80005cda:	8526                	mv	a0,s1
    80005cdc:	fd5fa0ef          	jal	80000cb0 <release>
	sleep();
    80005ce0:	ab2fc0ef          	jal	80001f92 <sleep>
	acquire(&q->lk);
    80005ce4:	8526                	mv	a0,s1
    80005ce6:	f43fa0ef          	jal	80000c28 <acquire>
	while(ticket != q->serving_ticket)
    80005cea:	509c                	lw	a5,32(s1)
    80005cec:	ff2794e3          	bne	a5,s2,80005cd4 <acquireq+0x28>
    80005cf0:	69a2                	ld	s3,8(sp)
}

	q->locked = 1;
    80005cf2:	4785                	li	a5,1
    80005cf4:	cc9c                	sw	a5,24(s1)
	release(&q->lk);
    80005cf6:	8526                	mv	a0,s1
    80005cf8:	fb9fa0ef          	jal	80000cb0 <release>
}
    80005cfc:	70a2                	ld	ra,40(sp)
    80005cfe:	7402                	ld	s0,32(sp)
    80005d00:	64e2                	ld	s1,24(sp)
    80005d02:	6942                	ld	s2,16(sp)
    80005d04:	6145                	addi	sp,sp,48
    80005d06:	8082                	ret

0000000080005d08 <releaseq>:

void
releaseq(struct qlock *q)
{
    80005d08:	1101                	addi	sp,sp,-32
    80005d0a:	ec06                	sd	ra,24(sp)
    80005d0c:	e822                	sd	s0,16(sp)
    80005d0e:	e426                	sd	s1,8(sp)
    80005d10:	1000                	addi	s0,sp,32
    80005d12:	84aa                	mv	s1,a0
	acquire(&q->lk);
    80005d14:	f15fa0ef          	jal	80000c28 <acquire>

	if(q->locked == 0)
    80005d18:	4c9c                	lw	a5,24(s1)
    80005d1a:	c395                	beqz	a5,80005d3e <releaseq+0x36>
		panic("releaseq");

	q->locked = 0;
    80005d1c:	0004ac23          	sw	zero,24(s1)
	q->serving_ticket++;
    80005d20:	509c                	lw	a5,32(s1)
    80005d22:	2785                	addiw	a5,a5,1
    80005d24:	d09c                	sw	a5,32(s1)

	wakeup(&q->serving_ticket);
    80005d26:	02048513          	addi	a0,s1,32
    80005d2a:	a98fc0ef          	jal	80001fc2 <wakeup>

	release(&q->lk);
    80005d2e:	8526                	mv	a0,s1
    80005d30:	f81fa0ef          	jal	80000cb0 <release>
}
    80005d34:	60e2                	ld	ra,24(sp)
    80005d36:	6442                	ld	s0,16(sp)
    80005d38:	64a2                	ld	s1,8(sp)
    80005d3a:	6105                	addi	sp,sp,32
    80005d3c:	8082                	ret
		panic("releaseq");
    80005d3e:	00002517          	auipc	a0,0x2
    80005d42:	9f250513          	addi	a0,a0,-1550 # 80007730 <etext+0x730>
    80005d46:	aeffa0ef          	jal	80000834 <panic>

0000000080005d4a <qlock_basic_test>:

void
qlock_basic_test(void)
{
    80005d4a:	715d                	addi	sp,sp,-80
    80005d4c:	e486                	sd	ra,72(sp)
    80005d4e:	e0a2                	sd	s0,64(sp)
    80005d50:	fc26                	sd	s1,56(sp)
    80005d52:	0880                	addi	s0,sp,80
	struct qlock q;

	initqlock(&q, "qlock_test");
    80005d54:	fb840493          	addi	s1,s0,-72
    80005d58:	00002597          	auipc	a1,0x2
    80005d5c:	9e858593          	addi	a1,a1,-1560 # 80007740 <etext+0x740>
    80005d60:	8526                	mv	a0,s1
    80005d62:	f25ff0ef          	jal	80005c86 <initqlock>
	
	printk("QLock Test Starting\n");
    80005d66:	00002517          	auipc	a0,0x2
    80005d6a:	9ea50513          	addi	a0,a0,-1558 # 80007750 <etext+0x750>
    80005d6e:	f9cfa0ef          	jal	8000050a <printk>

	acquireq(&q);
    80005d72:	8526                	mv	a0,s1
    80005d74:	f39ff0ef          	jal	80005cac <acquireq>
	printk("QLock acquired successfully\n");
    80005d78:	00002517          	auipc	a0,0x2
    80005d7c:	9f050513          	addi	a0,a0,-1552 # 80007768 <etext+0x768>
    80005d80:	f8afa0ef          	jal	8000050a <printk>

	releaseq(&q);
    80005d84:	8526                	mv	a0,s1
    80005d86:	f83ff0ef          	jal	80005d08 <releaseq>
	printk("QLock released successfully\n");
    80005d8a:	00002517          	auipc	a0,0x2
    80005d8e:	9fe50513          	addi	a0,a0,-1538 # 80007788 <etext+0x788>
    80005d92:	f78fa0ef          	jal	8000050a <printk>

	printk("QLock Basic Test Complete\n");
    80005d96:	00002517          	auipc	a0,0x2
    80005d9a:	a1250513          	addi	a0,a0,-1518 # 800077a8 <etext+0x7a8>
    80005d9e:	f6cfa0ef          	jal	8000050a <printk>
}
    80005da2:	60a6                	ld	ra,72(sp)
    80005da4:	6406                	ld	s0,64(sp)
    80005da6:	74e2                	ld	s1,56(sp)
    80005da8:	6161                	addi	sp,sp,80
    80005daa:	8082                	ret

0000000080005dac <qlock_concurrent_test>:
static int active = 0;
static int counter = 0;

void
qlock_concurrent_test(void)
{
    80005dac:	7179                	addi	sp,sp,-48
    80005dae:	f406                	sd	ra,40(sp)
    80005db0:	f022                	sd	s0,32(sp)
    80005db2:	ec26                	sd	s1,24(sp)
    80005db4:	1800                	addi	s0,sp,48

	acquireq(&shared_q);
    80005db6:	0001e517          	auipc	a0,0x1e
    80005dba:	ae250513          	addi	a0,a0,-1310 # 80023898 <shared_q>
    80005dbe:	eefff0ef          	jal	80005cac <acquireq>

	active++;
    80005dc2:	00004717          	auipc	a4,0x4
    80005dc6:	7be70713          	addi	a4,a4,1982 # 8000a580 <active>
    80005dca:	431c                	lw	a5,0(a4)
    80005dcc:	2785                	addiw	a5,a5,1
    80005dce:	c31c                	sw	a5,0(a4)
	if(active != 1)
    80005dd0:	4705                	li	a4,1
    80005dd2:	08e79463          	bne	a5,a4,80005e5a <qlock_concurrent_test+0xae>
		panic("QLock mutual exclusion failed");

	counter++;
    80005dd6:	00004497          	auipc	s1,0x4
    80005dda:	7a648493          	addi	s1,s1,1958 # 8000a57c <counter>
    80005dde:	409c                	lw	a5,0(s1)
    80005de0:	2785                	addiw	a5,a5,1
    80005de2:	c09c                	sw	a5,0(s1)
	printk("Process %d acquried QLock, counter = %d\n",
		myproc()->pid, counter);
    80005de4:	b69fb0ef          	jal	8000194c <myproc>
	printk("Process %d acquried QLock, counter = %d\n",
    80005de8:	4090                	lw	a2,0(s1)
    80005dea:	590c                	lw	a1,48(a0)
    80005dec:	00002517          	auipc	a0,0x2
    80005df0:	9fc50513          	addi	a0,a0,-1540 # 800077e8 <etext+0x7e8>
    80005df4:	f16fa0ef          	jal	8000050a <printk>

	for(volatile int i = 0; i< 1000000;i++);
    80005df8:	fc042e23          	sw	zero,-36(s0)
    80005dfc:	fdc42703          	lw	a4,-36(s0)
    80005e00:	2701                	sext.w	a4,a4
    80005e02:	000f47b7          	lui	a5,0xf4
    80005e06:	23f78793          	addi	a5,a5,575 # f423f <_entry-0x7ff0bdc1>
    80005e0a:	00e7cd63          	blt	a5,a4,80005e24 <qlock_concurrent_test+0x78>
    80005e0e:	873e                	mv	a4,a5
    80005e10:	fdc42783          	lw	a5,-36(s0)
    80005e14:	2785                	addiw	a5,a5,1
    80005e16:	fcf42e23          	sw	a5,-36(s0)
    80005e1a:	fdc42783          	lw	a5,-36(s0)
    80005e1e:	2781                	sext.w	a5,a5
    80005e20:	fef758e3          	bge	a4,a5,80005e10 <qlock_concurrent_test+0x64>

	active--;
    80005e24:	00004717          	auipc	a4,0x4
    80005e28:	75c70713          	addi	a4,a4,1884 # 8000a580 <active>
    80005e2c:	431c                	lw	a5,0(a4)
    80005e2e:	37fd                	addiw	a5,a5,-1
    80005e30:	c31c                	sw	a5,0(a4)

	printk("Process%d released QLock\n", myproc()->pid);
    80005e32:	b1bfb0ef          	jal	8000194c <myproc>
    80005e36:	590c                	lw	a1,48(a0)
    80005e38:	00002517          	auipc	a0,0x2
    80005e3c:	9e050513          	addi	a0,a0,-1568 # 80007818 <etext+0x818>
    80005e40:	ecafa0ef          	jal	8000050a <printk>

	releaseq(&shared_q);
    80005e44:	0001e517          	auipc	a0,0x1e
    80005e48:	a5450513          	addi	a0,a0,-1452 # 80023898 <shared_q>
    80005e4c:	ebdff0ef          	jal	80005d08 <releaseq>
}
    80005e50:	70a2                	ld	ra,40(sp)
    80005e52:	7402                	ld	s0,32(sp)
    80005e54:	64e2                	ld	s1,24(sp)
    80005e56:	6145                	addi	sp,sp,48
    80005e58:	8082                	ret
		panic("QLock mutual exclusion failed");
    80005e5a:	00002517          	auipc	a0,0x2
    80005e5e:	96e50513          	addi	a0,a0,-1682 # 800077c8 <etext+0x7c8>
    80005e62:	9d3fa0ef          	jal	80000834 <panic>

0000000080005e66 <qlock_test_init>:

void 
qlock_test_init(void)
{
    80005e66:	1141                	addi	sp,sp,-16
    80005e68:	e406                	sd	ra,8(sp)
    80005e6a:	e022                	sd	s0,0(sp)
    80005e6c:	0800                	addi	s0,sp,16
	initqlock(&shared_q, "shared_qlock");
    80005e6e:	00002597          	auipc	a1,0x2
    80005e72:	9ca58593          	addi	a1,a1,-1590 # 80007838 <etext+0x838>
    80005e76:	0001e517          	auipc	a0,0x1e
    80005e7a:	a2250513          	addi	a0,a0,-1502 # 80023898 <shared_q>
    80005e7e:	e09ff0ef          	jal	80005c86 <initqlock>
}
    80005e82:	60a2                	ld	ra,8(sp)
    80005e84:	6402                	ld	s0,0(sp)
    80005e86:	0141                	addi	sp,sp,16
    80005e88:	8082                	ret
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	0000100f          	fence.i
    800060a0:	12000073          	sfence.vma
    800060a4:	18051073          	csrw	satp,a0
    800060a8:	12000073          	sfence.vma
    800060ac:	02000537          	lui	a0,0x2000
    800060b0:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060b2:	0536                	slli	a0,a0,0xd
    800060b4:	02853083          	ld	ra,40(a0)
    800060b8:	03053103          	ld	sp,48(a0)
    800060bc:	03853183          	ld	gp,56(a0)
    800060c0:	04053203          	ld	tp,64(a0)
    800060c4:	04853283          	ld	t0,72(a0)
    800060c8:	05053303          	ld	t1,80(a0)
    800060cc:	05853383          	ld	t2,88(a0)
    800060d0:	7120                	ld	s0,96(a0)
    800060d2:	7524                	ld	s1,104(a0)
    800060d4:	7d2c                	ld	a1,120(a0)
    800060d6:	6150                	ld	a2,128(a0)
    800060d8:	6554                	ld	a3,136(a0)
    800060da:	6958                	ld	a4,144(a0)
    800060dc:	6d5c                	ld	a5,152(a0)
    800060de:	0a053803          	ld	a6,160(a0)
    800060e2:	0a853883          	ld	a7,168(a0)
    800060e6:	0b053903          	ld	s2,176(a0)
    800060ea:	0b853983          	ld	s3,184(a0)
    800060ee:	0c053a03          	ld	s4,192(a0)
    800060f2:	0c853a83          	ld	s5,200(a0)
    800060f6:	0d053b03          	ld	s6,208(a0)
    800060fa:	0d853b83          	ld	s7,216(a0)
    800060fe:	0e053c03          	ld	s8,224(a0)
    80006102:	0e853c83          	ld	s9,232(a0)
    80006106:	0f053d03          	ld	s10,240(a0)
    8000610a:	0f853d83          	ld	s11,248(a0)
    8000610e:	10053e03          	ld	t3,256(a0)
    80006112:	10853e83          	ld	t4,264(a0)
    80006116:	11053f03          	ld	t5,272(a0)
    8000611a:	11853f83          	ld	t6,280(a0)
    8000611e:	7928                	ld	a0,112(a0)
    80006120:	10200073          	sret
	...
