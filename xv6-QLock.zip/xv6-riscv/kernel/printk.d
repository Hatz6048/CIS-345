kernel/printk.o: kernel/printk.c \
 /usr/lib/gcc-cross/riscv64-linux-gnu/15/include/stdarg.h kernel/types.h \
 kernel/param.h kernel/spinlock.h kernel/sleeplock.h kernel/fs.h \
 kernel/file.h kernel/memlayout.h kernel/riscv.h kernel/defs.h \
 kernel/proc.h
