#include "kernel/types.h"
#include "user/user.h"

int
 main(void)
{
	printf("Starting Concurrent QLock test...\n");

	for(int i = 0; i < 3; i++) {
		int pid = fork();

		if(pid < 0) {
		   printf("Fork failed\n");
			exit(1);
		}

		if(pid ==0)  {
			qlocktest();
			exit(0);
		}
	}
	
	for(int i = 0; i < 3; i++){
		wait(0);
	}

	printf("Concurrent QLock test finished. \n");
	exit(0);
}

