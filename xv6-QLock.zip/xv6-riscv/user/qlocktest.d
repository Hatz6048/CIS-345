user/qlocktest.o: user/qlocktest.c kernel/types.h user/user.h
