CIS 345 Homework 2 - getprocs System Call

Objective: add a system call in xv6-riscv that returns the number of processes that are not unused.

Files modified:

	- kernel/syscall.h -- added the system call number.
	- kernel/syscall.c -- registered the new system call.
	- kernel/sysproc.c -- implemented the process-counting function
	- user/user.h -- decalered getprocs()
	- user/user.pl -- added the system call entry
	- user/getprocs.c -- created a test program
	- Makefile -- added the test program to UPROGS

System call Number

23 (SYS_getprocs)

Testing

the program was designed to run on xv6 shll using:

getprocs

example output:

Processes running: 3

the system call counts all process entries whose state is not UNUSED, including sleeping processes.
